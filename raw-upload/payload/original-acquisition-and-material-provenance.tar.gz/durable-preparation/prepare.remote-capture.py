"""Local inert durable-material preparation. No publication, executable launch or source mutation."""
import gzip, hashlib, importlib.util, io, json, os, pathlib, stat, sys, tarfile, time, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
ASSETS = pathlib.Path('/tmp/M6_410_REMOTE_DURABLE_SCHEMA_PORT_OUTPUT_20261019_RUN1/assets')
SCRATCH = ROOT.parent
REPO = pathlib.Path('/workspace/zryna')
COMMIT = '71fd69d99a39c22bdf262d1655a032aa76221f3e'
TREE = '351da60bd4037e0f96c286045c8943f41fa99b03'
RAW_TAG = 'm6-raw-evidence-' + COMMIT + '-1'
URL = 'https://github.com/zryna/zryna/releases/download/' + RAW_TAG + '/'
sha = lambda b: hashlib.sha256(b).hexdigest()

def digest(path):
    p = pathlib.Path(path)
    before = p.lstat()
    assert stat.S_ISREG(before.st_mode) and not p.is_symlink()
    h, count = hashlib.sha256(), 0
    with p.open('rb') as stream:
        while block := stream.read(65536):
            h.update(block); count += len(block)
    after = p.lstat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
    return count,h.hexdigest()

def put(name,data):
    p = ASSETS / name
    with p.open('xb') as stream: stream.write(data)
    p.chmod(0o400)
    return p

def canon(value): return json.dumps(value,separators=(',',':'),ensure_ascii=True).encode()
def save(name,value):
    with (ROOT/name).open('x') as stream: json.dump(value,stream,indent=2);stream.write('\n')
def j(path): return json.loads(pathlib.Path(path).read_bytes())

# Actual future inputs only. This helper is not invoked by inert preparation.
assert len(sys.argv) == 3, 'explicit actual selection path and independently pinned SHA required'
selection_raw = pathlib.Path(sys.argv[1]).read_bytes()
assert len(selection_raw) <= 262144 and sha(selection_raw) == sys.argv[2]
selection = json.loads(selection_raw)
assert selection['source'] == {'commit': COMMIT, 'tree': TREE}
required_initial = ['frozenMain','fullCiAdmission','candidateReview','nativeReview','installedSupplementReview','editorSetupReview','readerReview','documentationReview','compilerRuntimePlan','compilerImageMetadata','evaluatorImageMetadata','compilerImageExport','evaluatorImageExport']
for key in required_initial:
    selected_pin = selection['inputs'][key]
    assert selected_pin is not None and set(selected_pin) == {'path','bytes','sha256'}, key
    assert digest(selected_pin['path']) == (selected_pin['bytes'],selected_pin['sha256']), key
frozen = j(selection['inputs']['frozenMain']['path'])
assert frozen['status'] == 'actual-reviewed-publication-fix-merged-and-new-main-frozen'
assert frozen['commit'] == COMMIT and frozen['tree'] == TREE and frozen['pr'] == 565
assert frozen['head'] == '3604ea3bb551d9dbeef5dcd7c3cee0109e8de8d3' and frozen['previous'] == 'b3be654c452ea51f2c136a75d2eb89995eb4bd66'
for key in ['candidateReview','readerReview']:
    assert j(selection['inputs'][key]['path'])['source'] == selection['source']
assert j(selection['inputs']['documentationReview']['path'])['expected']['source']['commit'] == COMMIT
production_pin = selection['websiteProductionProof']
assert production_pin is not None and set(production_pin) == {'path','bytes','sha256'}
assert digest(production_pin['path']) == (production_pin['bytes'],production_pin['sha256'])
assert pathlib.Path(production_pin['path']) == SCRATCH/('M6_410_WEBSITE_PRODUCTION_VERIFICATION_'+COMMIT+'_RUN1')/'RESULT.json'

pins, uploads, meanings = [], {}, {}
def artifact(role,path,version,source,*,asset=None,existing=None,note=''):
    path = pathlib.Path(path); count,hash_ = digest(path)
    name = asset or path.name
    assert count > 0 and count <= 2147483648
    pin = {'role':role,'path':'artifacts/'+name,'version':version,'source':source,'bytes':count,'sha256':hash_,'url':existing or URL+name}
    assert not any(x['role']==role or x['path']==pin['path'] for x in pins)
    pins.append(pin)
    meanings[role] = {'localPath':str(path),'subjectMeaning':note,'retention': 'existing-original-release' if existing else 'future-create-only-raw-release'}
    if not existing:
        if name in uploads: assert uploads[name]['sha256']==hash_
        uploads[name]={'name':name,'localPath':str(path),'bytes':count,'sha256':hash_,'futureUrl':URL+name}
    return pin

def git_source(source_hash):
    return {'kind':'git','revision':COMMIT+':'+TREE,'sha256':source_hash}

legacy = SCRATCH/'M6_410_LEGACY_RESTORED_VERIFICATION_20261018_RUN1'
legacy_inputs = SCRATCH/'M6_410_LEGACY_PUBLISHED_INPUTS_20261018_RUN1'
verified = j(legacy/'RESULT.json'); assert verified['signature'] is True
legacy_source={'kind':'signed-package','revision':'v0.2.3@'+verified['source']['commit'],'sha256':verified['archiveSha256']}
artifact('compiler-release',legacy_inputs/'zryna-0.2.3-x86_64-unknown-linux-gnu.tar.gz','0.2.3',legacy_source,
 existing='https://github.com/zryna/zryna/releases/download/v0.2.3/zryna-0.2.3-x86_64-unknown-linux-gnu.tar.gz',
 note='Original complete immutable signed v0.2.3 Linux compiler archive, authenticated by the retained envelope/bundle. No rebuilding or relabeling as current main.')
for role,name in [('legacy-release-envelope','zryna-release-envelope-v1.json'),('legacy-release-signature','zryna-release-envelope-v1.sigstore.json')]:
    artifact(role,legacy_inputs/name,'0.2.3',legacy_source,existing='https://github.com/zryna/zryna/releases/download/v0.2.3/'+name,note='Original signed legacy provenance, unchanged bytes.')

composition = SCRATCH/'M6_410_MATERIAL_COMPOSITION_20261018_RUN1'
material_runtime = SCRATCH/'M6_410_FINAL_RUNTIME_PREPARATION_20261018_RUN1'
# Required actual retained GHA capture; no local Engine or emitter fallback.
adapter_path=pathlib.Path('/workspace/scratch/M6_410_REMOTE_CAPTURE_DURABLE_ADAPTER_PREPARATION_20261019_RUN2/capture-inputs.py')
assert digest(adapter_path)==(12405,'19b41ddc10490b1c937edc06d903c7e669c62e2c45eea1df3cfdce19056f953c')
spec=importlib.util.spec_from_file_location('retained_material_capture',adapter_path)
adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
selected_capture=selection['remoteCapture']
assert set(selected_capture)=={'root','manifest','completedRuntime','candidate'} and all(selected_capture.values())
assert selected_capture['candidate']==j(selection['inputs']['candidateReview']['path'])['compiler']
capture=adapter.load_capture(selected_capture['root'],selected_capture['manifest'],selected_capture['completedRuntime'],selected_capture['candidate'])
assert digest(adapter_path)==(12405,'19b41ddc10490b1c937edc06d903c7e669c62e2c45eea1df3cfdce19056f953c')
for key,actual in [('compilerRuntimePlan',capture['runtimePlans']['compiler']),('compilerImageMetadata',capture['imageMetadata']['compiler']),('evaluatorImageMetadata',capture['imageMetadata']['evaluator']),('compilerImageExport',capture['imageExports']['compiler']),('evaluatorImageExport',capture['imageExports']['evaluator'])]:
    assert selection['inputs'][key]==actual, key
plans=pathlib.Path(capture['runtimePlans']['compiler']['path']).parent
save('REMOTE_CAPTURE_INPUTS.json',capture)
# Preserve whole actual emitted bytes/receipts; no source-path rewrite or re-emission.
for role in ['compiler','evaluator']:
    material=capture['materials'][role];receipt=j(material['emissionReceipt']['path']);manifest=pathlib.Path(material['manifest']['path'])
    artifact(role+'-materials',manifest,'1.0.0',{'kind':'git','revision':'5d79dba18117a7ff41ff08d328aa94838c0fce9c:78f42e37111204b1fb20a2363fc41fc23e62b8ef','sha256':material['plan']['sha256']},asset=role+'-materials-manifest.json',note='Original unchanged component manifest; plan SHA identifies actual retained remote locator plan, not a new historical source blob or approval.')
    artifact(role+'-materials-archive',material['materialArchive']['path'],'1.0.0',{'kind':'git','revision':'5d79dba18117a7ff41ff08d328aa94838c0fce9c:78f42e37111204b1fb20a2363fc41fc23e62b8ef','sha256':material['manifest']['sha256']},asset=role+'-materials.tar.gz',note='Whole actual original remote-emitter gzip, independently audited 14/419 USTAR members; immutable historical component bytes unchanged, remote source paths remain provenance only.')
    save(role+'-material-emission.json',receipt)

def small_tar(name, entries):
    out=ASSETS/name
    with out.open('xb') as raw_out:
        with gzip.GzipFile(fileobj=raw_out,filename='',mtime=0,mode='wb',compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.USTAR_FORMAT) as a:
                for rel,path,mode in entries:
                    size,_=digest(path); h=tarfile.TarInfo(rel);h.mode=mode;h.size=size;h.uid=h.gid=h.mtime=0
                    with pathlib.Path(path).open('rb') as stream:a.addfile(h,stream)
    out.chmod(0o400);return out

def small_material_tar(name, entries):
    # Original two small publication envelopes from already verified compiler material archive.
    material=capture['materials']['compiler'];manifest=j(material['manifest']['path']);by={x['path']:x for x in manifest['files']}
    out=ASSETS/name
    with tarfile.open(material['materialArchive']['path'],'r:gz') as original,out.open('xb') as raw_out:
        members={x.name:x for x in original.getmembers()}
        with gzip.GzipFile(fileobj=raw_out,filename='',mtime=0,mode='wb',compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.USTAR_FORMAT) as archive:
                for rel,mode in entries:
                    row=by[rel];member=members[rel];assert member.isfile() and member.size==row['bytes'] and member.mode==row['mode']
                    h=tarfile.TarInfo(rel);h.mode=mode;h.size=row['bytes'];h.uid=h.gid=h.mtime=0
                    with original.extractfile(member) as stream:archive.addfile(h,stream)
    out.chmod(0o400);return out
node_tar=small_material_tar('node-22.22.1-linux-x64.tar.gz',[(x,0o555 if x.endswith('/node') else 0o444)for x in ['runtime/node/bin/node','licenses/node-LICENSE']])
artifact('node-runtime',node_tar,'22.22.1',legacy_source,note='Exact unchanged legacy Node and license selected from fully verified original compiler materials; no new runtime approval.')
compiler_manifest=j(capture['materials']['compiler']['manifest']['path'])
provider_tar=small_material_tar('signed-legacy-provider-6.0.2.tar.gz',[(x['path'],x['mode'])for x in compiler_manifest['files']if x['path'].startswith('lib/zryna/bootstrap/')or x['path'].startswith('licenses/typescript')])
artifact('provider',provider_tar,'6.0.2',legacy_source,note='Entire unchanged signed legacy bootstrap/provider closure and licenses selected from verified original material archive; TypeScript package6.0.2 delegates to original6.0.3.')

# Exact same-source setup candidates and individually selected original payloads.
for platform in ['linux','windows']:
    upper=platform.upper();filename='zryna-setup-0.1.0-candidate.3-x86_64-'+('unknown-linux-gnu.tar.gz' if platform=='linux' else 'pc-windows-msvc.zip')
    p=SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('SETUP-'+platform)/'retained/evidence'/filename
    if platform=='linux':
        with tarfile.open(p,'r:gz') as a:
            members={x.name:x for x in a.getmembers()}; prefix=filename.removesuffix('.tar.gz')+'/'
            read=lambda n:a.extractfile(members[prefix+n]).read()
            manifest_raw=read('setup.json'); server_raw=read('bin/zryna-language-server'); vsix_raw=read('editor/zryna-0.5.0.vsix')
    else:
        with zipfile.ZipFile(p) as a:
            prefix=filename.removesuffix('.zip')+'/'
            manifest_raw=a.read(prefix+'setup.json'); server_raw=a.read(prefix+'bin/zryna-language-server.exe'); vsix_raw=a.read(prefix+'editor/zryna-0.5.0.vsix')
    manifest=json.loads(manifest_raw);assert manifest['sourceCommit']==COMMIT and manifest['sourceTree']==TREE
    source=git_source(sha(manifest_raw))
    artifact('setup-'+platform,p,'0.1.0-candidate.3',source,note='Actual full same-source review-candidate portable setup archive. Includes nested legacy compiler, Node/provider closure, licenses, server, VSIX and provenance. No independent-clean-machine or production setup admission claim.')
    server_name='zryna-language-server-'+platform+('.exe' if platform=='windows' else '')
    for rel,data in [('bin/zryna-language-server'+('.exe' if platform=='windows' else ''),server_raw),('editor/zryna-0.5.0.vsix',vsix_raw)]:
        pin=next(x for x in manifest['files'] if x['path']==rel);assert len(data)==pin['size'] and sha(data)==pin['sha256']
    artifact('server-'+platform,put(server_name,server_raw),'0.5.0',source,note='Exact installed native language server binary selected from the authenticated same-source portable setup manifest.')
    artifact('extension' if platform=='linux' else 'extension-windows',put('zryna-0.5.0-'+platform+'.vsix',vsix_raw),'0.5.0',source,note='Exact actual platform-selected installed VSIX bytes. Windows build has a different ZIP digest and is retained as a separate role; no platform identity substitution.')
    artifact('setup-manifest-'+platform,put('setup-manifest-'+platform+'.json',manifest_raw),'0.1.0-candidate.3',source,note='Actual original canonical setup manifest, retaining complete file identities and source.')

browser_inputs=selection['requiredLocators']['originalChromeInputs']
assert set(browser_inputs)=={'archive','inventory'}
for value in browser_inputs.values():assert digest(value['path'])==(value['bytes'],value['sha256'])
browser_inventory=pathlib.Path(browser_inputs['inventory']['path']);browser_archive=pathlib.Path(browser_inputs['archive']['path'])
assert digest(browser_archive)==(195836009,'8aac35011c18f6e2d10696154af89a5728ac2ddd6dc6fad24ffdf243c3fcfd5a')
artifact('chrome-linux',browser_archive,'153.0.8010.12',{'kind':'upstream-archive','revision':'chrome-for-testing/153.0.8010.12/linux64','sha256':digest(browser_inventory)[1]},asset='chrome-linux64-153.0.8010.12.zip',note='Actual complete pinned upstream archive, all303files independently CRC/inventory/physical-byte verified. Includes upstream license files.')
artifact('chrome-linux-inventory',browser_inventory,'153.0.8010.12',{'kind':'upstream-archive','revision':'chrome-for-testing/153.0.8010.12/linux64','sha256':digest(browser_archive)[1]},asset='chrome-linux64-153.0.8010.12-inventory.json',note='Original complete canonical upstream browser inventory.')

compiler_runtime_plan=j(plans/'compiler-plan.json');supervisor=next(x for x in compiler_runtime_plan['files'] if x['path']=='supervisor')
supervisor_locator=capture['runtimeSourceLocators'][supervisor['sourcePath']]
assert digest(supervisor_locator['path'])==(supervisor['bytes'],supervisor['sha256'])
artifact('daemon-supervisor-linux',supervisor_locator['path'],'1.0.0',git_source(digest(plans/'compiler-plan.json')[1]),asset='daemon-supervisor-linux',note='Actual approved fixed nonroot native PID1 supervisor binary selected by original compiler/evaluator runtime plans, unchanged source; runtime image also retains library licenses.')

# Retained actual fixed-peer remote Engine identity, no new live request.
engine_file=pathlib.Path(capture['engineIdentity']['path']);engine_identity=j(engine_file);version=engine_identity['engine']
artifact('docker-engine-linux',engine_file,version['Version'],{'kind':'upstream-archive','revision':'docker-engine/'+version['Version'],'sha256':sha(canon(version))},asset='docker-engine-linux-identity.json',note='Whole actual fixed-peer remote Engine identity retained before daemon stop, bound to matching host engine-info and source. No new Engine call or binary distribution.')

# Validate complete already acquired Engine image exports without extraction or execution.
image_reviews=[]
for role in ['compiler','evaluator']:
    p=pathlib.Path(selection['inputs'][role+'ImageExport']['path']);approved=j(selection['inputs'][role+'ImageMetadata']['path'])
    with tarfile.open(p,'r:') as a:
        members=a.getmembers();assert len(members)<=512
        seen=set()
        for m in members:
            assert m.name not in seen and not m.name.startswith('/') and all(x not in ['','..','.'] for x in m.name.split('/'))
            assert m.isdir() or m.isfile();assert 0<=m.size<=128*1024*1024;seen.add(m.name)
        assert sum(m.size for m in members)<=128*1024*1024
        by={m.name:m for m in members}
        read=lambda name:a.extractfile(by[name]).read()
        for m in members:
            if m.isfile() and m.name.startswith('blobs/sha256/'):
                assert sha(read(m.name))==m.name.rsplit('/',1)[1]
        config_name='blobs/sha256/'+approved['image'].removeprefix('sha256:')
        config=json.loads(read(config_name));assert config['rootfs']['diff_ids']==approved['rootFs']['Layers']
        assert config['config']==approved['config']
        manifest=json.loads(read('manifest.json'));assert len(manifest)==1
        assert manifest[0]['Config']==config_name
        assert manifest[0]['Layers']==['blobs/sha256/'+x.removeprefix('sha256:') for x in approved['rootFs']['Layers']]
        image_reviews.append({'role':role,'image':approved['image'],'rootFs':approved['rootFs'],'members':len(members),'bytes':digest(p)[0],'sha256':digest(p)[1],'configSha256Verified':True,'allBlobContentAddressesVerified':True,'fixedSocketPeerUid':65534,'scope':'GET image export only; no image load/container/process execution.'})
    artifact(role+'-runtime-image',p,'1.0.0',git_source(digest(plans/(role+'-plan.json'))[1]),note='Complete actual Docker/OCI image export, exact approved config SHA/rootFS diffID and every blob hash verified. Original config+all runtime files/licenses retained; inert archive only.')
save('image-export-review.json',image_reviews)

docs=SCRATCH/('M6_410_DOCUMENTATION_AUTHENTICATION_'+COMMIT+'_RUN1')
docs_result=j(docs/'RESULT.json');manifest=docs/'verified/docs/evidence/manifest.json'
assert digest(manifest)[1]==docs_result['expected']['manifestSha256']
artifact('docs-bundle',manifest,'0.1.0',git_source(digest(manifest)[1]),asset='authenticated-docs-manifest.json',note='Actual canonical authenticated source documentation manifest. SHA is the actual manifest identity, not the whole GitHub artifact ZIP digest; whole raw bundle is separately retained.')

# Preserve whole original raw carriers. None are represented as native receipt stdout/stderr.
raws=[]
for platform in ['linux','windows']:
    upper=platform.upper()
    for family,stem,version_ in [('native','FINAL_NATIVE','1.0.0'),('setup-artifact','FINAL_SETUP','0.1.0-candidate.3'),('editor-artifact','FINAL_EDITOR','0.5.0'),('installed-supplement','FINAL_INSTALLED_SUPPLEMENT','1.0.0')]:
        base=({'native':SCRATCH/('M6_410_FINAL_NATIVE_'+upper+'_'+COMMIT+'_RUN1'),'setup-artifact':SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('SETUP-'+platform),'editor-artifact':SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('EDITOR-'+platform),'installed-supplement':SCRATCH/('M6_410_SUPPLEMENT_INPUTS_'+COMMIT+'_RUN1')/upper})[family]
        archive=base/'original-artifact.zip' if family=='native' else base/'retained/artifact.zip'
        metadata=j(base/'artifact.json')
        actual=digest(archive);assert actual==(metadata['size_in_bytes'],metadata['digest'].removeprefix('sha256:'))
        # Workflow head and payload source differ for supplementary operator artifacts.
        if family in ['installed-supplement','native']:
            # Confirm actual tree using preserved local Git object, never guess it.
            import subprocess
            operator=metadata['workflow_run']['head_sha'];tree=subprocess.run(['git','rev-parse',operator+'^{tree}'],cwd=REPO,capture_output=True,text=True,check=True).stdout.strip()
            source={'kind':'git','revision':operator+':'+tree,'sha256':actual[1]}
        else: source=git_source(actual[1])
        artifact(family+'-'+platform,archive,version_,source,asset=family+'-'+platform+'-original.zip',note='Whole unmodified original GitHub Actions artifact ZIP; workflow source/head remains in its separately retained acquisition record. Payload selected actual main 71fd69d; native proof ownership preserved. This ZIP is supporting raw material, never substituted for a receipt stream.')
        raws.append({'role':family+'-'+platform,'artifact':metadata,'acquisition':str(base/'ACQUISITION.json')})
    base=SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('CANONICAL-'+platform)
    artifact('canonical-shared-log-'+platform,base/'ACTUAL_JOB.log','1.0.0',git_source(digest(base/'JOB.json')[1]),asset='canonical-'+platform+'-original-shared-job.log',note='Original complete GitHub shared job log. It merges step output and is not native separate stdout/stderr, nor a unique-test count.')
    reader=pathlib.Path(selection['requiredLocators']['readerAcquisitionRoot'])/('PLATFORM-'+platform)
    import subprocess
    reader_metadata=j(reader/'artifact.json');reader_review=j(selection['inputs']['readerReview']['path'])
    reader_operator=reader_metadata['workflow_run']['head_sha'];assert reader_operator==reader_review['operator'] and reader_metadata['workflow_run']['id']==reader_review['runId']
    reader_tree=subprocess.run(['git','rev-parse',reader_operator+'^{tree}'],cwd=REPO,capture_output=True,text=True,check=True).stdout.strip()
    assert len(reader_tree)==40 and all(x in '0123456789abcdef' for x in reader_tree)
    source={'kind':'git','revision':reader_operator+':'+reader_tree,'sha256':digest(reader/'retained/evidence/zryna/zryna/operator/readonly-evidence/reader.mjs')[1]}
    artifact('native-reader-'+platform,reader/'retained/artifact.zip','1.0.0',source,asset='native-reader-'+platform+'-original.zip',note='Whole original native read-only reader artifact. source revision is operator commit/tree; source.sha256 is actual reader.mjs content hash. Its actual source 71fd69d input corpus and original streams remain distinct; no claim that the reader reran product suites.')
    raws.append({'role':'native-reader-'+platform,'artifact':j(reader/'artifact.json'),'acquisition':str(reader/'ACQUISITION.json')})

for role,name in [('docs-artifact','download-'+str(docs_result['expected']['docsArtifact']['id'])+'.zip'),('docs-gate-artifact','download-'+str(docs_result['expected']['gateArtifact']['id'])+'.zip')]:
    p=docs/name
    artifact(role,p,'0.1.0',git_source(docs_result['expected']['expectationsSha256']),asset=role+'-original.zip',note='Whole unmodified authenticated official source documentation publication artifact; no reinterpretation as native output.')

website=SCRATCH/('M6_410_WEBSITE_PRODUCTION_VERIFICATION_'+COMMIT+'_RUN1')/'RESULT.json'
assert digest(website)==(production_pin['bytes'],production_pin['sha256'])
production=j(website)
assert production['status']=='actual-new-source-production-124-route-content-and-header-check-passed' and production['compilerSourceCommit']==COMMIT
assert production['manifestSha256']==docs_result['expected']['manifestSha256'] and production['quality']['routes']==124 and production['quality']['routesActual200']==124
assert production['quality']['missingRouteActual404'] is True and production['quality']['originalM4MatrixAndAllImportedContentChecks'] is True
checker_path='/workspace/website/tools/docs/check-published-content.mjs'
checker_pin=next(x for x in production['pins'] if x['path']==checker_path)
assert digest(checker_path)==(checker_pin['bytes'],checker_pin['sha256'])
website_source={'kind':'git','revision':production['checkerWebsiteCommit']+':'+production['checkerWebsiteTree'],'sha256':checker_pin['sha256']}
artifact('website-production-proof',website,'1.0.0',website_source,asset='website-production-proof.json',note='Actual production124-route content/header proof. Source revision/hash names the original website checker; compiler 71fd69d/manifest are observed content identity, no provider image/deployment identity or runtime qualification claim.')

# Retain honest material/provenance interpretation and all raw acquisition metadata in one inert capsule.
provenance={'format':'zryna.m6-durable-material-interpretation.v1','version':1,'source':{'commit':COMMIT,'tree':TREE},'artifactMeanings':meanings,'rawArtifacts':raws,'imageExports':image_reviews,'legacyVerification':verified,'documentationAuthentication':docs_result,'scope':'Local create-only inert retention plan. Future URLs are uncreated obligations; no released artifact/publication/qualification capability is asserted.'}
provenance_file=put('durable-material-provenance.json',canon(provenance))
artifact('durable-material-provenance',provenance_file,'1.0.0',git_source(sha(canon(provenance))),note='Explicit original artifact ownership, source/hash interpretation and acquisition metadata; supporting material only.')
pending=[{'role':'playground-compiler','status':'pending-actual-published-and-independently-authenticated-compiler-archive','owner':'parent'}, {'role':'source-composition','status':'pending-actual-publication-bound-source-composition','owner':'parent'}, {'role':'host-policy','status':'pending-actual-publication-bound-reviewed-host-policy','owner':'parent'}]
pins.sort(key=lambda x:x['role'])
save('artifact-pins.ready.json',pins)
save('upload-plan.ready.json',{'status':'local-assets-ready-publication-pending','tag':RAW_TAG,'assets':sorted(uploads.values(),key=lambda x:x['name']),'pending':pending,'actualReadyArtifactRoles':len(pins),'source':{'commit':COMMIT,'tree':TREE}})
save('RESULT.json',{'status':'actual-inert-materials-ready-with-three-parent-publication-pins-pending','readyPins':str(ROOT/'artifact-pins.ready.json'),'uploads':str(ROOT/'upload-plan.ready.json'),'roles':len(pins),'uploadAssets':len(uploads),'uploadBytes':sum(x['bytes'] for x in uploads.values()),'pending':pending,'sourceUnchanged':True,'scope':'No external writes/publications/tags, emitter, Engine request, tests or guests. Uses authenticated retained actual remote capture only.'})
print(json.dumps({'root':str(ROOT),'readyRoles':len(pins),'uploadAssets':len(uploads),'pending':3}))
