"""Local inert durable-material preparation. No publication, executable launch or source mutation."""
import gzip, hashlib, io, json, os, pathlib, stat, sys, tarfile, time, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
ASSETS = pathlib.Path('/tmp/M6_410_DURABLE_MATERIAL_ASSETS_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/assets')
SCRATCH = ROOT.parent
REPO = pathlib.Path('/workspace/zryna')
COMMIT = 'dcef77a79782e91016b9e3e8d528cf21850b9d41'
TREE = '1fa77b9e77185f5fb9d401f1cfb70ee6cc76f963'
RAW_TAG = 'm6-raw-evidence-' + COMMIT + '-1'
URL = 'https://github.com/zryna/zryna/releases/download/' + RAW_TAG + '/'
sha = lambda b: hashlib.sha256(b).hexdigest()

def digest(path):
    p = pathlib.Path(path)
    before = p.lstat()
    assert stat.S_ISREG(before.st_mode) and not p.is_symlink()
    h, count = hashlib.sha256(), 0
    with p.open('rb') as stream:
        while block := stream.read(65536):
            h.update(block); count += len(block)
    after = p.lstat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
    return count,h.hexdigest()

def put(name,data):
    p = ASSETS / name
    with p.open('xb') as stream: stream.write(data)
    p.chmod(0o400)
    return p

def canon(value): return json.dumps(value,separators=(',',':'),ensure_ascii=True).encode()
def save(name,value):
    with (ROOT/name).open('x') as stream: json.dump(value,stream,indent=2);stream.write('\n')
def j(path): return json.loads(pathlib.Path(path).read_bytes())

pins, uploads, meanings = [], {}, {}
def artifact(role,path,version,source,*,asset=None,existing=None,note=''):
    path = pathlib.Path(path); count,hash_ = digest(path)
    name = asset or path.name
    assert count > 0 and count <= 2147483648
    pin = {'role':role,'path':'artifacts/'+name,'version':version,'source':source,'bytes':count,'sha256':hash_,'url':existing or URL+name}
    assert not any(x['role']==role or x['path']==pin['path'] for x in pins)
    pins.append(pin)
    meanings[role] = {'localPath':str(path),'subjectMeaning':note,'retention': 'existing-original-release' if existing else 'future-create-only-raw-release'}
    if not existing:
        if name in uploads: assert uploads[name]['sha256']==hash_
        uploads[name]={'name':name,'localPath':str(path),'bytes':count,'sha256':hash_,'futureUrl':URL+name}
    return pin

def git_source(source_hash):
    return {'kind':'git','revision':COMMIT+':'+TREE,'sha256':source_hash}

legacy = SCRATCH/'M6_410_LEGACY_RESTORED_VERIFICATION_20261018_RUN1'
legacy_inputs = SCRATCH/'M6_410_LEGACY_PUBLISHED_INPUTS_20261018_RUN1'
verified = j(legacy/'RESULT.json'); assert verified['signature'] is True
legacy_source={'kind':'signed-package','revision':'v0.2.3@'+verified['source']['commit'],'sha256':verified['archiveSha256']}
artifact('compiler-release',legacy_inputs/'zryna-0.2.3-x86_64-unknown-linux-gnu.tar.gz','0.2.3',legacy_source,
 existing='https://github.com/zryna/zryna/releases/download/v0.2.3/zryna-0.2.3-x86_64-unknown-linux-gnu.tar.gz',
 note='Original complete immutable signed v0.2.3 Linux compiler archive, authenticated by the retained envelope/bundle. No rebuilding or relabeling as current main.')
for role,name in [('legacy-release-envelope','zryna-release-envelope-v1.json'),('legacy-release-signature','zryna-release-envelope-v1.sigstore.json')]:
    artifact(role,legacy_inputs/name,'0.2.3',legacy_source,existing='https://github.com/zryna/zryna/releases/download/v0.2.3/'+name,note='Original signed legacy provenance, unchanged bytes.')

composition = SCRATCH/'M6_410_MATERIAL_COMPOSITION_20261018_RUN1'
material_runtime = SCRATCH/'M6_410_FINAL_RUNTIME_PREPARATION_20261018_RUN1'
runtime = SCRATCH/'M6_410_RUNTIME_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1'
plans = SCRATCH/('M6_410_RUNTIME_PLANS_'+COMMIT+'_RUN1')
sys.path.insert(0,str(REPO/'examples/playground/restricted/daemon/preparation'))
from emit import run as emit_materials
from engine import Engine

# Retain the full original deterministic ordinary-file emission, compressed inertly.
for role in ['compiler','evaluator']:
    plan_path = composition/(role+'-plan.json'); raw_plan=plan_path.read_bytes()
    out = ASSETS/(role+'-materials.tar.gz')
    with out.open('xb') as raw_out:
        with gzip.GzipFile(fileobj=raw_out,filename='',mtime=0,mode='wb',compresslevel=6) as compressed:
            receipt=emit_materials(str(plan_path),len(raw_plan),sha(raw_plan),compressed)
    out.chmod(0o400)
    expected=j(material_runtime/(role+'-materials.json'))
    assert receipt['archiveSha256']==expected['emission']['archiveSha256']
    assert receipt['archiveBytes']==expected['emission']['archiveBytes']
    manifest=composition/(role+'-manifest.json')
    assert digest(manifest)[1]==expected['root_sha256']
    artifact(role+'-materials',manifest,'1.0.0',{'kind':'git','revision':'5d79dba18117a7ff41ff08d328aa94838c0fce9c:78f42e37111204b1fb20a2363fc41fc23e62b8ef','sha256':sha(raw_plan)},asset=role+'-materials-manifest.json',note='Original complete canonical material manifest; artifact SHA is exactly the approved material root. Full deterministic original archive is separately retained below.')
    artifact(role+'-materials-archive',out,'1.0.0',{'kind':'git','revision':'5d79dba18117a7ff41ff08d328aa94838c0fce9c:78f42e37111204b1fb20a2363fc41fc23e62b8ef','sha256':digest(manifest)[1]},note='Gzip transport of original unchanged emitter USTAR; decompressed archive bytes/hash exactly match the original populated-volume emission; includes all material files/licenses.')
    save(role+'-material-emission.json',receipt)

def small_tar(name, entries):
    out=ASSETS/name
    with out.open('xb') as raw_out:
        with gzip.GzipFile(fileobj=raw_out,filename='',mtime=0,mode='wb',compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.USTAR_FORMAT) as a:
                for rel,path,mode in entries:
                    size,_=digest(path); h=tarfile.TarInfo(rel);h.mode=mode;h.size=size;h.uid=h.gid=h.mtime=0
                    with pathlib.Path(path).open('rb') as stream:a.addfile(h,stream)
    out.chmod(0o400);return out

node_tar=small_tar('node-22.22.1-linux-x64.tar.gz',[(x,legacy/'extracted'/x,0o555 if x.endswith('/node') else 0o444) for x in ['runtime/node/bin/node','licenses/node-LICENSE']])
artifact('node-runtime',node_tar,'22.22.1',legacy_source,note='Exact original signed legacy Node binary plus Node license, repackaged inertly; inner binary124674920bytes SHA243fd8938011479f41b3de101842150fa990f33fbbb3f7aabd330857f2d79e1d.')
compiler_plan=j(composition/'compiler-plan.json')
provider_entries=[(x['path'],pathlib.Path(x['sourcePath']),x['mode']) for x in compiler_plan['files'] if x['path'].startswith('lib/zryna/bootstrap/') or x['path'].startswith('licenses/typescript')]
provider_tar=small_tar('signed-legacy-provider-6.0.2.tar.gz',provider_entries)
artifact('provider',provider_tar,'6.0.2',legacy_source,note='Entire actually used signed legacy bootstrap/provider closure and licenses; TypeScript6 compatibility package6.0.2 delegates to original TypeScript package6.0.3. No claim that both upstream package versions are identical.')

# Exact same-source setup candidates and individually selected original payloads.
for platform in ['linux','windows']:
    upper=platform.upper();filename='zryna-setup-0.1.0-candidate.3-x86_64-'+('unknown-linux-gnu.tar.gz' if platform=='linux' else 'pc-windows-msvc.zip')
    p=SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('SETUP-'+platform)/'retained/evidence'/filename
    if platform=='linux':
        with tarfile.open(p,'r:gz') as a:
            members={x.name:x for x in a.getmembers()}; prefix=filename.removesuffix('.tar.gz')+'/'
            read=lambda n:a.extractfile(members[prefix+n]).read()
            manifest_raw=read('setup.json'); server_raw=read('bin/zryna-language-server'); vsix_raw=read('editor/zryna-0.5.0.vsix')
    else:
        with zipfile.ZipFile(p) as a:
            prefix=filename.removesuffix('.zip')+'/'
            manifest_raw=a.read(prefix+'setup.json'); server_raw=a.read(prefix+'bin/zryna-language-server.exe'); vsix_raw=a.read(prefix+'editor/zryna-0.5.0.vsix')
    manifest=json.loads(manifest_raw);assert manifest['sourceCommit']==COMMIT and manifest['sourceTree']==TREE
    source=git_source(sha(manifest_raw))
    artifact('setup-'+platform,p,'0.1.0-candidate.3',source,note='Actual full same-source review-candidate portable setup archive. Includes nested legacy compiler, Node/provider closure, licenses, server, VSIX and provenance. No independent-clean-machine or production setup admission claim.')
    server_name='zryna-language-server-'+platform+('.exe' if platform=='windows' else '')
    for rel,data in [('bin/zryna-language-server'+('.exe' if platform=='windows' else ''),server_raw),('editor/zryna-0.5.0.vsix',vsix_raw)]:
        pin=next(x for x in manifest['files'] if x['path']==rel);assert len(data)==pin['size'] and sha(data)==pin['sha256']
    artifact('server-'+platform,put(server_name,server_raw),'0.5.0',source,note='Exact installed native language server binary selected from the authenticated same-source portable setup manifest.')
    artifact('extension' if platform=='linux' else 'extension-windows',put('zryna-0.5.0-'+platform+'.vsix',vsix_raw),'0.5.0',source,note='Exact actual platform-selected installed VSIX bytes. Windows build has a different ZIP digest and is retained as a separate role; no platform identity substitution.')
    artifact('setup-manifest-'+platform,put('setup-manifest-'+platform+'.json',manifest_raw),'0.1.0-candidate.3',source,note='Actual original canonical setup manifest, retaining complete file identities and source.')

browser=REPO/'.zryna/cache/scalar-browser-linux-x64-153.0.8010.12'
browser_inventory=browser/'inventory.json'; browser_archive=browser/'archive.zip'
assert digest(browser_archive)==(195836009,'8aac35011c18f6e2d10696154af89a5728ac2ddd6dc6fad24ffdf243c3fcfd5a')
artifact('chrome-linux',browser_archive,'153.0.8010.12',{'kind':'upstream-archive','revision':'chrome-for-testing/153.0.8010.12/linux64','sha256':digest(browser_inventory)[1]},asset='chrome-linux64-153.0.8010.12.zip',note='Actual complete pinned upstream archive, all303files independently CRC/inventory/physical-byte verified. Includes upstream license files.')
artifact('chrome-linux-inventory',browser_inventory,'153.0.8010.12',{'kind':'upstream-archive','revision':'chrome-for-testing/153.0.8010.12/linux64','sha256':digest(browser_archive)[1]},asset='chrome-linux64-153.0.8010.12-inventory.json',note='Original complete canonical upstream browser inventory.')

compiler_runtime_plan=j(plans/'compiler-plan.json');supervisor=next(x for x in compiler_runtime_plan['files'] if x['path']=='supervisor')
assert digest(supervisor['sourcePath'])==(supervisor['bytes'],supervisor['sha256'])
artifact('daemon-supervisor-linux',supervisor['sourcePath'],'1.0.0',git_source(digest(plans/'compiler-plan.json')[1]),asset='daemon-supervisor-linux',note='Actual approved fixed nonroot native PID1 supervisor binary selected by original compiler/evaluator runtime plans, unchanged source; runtime image also retains library licenses.')

# Read-only peer-authenticated Engine identity. Its observation is a material, not an execution receipt.
engine=Engine(65534,seconds=30);version=engine.json('GET','/version')
engine_identity={'format':'zryna.m6-engine-identity-material.v1','version':1,'observation':'read-only fixed /var/run/docker.sock, peer UID65534, API/v1.49/version','engine':version,'scope':'Identity observation only. No container/image/material effects or publication approval.'}
engine_file=put('docker-engine-linux-identity.json',canon(engine_identity))
artifact('docker-engine-linux',engine_file,version['Version'],{'kind':'upstream-archive','revision':'docker-engine/'+version['Version'],'sha256':sha(canon(version))},note='Actual Engine version/OS/architecture/build identity read from the authenticated fixed local daemon; this JSON is an identity observation, not an Engine binary distribution.')

# Validate complete already acquired Engine image exports without extraction or execution.
image_reviews=[]
for role in ['compiler','evaluator']:
    p=ASSETS/(role+'-runtime-image.tar');approved=j(runtime/(role+'-image.json'))
    with tarfile.open(p,'r:') as a:
        members=a.getmembers();assert len(members)<=512
        seen=set()
        for m in members:
            assert m.name not in seen and not m.name.startswith('/') and all(x not in ['','..','.'] for x in m.name.split('/'))
            assert m.isdir() or m.isfile();assert 0<=m.size<=128*1024*1024;seen.add(m.name)
        assert sum(m.size for m in members)<=128*1024*1024
        by={m.name:m for m in members}
        read=lambda name:a.extractfile(by[name]).read()
        for m in members:
            if m.isfile() and m.name.startswith('blobs/sha256/'):
                assert sha(read(m.name))==m.name.rsplit('/',1)[1]
        config_name='blobs/sha256/'+approved['image'].removeprefix('sha256:')
        config=json.loads(read(config_name));assert config['rootfs']['diff_ids']==approved['rootFs']['Layers']
        assert config['config']==approved['config']
        manifest=json.loads(read('manifest.json'));assert len(manifest)==1
        assert manifest[0]['Config']==config_name
        assert manifest[0]['Layers']==['blobs/sha256/'+x.removeprefix('sha256:') for x in approved['rootFs']['Layers']]
        image_reviews.append({'role':role,'image':approved['image'],'rootFs':approved['rootFs'],'members':len(members),'bytes':digest(p)[0],'sha256':digest(p)[1],'configSha256Verified':True,'allBlobContentAddressesVerified':True,'fixedSocketPeerUid':65534,'scope':'GET image export only; no image load/container/process execution.'})
    artifact(role+'-runtime-image',p,'1.0.0',git_source(digest(plans/(role+'-plan.json'))[1]),note='Complete actual Docker/OCI image export, exact approved config SHA/rootFS diffID and every blob hash verified. Original config+all runtime files/licenses retained; inert archive only.')
save('image-export-review.json',image_reviews)

docs=SCRATCH/('M6_410_DOCUMENTATION_AUTHENTICATION_'+COMMIT+'_RUN1')
docs_result=j(docs/'RESULT.json');manifest=docs/'verified/docs/evidence/manifest.json'
assert digest(manifest)[1]==docs_result['expected']['manifestSha256']
artifact('docs-bundle',manifest,'0.1.0',git_source(digest(manifest)[1]),asset='authenticated-docs-manifest.json',note='Actual canonical authenticated source documentation manifest. SHA is the actual manifest identity, not the whole GitHub artifact ZIP digest; whole raw bundle is separately retained.')

# Preserve whole original raw carriers. None are represented as native receipt stdout/stderr.
raws=[]
for platform in ['linux','windows']:
    upper=platform.upper()
    for family,stem,version_ in [('native','FINAL_NATIVE','1.0.0'),('setup-artifact','FINAL_SETUP','0.1.0-candidate.3'),('editor-artifact','FINAL_EDITOR','0.5.0'),('installed-supplement','FINAL_INSTALLED_SUPPLEMENT','1.0.0')]:
        base=({'native':SCRATCH/('M6_410_FINAL_NATIVE_'+upper+'_'+COMMIT+'_RUN1'),'setup-artifact':SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('SETUP-'+platform),'editor-artifact':SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('EDITOR-'+platform),'installed-supplement':SCRATCH/('M6_410_SUPPLEMENT_INPUTS_'+COMMIT+'_RUN1')/upper})[family]
        archive=base/'original-artifact.zip' if family=='native' else base/'retained/artifact.zip'
        metadata=j(base/'artifact.json')
        actual=digest(archive);assert actual==(metadata['size_in_bytes'],metadata['digest'].removeprefix('sha256:'))
        # Workflow head and payload source differ for supplementary operator artifacts.
        if family in ['installed-supplement','native']:
            # Confirm actual tree using preserved local Git object, never guess it.
            import subprocess
            operator=metadata['workflow_run']['head_sha'];tree=subprocess.run(['git','rev-parse',operator+'^{tree}'],cwd=REPO,capture_output=True,text=True,check=True).stdout.strip()
            source={'kind':'git','revision':operator+':'+tree,'sha256':actual[1]}
        else: source=git_source(actual[1])
        artifact(family+'-'+platform,archive,version_,source,asset=family+'-'+platform+'-original.zip',note='Whole unmodified original GitHub Actions artifact ZIP; workflow source/head remains in its separately retained acquisition record. Payload selected actual main dcef77a; native proof ownership preserved. This ZIP is supporting raw material, never substituted for a receipt stream.')
        raws.append({'role':family+'-'+platform,'artifact':metadata,'acquisition':str(base/'ACQUISITION.json')})
    base=SCRATCH/('M6_410_CI_INPUTS_'+COMMIT+'_RUN1')/('CANONICAL-'+platform)
    artifact('canonical-shared-log-'+platform,base/'ACTUAL_JOB.log','1.0.0',git_source(digest(base/'JOB.json')[1]),asset='canonical-'+platform+'-original-shared-job.log',note='Original complete GitHub shared job log. It merges step output and is not native separate stdout/stderr, nor a unique-test count.')
    reader=SCRATCH/('M6_410_NATIVE_READER_ACQUISITION_'+COMMIT+'_RUN1')/('PLATFORM-'+platform)
    source={'kind':'git','revision':'5270e95eb53d339a15bffb9a60d29415b3eb1b48:0dd8be2d06e0223029afd15a991c2c3f0150d38d','sha256':digest(reader/'retained/evidence/zryna/zryna/operator/readonly-evidence/reader.mjs')[1]}
    artifact('native-reader-'+platform,reader/'retained/artifact.zip','1.0.0',source,asset='native-reader-'+platform+'-original.zip',note='Whole original native read-only reader artifact. source revision is operator commit/tree; source.sha256 is actual reader.mjs content hash. Its actual source dcef77a input corpus and original streams remain distinct; no claim that the reader reran product suites.')
    raws.append({'role':'native-reader-'+platform,'artifact':j(reader/'artifact.json'),'acquisition':str(reader/'ACQUISITION.json')})

for role,name in [('docs-artifact','download-'+str(docs_result['expected']['docsArtifact']['id'])+'.zip'),('docs-gate-artifact','download-'+str(docs_result['expected']['gateArtifact']['id'])+'.zip')]:
    p=docs/name
    artifact(role,p,'0.1.0',git_source(docs_result['expected']['expectationsSha256']),asset=role+'-original.zip',note='Whole unmodified authenticated official source documentation publication artifact; no reinterpretation as native output.')

website=SCRATCH/('M6_410_WEBSITE_PRODUCTION_VERIFICATION_'+COMMIT+'_RUN1')/'RESULT.json'
assert digest(website)==(4670,'1f2923e6a457ca15e7497ab0f978acd486152c73dd1c4f7f8de516341697042b')
artifact('website-production-proof',website,'1.0.0',{'kind':'git','revision':'fcd26ab6dfc9aab6879062f698fd2b4bb717b409:a0aff6f75022e9ec641b9d846342a9cad5ceb0a4','sha256':'cff9b030c51a2443fcc2e2e9809c9794be7c8415d5d069a874885eca794c259c'},asset='website-production-proof.json',note='Actual production124-route content/header proof. Source revision/hash names the original website checker; compiler dcef/manifest are observed content identity, no provider image/deployment identity or runtime qualification claim.')

# Retain honest material/provenance interpretation and all raw acquisition metadata in one inert capsule.
provenance={'format':'zryna.m6-durable-material-interpretation.v1','version':1,'source':{'commit':COMMIT,'tree':TREE},'artifactMeanings':meanings,'rawArtifacts':raws,'imageExports':image_reviews,'legacyVerification':verified,'documentationAuthentication':docs_result,'scope':'Local create-only inert retention plan. Future URLs are uncreated obligations; no released artifact/publication/qualification capability is asserted.'}
provenance_file=put('durable-material-provenance.json',canon(provenance))
artifact('durable-material-provenance',provenance_file,'1.0.0',git_source(sha(canon(provenance))),note='Explicit original artifact ownership, source/hash interpretation and acquisition metadata; supporting material only.')
pending=[{'role':'playground-compiler','status':'pending-actual-published-and-independently-authenticated-compiler-archive','owner':'parent'}, {'role':'source-composition','status':'pending-actual-publication-bound-source-composition','owner':'parent'}, {'role':'host-policy','status':'pending-actual-publication-bound-reviewed-host-policy','owner':'parent'}]
pins.sort(key=lambda x:x['role'])
save('artifact-pins.ready.json',pins)
save('upload-plan.ready.json',{'status':'local-assets-ready-publication-pending','tag':RAW_TAG,'assets':sorted(uploads.values(),key=lambda x:x['name']),'pending':pending,'actualReadyArtifactRoles':len(pins),'source':{'commit':COMMIT,'tree':TREE}})
save('RESULT.json',{'status':'actual-inert-materials-ready-with-three-parent-publication-pins-pending','readyPins':str(ROOT/'artifact-pins.ready.json'),'uploads':str(ROOT/'upload-plan.ready.json'),'roles':len(pins),'uploadAssets':len(uploads),'uploadBytes':sum(x['bytes'] for x in uploads.values()),'pending':pending,'sourceUnchanged':True,'scope':'No external writes/publications/tags, no tests/guest/container launches; read-only Engine version and bounded image export only.'})
print(json.dumps({'root':str(ROOT),'readyRoles':len(pins),'uploadAssets':len(uploads),'pending':3}))
