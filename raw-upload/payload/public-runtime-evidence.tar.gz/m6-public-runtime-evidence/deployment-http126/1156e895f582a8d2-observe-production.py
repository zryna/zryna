"""Actual fresh production identity then one original full route checker. No provider writes."""
from pathlib import Path
import argparse,datetime,difflib,hashlib,json,re,subprocess,time
R=Path(__file__).resolve().parent;W=Path('/workspace/website')
C='71fd69d99a39c22bdf262d1655a032aa76221f3e';T='351da60bd4037e0f96c286045c8943f41fa99b03';M='697b7a79e08aa16542e95ca6902c8efa1a030a29ba0730a85795886e44a2e66b'
# Root must independently select the actual merged website identity after fresh
# API merge/main proof. HEAD is checked against these inputs, never used to select them.
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--website-commit',required=True,help='Actual merged website commit independently selected after root fresh API proof')
parser.add_argument('--website-tree',required=True,help='Actual merged website tree independently selected after root fresh API proof')
args=parser.parse_args();B=args.website_commit;BT=args.website_tree
assert re.fullmatch('[a-f0-9]{40}',B) and re.fullmatch('[a-f0-9]{40}',BT),'explicit complete independently selected merged website commit/tree required'
ORIGIN='https://zryna.com';CHECKER=W/'tools/docs/check-published-content.mjs';ORIGINAL=Path('/workspace/scratch/m6-410-production-check-curl-fetch-20261018.mjs');NODE='/workspace/scratch/M6_410_WEBSITE_TOOLCHAIN_20261018_RUN1/node'
sha=lambda b:hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
 raw=value if isinstance(value,bytes)else(json.dumps(value,indent=2)+'\n').encode()
 with(R/name).open('xb')as f:f.write(raw)
 (R/name).chmod(0o400)
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def js(p):return json.loads(Path(p).read_bytes())
def git(*args):return subprocess.check_output(['git','--no-replace-objects','--no-optional-locks','-c','core.fsmonitor=false',*args],cwd=W,timeout=15)
def source():
 return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all').decode()}
def guard():
 assert source()=={'head':B,'tree':BT,'status':''}
 assert sha(CHECKER.read_bytes())=='7705bb9f2d7e78d0bfed16d5aad60e3a7bda4570aff541a34b8e9cf4de4ac47e'
 assert git('show','HEAD:tools/docs/check-published-content.mjs')==CHECKER.read_bytes()
 lock=js(W/'src/content/compiler-data/compiler-docs.lock.json');assert lock['source']['commit']==C and lock['manifestSha256']==M
 assert sha((W/'src/content/compiler-data/next/manifest.json').read_bytes())==M
 manifest=js(W/'src/content/compiler-data/next/manifest.json');assert manifest['source']==lock['source'] and manifest['source']['repository']=='https://github.com/zryna/zryna' and manifest['source']['commit']==C
 return lock
def headers(p):
 raw=p.read_bytes();blocks=raw.decode('iso-8859-1').strip().split('\r\n\r\n');lines=blocks[-1].splitlines();match=re.fullmatch(r'HTTP/[0-9.]+ ([0-9]{3})(?: .*)?',lines[0]);assert match
 values={}
 for line in lines[1:]:
  key,value=line.split(':',1);values.setdefault(key.lower(),[]).append(value.strip())
 return int(match.group(1)),values
def main():
 lock=guard();save('SOURCE_BEFORE.json',source())
 original=ORIGINAL.read_bytes();assert sha(original)=='92b3ab508397a8db9a56145affa835aebc62c648f6475c36e65ad627f6ada33d'
 before="/workspace/scratch/M6_410_WEBSITE_PRODUCTION_HTTP_20261018_RUN3";after=str(R/'HTTP');assert original.decode().count(before)==1
 adapted=original.decode().replace(before,after).encode();save('curl-fetch-check.mjs',adapted)
 patch=''.join(difflib.unified_diff(original.decode().splitlines(True),adapted.decode().splitlines(True),fromfile=str(ORIGINAL),tofile=str(R/'curl-fetch-check.mjs')))
 save('ADAPTER_BINDING.json',{'original':pin(ORIGINAL),'adapted':pin(R/'curl-fetch-check.mjs'),'originalChecker':pin(CHECKER),'onlySubstitution':{'before':before,'after':after},'diff':patch,'checkerSource':{'commit':B,'tree':BT},'checkerChangeAlreadyReviewed':'Whole current source-E checker independently pinned; adapter changes only retained output root. Original routes/security/transport/limits unchanged.'})
 save('INTENT.json',{'at':now(),'compiler':{'commit':C,'tree':T},'website':{'commit':B,'tree':BT},'manifestSha256':M,'origin':ORIGIN,'identityIntervalSeconds':60,'identityMaximumSeconds':900,'fullOriginalCheckerInvocationsMaximum':1,'scope':'Actual read-only HTTP content/header observation; no provider deployment/image identity query or inference, no Git/provider configuration or writes.'})
 end=time.monotonic()+900;number=0;firstMismatch=None;matched=None
 while time.monotonic()<end:
  number+=1;assert number<=15;stem='IDENTITY-'+str(number).zfill(3);started=now()
  command=['curl','--silent','--show-error','--max-time','20','--max-filesize','2097152','--dump-header',str(R/(stem+'.headers')),'--output',str(R/(stem+'.body')),'--url',ORIGIN+'/reference/compiler-status/']
  with(R/(stem+'.stdout')).open('xb')as out,(R/(stem+'.stderr')).open('xb')as err: result=subprocess.run(command,stdout=out,stderr=err,timeout=25)
  status=None;observed={};body=b''
  if(R/(stem+'.headers')).is_file()and(R/(stem+'.headers')).stat().st_size:
   try:status,observed=headers(R/(stem+'.headers'))
   except Exception:pass
  if(R/(stem+'.body')).is_file():body=(R/(stem+'.body')).read_bytes()
  exact=result.returncode==0 and status==200 and C.encode()in body and M.encode()in body
  record={'at':started,'completedAt':now(),'command':command,'curlExitCode':result.returncode,'status':status,'sourceCommitPresent':C.encode()in body,'manifestPresent':M.encode()in body,'matched':exact,'captures':[pin(R/(stem+ext))for ext in ['.headers','.body','.stdout','.stderr']if(R/(stem+ext)).is_file()]}
  save(stem+'.json',record);print(json.dumps({'event':'actual-production-identity','observation':number,'status':status,'curlExitCode':result.returncode,'matched':exact}),flush=True)
  if exact:
   matched=pin(R/(stem+'.json'));save('IDENTITY_MATCHED.json',record);break
  if firstMismatch is None:firstMismatch=pin(R/(stem+'.json'))
  remaining=end-time.monotonic()
  if remaining<=0:break
  until=time.monotonic()+min(60,remaining)
  while time.monotonic()<until:time.sleep(min(10,until-time.monotonic()))
 assert matched is not None,'Bounded15minute external deployment convergence ended without exact compiler/manifest identity; no checker run'
 guard();command=[NODE,str(R/'curl-fetch-check.mjs')];started=now()
 save('CHECK_COMMAND.json',{'argv':command,'cwd':str(W),'startedAt':started,'trustedOuterBudgetSeconds':600,'innerOriginalCurlLimitSeconds':20,'attempts':1})
 print(json.dumps({'event':'one-original-production-check-started','at':started}),flush=True)
 try:
  with(R/'check.stdout').open('xb')as out,(R/'check.stderr').open('xb')as err: actual=subprocess.run(command,cwd=W,stdout=out,stderr=err,timeout=600)
 except subprocess.TimeoutExpired:
  save('CHECK_COMPLETE.json',{'exitCode':None,'timeout':True,'completedAt':now(),'rerun':False});raise
 finished=now();save('CHECK_COMPLETE.json',{'exitCode':actual.returncode,'startedAt':started,'completedAt':finished,'rerun':False})
 assert actual.returncode==0,('Original full checker failed; no rerun',actual.returncode)
 report=json.loads((R/'check.stdout').read_bytes());transport=js(R/'HTTP/TRANSPORT.json')
 assert report['result']=='passed'and report['mode']=='--origin'and report['origin']==ORIGIN
 assert report['sourceCommit']==C and report['manifestSha256']==M and report['checkerWebsiteCommit']==B and report['checkerWebsiteTree']==BT
 assert report['observedDeployment']is None and report['routes']==124 and len(report['responses'])==124 and all(x['status']==200 for x in report['responses'])
 assert transport['status']=='passed'and transport['adapterSha256']==sha(adapted)and transport['originalCheckerSha256']==sha(CHECKER.read_bytes())and len(transport['rows'])==126
 for i,row in enumerate(transport['rows']):
  stem=R/'HTTP'/('request-'+str(i).zfill(3));body=stem.with_suffix('.body');hp=stem.with_suffix('.headers');ep=stem.with_suffix('.stderr')
  assert body.is_file()and hp.is_file()and ep.is_file()
  b=body.read_bytes();hb=hp.read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256']and sha(hb)==row['headerSha256']
  status,values=headers(hp);assert status==row['status']
  if i<124:
   assert report['responses'][i]['url']==row['url']and report['responses'][i]['bytes']==len(b)and report['responses'][i]['sha256']==sha(b)and status==200
  if i==124:assert row['url']==ORIGIN+'/definitely-missing'and status==404
  if i==125:assert row['url']=='http://zryna.com/'and status in[301,308]and values['location']==[ORIGIN+'/']and report['observedHttpRedirect']=={'status':status,'location':ORIGIN+'/'}
 guard();save('SOURCE_AFTER.json',source())
 result={'status':'actual-new-source-production-124-route-content-and-header-check-passed','at':now(),'origin':ORIGIN,'compilerSourceCommit':C,'manifestSha256':M,'checkerWebsiteCommit':B,'checkerWebsiteTree':BT,'initialOldProductionIdentityRetained':firstMismatch,'actualNewProductionIdentity':matched,'convergenceObservations':number,'intervalSeconds':60,'originalFullCheckerInvocations':1,'quality':{'routes':124,'routesActual200':124,'missingRouteActual404':True,'httpToHttpsRedirect':report['observedHttpRedirect'],'securityHeadersCheckedByOriginal':True,'observedHsts':report['observedHsts'],'originalM4MatrixAndAllImportedContentChecks':True},'rawRetention':{'root':str(R/'HTTP'),'actualRequests':126,'completeBodies':126,'completeHeaders':126,'allBodyAndHeaderPinsRehashedAgainstOriginalTransport':True,'transport':pin(R/'HTTP/TRANSPORT.json')},'pins':[pin(R/n)for n in ['INTENT.json','ADAPTER_BINDING.json','curl-fetch-check.mjs','CHECK_COMMAND.json','CHECK_COMPLETE.json','check.stdout','check.stderr','SOURCE_BEFORE.json','SOURCE_AFTER.json']]+[pin(CHECKER)],'productionDeploymentIdentity':None,'scope':'Actual HTTPS content/header observation against exact clean merged checker/lock/source. Provider deployment/image identity not queried or inferred. Historical C production proof not reused. This does not establish compiler publication/private68/runtime/final23 acceptance or410closure.','effects':{'gitWrites':0,'providerWrites':0,'deploymentTriggers':0,'apiConfigurationChanges':0,'secretsRequested':0,'originalFullCheckerInvocations':1}}
 save('RESULT.json',result);print(json.dumps({'event':'actual-production-proof-complete','result':pin(R/'RESULT.json'),'checkerWebsiteCommit':B,'compilerSourceCommit':C,'responses':126,'observedHsts':report['observedHsts']}),flush=True)
try:main()
except BaseException as error:
 save('FAILURE.json',{'status':'failed-no-production-proof-or-rerun','at':now(),'reason':str(error)[:4000],'capturedRawResponsesPreserved':True});raise
