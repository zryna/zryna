// Trusted transport adapter: original checker remains unchanged; curl uses session proxy/CA.
import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,openSync,closeSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='/workspace/scratch/M6_410_WEBSITE_PRODUCTION_VERIFICATION_71fd69d99a39c22bdf262d1655a032aa76221f3e_RUN1/HTTP';mkdirSync(root,{mode:0o700});
const fd=openSync(root+'/TRANSPORT.json','wx',0o400),rows=[];
const target='/workspace/website/tools/docs/check-published-content.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
globalThis.fetch=async(input,options={})=>{
 const url=String(input);assert(/^https?:\/\/zryna\.com\/[a-zA-Z0-9_./-]*$/.test(url));assert(['error','manual'].includes(options.redirect));
 const stem=root+'/request-'+String(rows.length).padStart(3,'0'),started=new Date().toISOString();
 const stderr=openSync(stem+'.stderr','wx',0o400);
 const child=spawn('curl',['--silent','--show-error','--max-time','20','--max-filesize','2097152','--dump-header',stem+'.headers','--output',stem+'.body','--url',url],{stdio:['ignore','ignore',stderr],shell:false});closeSync(stderr);
 const end=await new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));
 assert.deepEqual(end,{code:0,signal:null});const rawHeaders=readFileSync(stem+'.headers','utf8'),body=readFileSync(stem+'.body');assert(body.length<=2097152);
 const blocks=rawHeaders.trim().split(/\r?\n\r?\n/),block=blocks.at(-1).split(/\r?\n/),line=block.shift();const match=/^HTTP\/[0-9.]+ ([0-9]{3})/.exec(line);assert(match);
 const status=Number(match[1]),headers=new Headers();for(const line of block){const p=line.indexOf(':');assert(p>0);headers.append(line.slice(0,p),line.slice(p+1).trim())}
 rows.push({url,started,completed:new Date().toISOString(),status,bytes:body.length,sha256:hash(body),headerSha256:hash(Buffer.from(rawHeaders))});
 if(options.redirect==='error')assert(status<300||status>=400,'Actual redirect rejected');
 return new Response(body,{status,headers});
};
let status='failed';try{
 process.argv=[process.execPath,target,'--origin','https://zryna.com'];await import(pathToFileURL(target));status='passed';
}finally{writeFileSync(fd,JSON.stringify({status,adapterSha256:hash(readFileSync(import.meta.filename)),originalCheckerSha256:hash(readFileSync(target)),rows},null,2)+'\n');closeSync(fd)}
