{const f=await import('node:fs'),h=await import('node:crypto'),u=1000,p="/workspace/scratch/M6_410_EPHEMERAL_HOST_39290523675_1/runtime-observations/caller/.identities/11-material-denials.node.json";
if(process.env.M6_410_CALLER_IDENTITY_PATH!==p)throw Error('Fixed caller identity path');
const raw=f.readFileSync('/proc/self/status','utf8'),keys=['Uid','Gid','Groups','CapInh','CapPrm','CapEff','CapBnd','CapAmb','NoNewPrivs'],status={};
if(Buffer.byteLength(raw)>65536)throw Error('Bounded caller identity');for(const key of keys){const match=raw.match(new RegExp('^'+key+':[\\t ]*(.*)$','m'));if(!match)throw Error('Missing identity '+key);status[key]=match[1].trim();}
const groups=status.Groups?status.Groups.split(/\s+/).map(Number):[];
if(![process.getuid(),process.geteuid(),process.getgid(),process.getegid()].every(x=>x===u)||groups.length||status.Uid.split(/\s+/).some(x=>Number(x)!==u)||status.Gid.split(/\s+/).some(x=>Number(x)!==u)||keys.slice(3,8).some(k=>BigInt('0x'+status[k])!==0n)||status.NoNewPrivs!=='1')throw Error('Actual nonroot zero-capability NNP caller required');
f.writeFileSync(p,JSON.stringify({pid:process.pid,parentPid:process.ppid,uid:process.getuid(),euid:process.geteuid(),gid:process.getgid(),egid:process.getegid(),groups,nodeGetgroups:process.getgroups(),status,statusSha256:h.createHash('sha256').update(raw).digest('hex'),rawStatus:raw})+'\n',{flag:'wx',mode:0o400});}
// Prepared private negative operator. It is not a source launcher or publication capability.
import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,openSync,closeSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {createDaemonBridge} from '/workspace/zryna/examples/playground/restricted/daemon/bridge.mjs';
import {decodeCompilation} from '/workspace/zryna/examples/playground/restricted/protocol.mjs';
const here='/workspace/scratch/M6_410_EPHEMERAL_HOST_39290523675_1/candidate/caller-view/runtime-operators/runtime';
const root='/workspace/scratch/M6_410_EPHEMERAL_HOST_39290523675_1/runtime-observations/caller/M6_410_ACTUAL_MATERIAL_DENIAL_71fd69d99a39c22bdf262d1655a032aa76221f3e_RUN1';
assert.equal(process.argv.length,2);assert.equal(process.getuid(),1000);mkdirSync(root,{mode:0o700});
const fd=openSync(root+'/RESULT.json','wx',0o400),sha=b=>createHash('sha256').update(b).digest('hex');
const save=(name,value)=>writeFileSync(root+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o400});
const reviewed=JSON.parse(readFileSync('/workspace/scratch/M6_410_EPHEMERAL_HOST_39290523675_1/candidate/caller-view/reviewed-launcher.candidate.json'));
const original=JSON.parse(readFileSync(reviewed.approval.path));const helper=here+'/material-denial-observer.py';
const translator='/workspace/scratch/M6_410_EPHEMERAL_HOST_39290523675_1/candidate/caller-view/runtime-operators/fixed-imports/m6-410-compose-daemon-policy-20261018.py';
function digest(record){
 const code="import importlib.util,json,sys; s=importlib.util.spec_from_file_location('p',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(m.digest(json.load(sys.stdin)))";
 const child=spawnSync("/workspace/scratch/M6_410_REMOTE_OPERATOR_39290523675_1/seed/m6-remote-runtime-seed/host-python/bin/python3.12",['-B','-c',code,translator],{input:JSON.stringify(record),encoding:'utf8',timeout:3000,maxBuffer:65536,shell:false});
 assert.equal(child.status,0,child.stderr);const value=child.stdout.trim();assert(/^[a-f0-9]{64}$/.test(value));return value;
}
function pin(path){const data=readFileSync(path);return {path,bytes:data.length,sha256:sha(data),ownerUid:statSync(path).uid};}
const sourceRequest={version:1,revision:801,source:'export function value(): i32 { return 42; }\n'};
const authorityFor=record=>({compilerSha256:record.compiler_executable_sha256,toolkitSha256:record.composition_sha256,policySha256:record.policy_sha256,bindingTemplateSha256:record.binding_template_sha256});
function payloadFor(frame,metadata,record){const authority=authorityFor(record);return {sourceRequest,frameBytes:frame,selection:{revision:801,sourceSha256:metadata.sourceSha256,componentSha256:metadata.identity.componentSha256,logical:'value',args:[]},receipt:{revision:801,sourceSha256:metadata.sourceSha256,frameSha256:sha(frame),compilerSha256:authority.compilerSha256,toolkitSha256:authority.toolkitSha256,policySha256:authority.policySha256},authority};}
let result={status:'failed',rows:[],preparedSource:reviewed.source,compilerSha256:reviewed.compiler.sha256};let originalBridge;
save('INTENT.json',{scriptSha256:sha(readFileSync(import.meta.filename)),helperSha256:sha(readFileSync(helper)),translatorSha256:sha(readFileSync(translator)),scope:'Six deliberately invalid private operator approvals only. Actual original native binary/directbridge. Never modify sealed volumes, images, source, limits, socket, or policy. Provenance failures before creation and audit failures before source upload. No public capability.'});
try{
 assert.equal(digest(original),original.policy_sha256,'Reviewed Python translation must equal original already-admitted Rust policy digest');
 originalBridge=createDaemonBridge({compiler:reviewed.compiler,approval:reviewed.approval});
 const frame=await originalBridge.compile(Buffer.from(JSON.stringify(sourceRequest)),undefined,'1'.repeat(64));await originalBridge.finish('1'.repeat(64),false);
 const compiled=await decodeCompilation(frame,{revision:801,source:sourceRequest.source,witSha256:reviewed.witSha256});assert.equal(compiled.metadata.status,'compiled');
 writeFileSync(root+'/pristine.frame',frame,{flag:'wx',mode:0o400});save('pristine.request.json',sourceRequest);
 const specs=[
  ['compiler-wrong-count','compiler',true,r=>r.compiler_materials.files++],
  ['evaluator-wrong-count','evaluator',true,r=>r.evaluator_materials.files++],
  ['compiler-wrong-nonce','compiler',false,r=>{r.compiler_materials.nonce=(r.compiler_materials.nonce[0]==='0'?'1':'0')+r.compiler_materials.nonce.slice(1);}],
  ['evaluator-wrong-nonce','evaluator',false,r=>{r.evaluator_materials.nonce=(r.evaluator_materials.nonce[0]==='0'?'1':'0')+r.evaluator_materials.nonce.slice(1);}],
  ['compiler-wrong-creation','compiler',false,r=>{r.compiler_materials.created_at='2026-10-17T08:37:12Z';assert.notEqual(r.compiler_materials.created_at,original.compiler_materials.created_at);}],
  ['compiler-wrong-root','compiler',false,r=>{r.compiler_root_sha256=(r.compiler_root_sha256[0]==='0'?'1':'0')+r.compiler_root_sha256.slice(1);r.compiler_materials.root_sha256=r.compiler_root_sha256;}],
 ];
 for(const [name,role,audit,change] of specs){
  const record=structuredClone(original);change(record);record.policy_sha256=digest(record);save(name+'.approval.invalid.json',record);
  const bridge=createDaemonBridge({compiler:reviewed.compiler,approval:pin(root+'/'+name+'.approval.invalid.json')});let child,ended,wake,pending='',events=[],primary;
  try{
   const stderr=openSync(root+'/'+name+'.observer.stderr','wx',0o400);child=spawn("/workspace/scratch/M6_410_REMOTE_OPERATOR_39290523675_1/seed/m6-remote-runtime-seed/host-python/bin/python3.12",['-B',helper,'--role',role,'--expect-audit',audit?'yes':'no','--output',root+'/'+name],{stdio:['pipe','pipe',stderr],shell:false,cwd:'/workspace/zryna'});closeSync(stderr);
   ended=new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));
   child.stdout.on('data',b=>{pending+=b.toString();assert(pending.length<4096);let n;while((n=pending.indexOf('\n'))>=0){events.push(JSON.parse(pending.slice(0,n)));pending=pending.slice(n+1);wake?.();}});
   const expiry=performance.now()+5000;while(!events.some(e=>e.event==='ready')){assert(performance.now()<expiry);await Promise.race([new Promise(resolve=>{wake=resolve;setTimeout(resolve,50)}),ended.then(v=>{throw Error('Observer ended before ready:'+JSON.stringify(v))})]);}
   const token='2'.repeat(64),started=performance.now();let failure;
   try{if(role==='compiler')await bridge.compile(Buffer.from(JSON.stringify(sourceRequest)),undefined,token);else await bridge.evaluate(token,payloadFor(frame,compiled.metadata,record));}
   catch(error){failure=error;}
   assert(failure,'Invalid material approval must not return success');assert.equal(failure.message,'PLAYGROUND-HOST-MATERIALS');
   assert(failure.hostFailure,'Native closed terminal acknowledgement required');assert.equal(failure.cleanupConfirmed,true);assert.equal(failure.owner,null);assert.equal(failure.cleanup,null);assert.equal(bridge.recovery(),null);
   save(name+'.terminal.json',failure.hostFailure);await bridge.finish(token,true);assert(bridge.idle());await bridge.close();
   child.stdin.end('verify\n');assert.deepEqual(await ended,{code:0,signal:null});const observation=JSON.parse(readFileSync(root+'/'+name+'/OBSERVATION.json'));assert.equal(observation.status,'actual-material-denial-and-cleanup-observed');
   const row={id:name,role,expectedStage:audit?'complete-real-audit-before-source-upload':'material-volume-provenance-before-owned-creation',status:'pass',elapsedMs:performance.now()-started,policyError:failure.message,cleanupConfirmed:true,observerSha256:sha(readFileSync(root+'/'+name+'/OBSERVATION.json'))};result.rows.push(row);save(name+'.RESULT.json',row);
  }catch(error){primary=error;throw error;}
  finally{if(child&&!child.stdin.destroyed)child.stdin.end();try{await bridge.close();}catch(error){save(name+'.CLEANUP_FAILURE.json',{message:error.message});if(!primary)throw error;}}
 }
 // Original immutable approval and pristine bridge remain valid after all negative candidates.
 const fresh=await originalBridge.compile(Buffer.from(JSON.stringify(sourceRequest)),undefined,'3'.repeat(64));await originalBridge.finish('3'.repeat(64),false);
 const actual=await decodeCompilation(fresh,{revision:801,source:sourceRequest.source,witSha256:reviewed.witSha256});
 const value=await originalBridge.evaluate('4'.repeat(64),payloadFor(fresh,actual.metadata,original));assert.equal(value.value,42);await originalBridge.finish('4'.repeat(64),false);
 save('RECOVERY.json',{status:'actual-original-approval-compiler-and-chrome-recovery',observation:value,originalApprovalSha256:sha(readFileSync(reviewed.approval.path))});await originalBridge.close();originalBridge=null;
 result.status='actual-material-provenance-and-pre-source-audit-denials-pass';result.actualChromeRecoveryValue=42;result.fullQualification=false;
}catch(error){result.failure=String(error.message).slice(0,2000);throw error;}
finally{if(originalBridge){try{await originalBridge.close();}catch(error){save('PRISTINE_CLEANUP_FAILURE.json',{message:error.message,recovery:originalBridge.recovery()});}}writeFileSync(fd,JSON.stringify(result,null,2)+'\n');closeSync(fd);}
