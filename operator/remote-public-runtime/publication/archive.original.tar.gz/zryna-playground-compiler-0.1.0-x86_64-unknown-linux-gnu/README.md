Zryna restricted playground compiler 0.1.0

Linux x86_64 compiler executable built from 71fd69d99a39c22bdf262d1655a032aa76221f3e.
This archive contains the compiler and its license/build materials.
Use the reviewed-source playground launcher from this exact source revision.
Node and the legacy nine-file provider closure require independent authentication
from the original immutable v0.2.3 release. Chrome, source composition, runtime
images and operator-sealed materials require their separately reviewed approvals.
No standalone toolkit, automatic guest authority or unrestricted host execution
is granted by acquiring this archive.
