"""Read-only source/candidate selection. No approval, image change or guest execution."""
import argparse,hashlib,json,pathlib,re,stat,subprocess
BASE='dcef77a79782e91016b9e3e8d528cf21850b9d41'
HEAD='f47a3c26b0d55405fc00fb654c38818b89dfea10'
def ordinary(path,maximum=2097152):
    p=pathlib.Path(path);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not s.st_mode&0o022 and 0<s.st_size<=maximum,str(p)
    raw=p.read_bytes();t=p.stat()
    for key in ['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']:assert getattr(s,key)==getattr(t,key),(p,key)
    assert len(raw)==s.st_size;return raw
def sha(raw):return hashlib.sha256(raw).hexdigest()
def select(repo,freeze,candidate_review=None):
    repo=pathlib.Path(repo).resolve();raw=ordinary(freeze);f=json.loads(raw)
    assert f['status']=='actual-reviewed-publication-fix-merged-and-new-main-frozen'
    assert f['previous']==BASE and f['head']==HEAD and f['pr']==564
    commit,tree=f['commit'],f['tree'];assert commit!=BASE and re.fullmatch('[a-f0-9]{40}',commit) and re.fullmatch('[a-f0-9]{40}',tree)
    def git(*args):return subprocess.run(['git',*args],cwd=repo,capture_output=True,check=True,timeout=10).stdout
    assert git('rev-parse','HEAD').decode().strip()==commit
    assert git('rev-parse','HEAD^{tree}').decode().strip()==tree
    assert not git('status','--porcelain=v1')
    assert tree=='3fa38d7b62b06a64ac5385d610be164f9b1961b8'
    assert git('rev-parse',commit+'^').decode().strip()==BASE
    assert f['previousPublicationFix']=={'pr':563,'commit':BASE,'tree':'1fa77b9e77185f5fb9d401f1cfb70ee6cc76f963'}
    assert git('symbolic-ref','--short','HEAD').decode().strip()=='main'
    review_pin=f['independentReview'];review_raw=ordinary(review_pin['path'])
    assert str(pathlib.Path(review_pin['path']))=='/workspace/scratch/M6_410_UPLOAD_RESPONSE_TAG2_FINAL_SCOPE_INDEPENDENT_REVIEW_20261018_RUN1/HEAD_CONFIRMATION.json'
    assert len(review_raw)==review_pin['bytes'] and sha(review_raw)==review_pin['sha256']=='c132b3511ef251965e7d026128055a27bcbed4ab1f12d0c506a3d163d93ff6ff'
    review=json.loads(review_raw)
    assert review['status']=='exact-committed-clean-eleven-file-head-independently-confirmed' and review['findings']==[]
    assert review['head']==HEAD and review['tree']==tree and review['soleParent']==BASE
    assert review['approvedWholePatchSha256']=='887f4f26574ce2b5c6d2bbc636ca15528c72b156325866d61912d70b3f08dcaf'
    changed=git('diff','--name-only',BASE,commit).decode().splitlines()
    expected=sorted(['.github/workflows/playground-compiler-release.yml',
      'examples/playground/restricted/daemon/compiler-publication-constants.mjs',
      'examples/playground/restricted/daemon/compiler-publication-sbom-fixture.mjs',
      'examples/playground/restricted/daemon/compiler-publication-sbom-graph.mjs',
      'scripts/m6/compiler-release/README.md','scripts/m6/compiler-release/admission.test.mjs',
      'scripts/m6/compiler-release/common.mjs','scripts/m6/compiler-release/github.mjs',
      'scripts/m6/compiler-release/github.test.mjs','scripts/m6/compiler-release/publish.test.mjs',
      'spec/tooling/M6_REVIEWED_SOURCE_V2.md'])
    assert changed==expected and sorted(p['path'] for p in review['files'])==expected
    assert sha(git('diff','--binary',BASE,commit))==review['approvedWholePatchSha256']
    actual=[]
    for item in review['files']:
        rel=item['path'];blob=git('show',commit+':'+rel)
        assert ordinary(repo/rel)==blob and len(blob)==item['bytes'] and sha(blob)==item['sha256']
        assert git('rev-parse',commit+':'+rel).decode().strip()==item['gitBlob']
        actual.append(item)
    assert actual==f['reviewedChanges']
    service_path='examples/playground/restricted/service.mjs';service=ordinary(repo/service_path)
    assert service==git('show',commit+':'+service_path)==git('show',BASE+':'+service_path)
    assert b'server.maxConnections = 8;' in service
    dirs={'plans':f'/workspace/scratch/M6_410_RUNTIME_PLANS_{commit}_RUN1','prepared':f'/workspace/scratch/M6_410_RUNTIME_PREPARATION_{commit}_RUN1','composition':f'/workspace/scratch/M6_410_LAUNCHER_PREPARATION_{commit}_RUN1','review':f'/workspace/scratch/M6_410_RUNTIME_INPUT_REVIEW_{commit}_RUN1'}
    result={'source':{'repository':'https://github.com/zryna/zryna','commit':commit,'tree':tree},'repo':str(repo),'frozenMainPath':str(pathlib.Path(freeze).resolve()),'frozenMainSha256':sha(raw),'directories':dirs,'unchangedHistoricalInputsBase':BASE,'originalMaterialInputsBase':'5d79dba18117a7ff41ff08d328aa94838c0fce9c','changedPaths':changed}
    if candidate_review:
        raw=ordinary(candidate_review);c=json.loads(raw)
        assert c['status']=='official-two-replica-candidate-acquired-and-reassembled'
        assert c['source']['commit']==commit and c['source']['tree']==tree
        compiler=c['compiler'];assert type(compiler['bytes']) is int and 0<compiler['bytes']<=134217728 and re.fullmatch('[a-f0-9]{64}',compiler['sha256'])
        data=ordinary(c['compilerPath'],134217728);assert len(data)==compiler['bytes'] and sha(data)==compiler['sha256']
        result.update({'compiler':compiler,'compilerPath':str(pathlib.Path(c['compilerPath']).resolve()),'candidateReviewPath':str(pathlib.Path(candidate_review).resolve()),'candidateReviewSha256':sha(raw),'candidateRunId':c['runId']})
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',default='/workspace/zryna');p.add_argument('--freeze',required=True);p.add_argument('--candidate-review');a=p.parse_args()
    print(json.dumps(select(a.repo,a.freeze,a.candidate_review),indent=2))
