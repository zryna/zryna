// Own bounded read-only observations of explicit independently reviewed existing evidence.
// Registry supplies required coverage only; no default pass/count, guest, API or process launch.
// Actual frozen source binding; all actual observation inputs remain pending.
import assert from 'node:assert/strict';
import {readFileSync,lstatSync,realpathSync,readdirSync,writeFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {release} from 'node:os';
import {bytes,sha256,parseCanonical,portablePath} from '/workspace/zryna/scripts/distribution/canonical.mjs';
import {sourceRegistry} from '/workspace/zryna/scripts/m6/source-registry.mjs';
import {openQualification} from '/workspace/zryna/scripts/m6/compiler-release/qualification.mjs';
const C='71fd69d99a39c22bdf262d1655a032aa76221f3e',T='351da60bd4037e0f96c286045c8943f41fa99b03';
const FAMILIES=['playground','containment','browser','accessibility','publication'];
const hash=v=>typeof v==='string'&&/^[0-9a-f]{64}$/.test(v);
const [selectionPath,expectedSelectionSha,output]=process.argv.slice(2);assert.equal(process.argv.length,5);
assert.equal(process.version,'v22.22.1');assert.equal(process.platform,'linux');assert.equal(process.arch,'x64');const startedAt=new Date().toISOString();
function read(path,maximum,empty=false){
 assert(realpathSync(path)===path);const s=lstatSync(path);assert(s.isFile()&&s.nlink===1&&!(s.mode&0o022)&&s.size>=Number(!empty)&&s.size<=maximum);const b=readFileSync(path),after=lstatSync(path);
 for(const k of ['dev','ino','mode','nlink','size','mtimeMs','ctimeMs'])assert.equal(after[k],s[k]);assert.equal(b.length,s.size);return b;
}
function pin(p,maximum){const b=read(p.path,maximum,p.bytes===0);assert.equal(b.length,p.bytes);assert.equal(sha256(b),p.sha256);return b;}
const selectionRaw=read(selectionPath,65536);assert.equal(sha256(selectionRaw),expectedSelectionSha);const s=parseCanonical(selectionRaw);assert.equal(s.format,'private.m6-public-readonly-selection.v1');assert.deepEqual(s.source,{commit:C,tree:T});
const reviewRaw=pin(s.caseReview,262144),inventoryRaw=pin(s.inventory,262144),authRaw=pin(s.authenticationState,65536);const review=parseCanonical(reviewRaw),inventory=parseCanonical(inventoryRaw),auth=parseCanonical(authRaw);
assert.equal(sha256(read(new URL(import.meta.url).pathname,65536)),s.reader.sha256);assert.equal(s.reader.path,new URL(import.meta.url).pathname);
assert.equal(review.format,'private.m6-public-family-case-review.v1');assert.equal(review.status,'independently-reviewed-actual-public-family-inputs');assert.deepEqual(review.source,s.source);assert(typeof review.reviewer==='string'&&review.reviewer.length>0&&review.reviewer.length<=128);
assert.equal(inventory.format,'private.m6-complete-public-capture-inventory.v1');assert.deepEqual(inventory.source,s.source);assert(Array.isArray(inventory.files)&&inventory.files.length>0&&inventory.files.length<=480);
assert.equal(auth.format,'private.m6-public-readonly-authentication.v1');assert.equal(auth.status,'independently-selected-actual-existing-inputs');assert.deepEqual(auth.source,s.source);assert.equal(auth.caseReviewSha256,s.caseReview.sha256);assert.equal(auth.inventorySha256,s.inventory.sha256);assert.equal(auth.readerSha256,s.reader.sha256);
const layout=auth.captureLayout;assert(layout&&layout.format==='private.m6-remote-public-capture-layout.v1');
assert(Number.isSafeInteger(layout.runId)&&layout.runId>0&&layout.runAttempt===1&&typeof layout.operatorCommit==='string'&&/^[a-f0-9]{40}$/.test(layout.operatorCommit)&&layout.operatorCommit!==C);
const originalHostRoot='/workspace/scratch/M6_410_EPHEMERAL_HOST_'+layout.runId+'_'+layout.runAttempt;
const finalRoot=layout.retainedFinalRoot;assert(typeof finalRoot==='string'&&finalRoot.startsWith('/workspace/scratch/M6_410_')&&finalRoot.endsWith('/retained/evidence/workspace/scratch/M6_410_REMOTE_PUBLIC_OPERATOR_'+layout.runId+'_'+layout.runAttempt+'/final-artifact')&&realpathSync(finalRoot)===finalRoot);
assert.deepEqual(review.captureLayout,layout);const publicRoot=finalRoot+'/public-composition',journalRoot=finalRoot+'/public-observations/caller-journal';
const files=new Map(),bySource=new Map();let total=0;
for(const row of inventory.files){portablePath(row.path);assert(!files.has(row.path));const b=pin({path:row.sourcePath,bytes:row.bytes,sha256:row.sha256},32*1024*1024);total+=b.length;assert(total<=128*1024*1024);assert(!bySource.has(row.sourcePath));files.set(row.path,b);bySource.set(row.sourcePath,row);}
const get=path=>{assert(files.has(path),'Missing actual complete capture '+path);return files.get(path);};
// The five completed cohort roots are complete inventories, not slices of a live process.
const captureNames={parity:'HTTP_PARITY',ui:'UI',boundaries:'HTTP_BOUNDARIES',isolation:'SESSION_ISOLATION',documentation:'DOCUMENTATION_EXERCISE'};
assert.deepEqual(inventory.captureRoots.map(r=>r.label).sort(),Object.keys(captureNames).sort());
let directories=0;function walk(root){assert(++directories<=512);const out=[];for(const name of readdirSync(root)){const p=join(root,name),st=lstatSync(p);assert(!st.isSymbolicLink());if(st.isDirectory())out.push(...walk(p));else{assert(st.isFile());out.push(p);}}return out;}
for(const r of inventory.captureRoots){assert.equal(r.path,finalRoot+'/public-observations/M6_410_ACTUAL_PUBLISHED_'+captureNames[r.label]+'_'+C+'_RUN1');assert(realpathSync(r.path)===r.path);const actual=walk(r.path).sort(),selected=inventory.files.filter(f=>f.sourcePath.startsWith(r.path+'/')).map(f=>f.sourcePath).sort();assert.deepEqual(actual,selected,'Full completed public cohort capture root');}
// These are selected actual source-bound authentication/qualification/deployment pins.
for(const role of ['qualificationPacket','signatureVerification','deploymentProof','coordinatorStart','coordinatorCompletion','callerCredentials','callerDropIntent','runtimeReap','rootCompletion','hostLifecycle','hostManifest','coordinatorProgram','publicComposition','publishedReceipt']){const p=auth[role];assert.equal(sha256(get(p.inventoryPath)),p.sha256);assert.equal(review[role+'Sha256'],p.sha256);}
const selectedRow=role=>inventory.files.find(f=>f.path===auth[role].inventoryPath);
for(const [role,path]of [['signatureVerification',publicRoot+'/actual-verification.json'],['coordinatorStart',journalRoot+'/ACTUAL_RUN_START.json'],['coordinatorCompletion',journalRoot+'/ACTUAL_RUN_COMPLETE.json'],['callerCredentials',journalRoot+'/CALLER_CREDENTIALS.json'],['callerDropIntent',publicRoot+'/CALLER_DROP_INTENT.json'],['runtimeReap',finalRoot+'/host/runtime.json'],['rootCompletion',finalRoot+'/COMPLETE.json'],['hostLifecycle',finalRoot+'/host/HOST_RESULT.json'],['hostManifest',finalRoot+'/owner/manifest.json'],['publicComposition',publicRoot+'/source-composition.json'],['publishedReceipt',publicRoot+'/authenticated-receipt.json']])assert.equal(selectedRow(role).sourcePath,path);
const jsonRole=role=>JSON.parse(get(auth[role].inventoryPath));
const start=jsonRole('coordinatorStart'),complete=jsonRole('coordinatorCompletion'),credentials=jsonRole('callerCredentials'),drop=jsonRole('callerDropIntent'),runtime=jsonRole('runtimeReap'),outer=jsonRole('rootCompletion'),host=jsonRole('hostLifecycle'),manifest=jsonRole('hostManifest');
assert.equal(complete.status,'five-original-public-cohorts-complete');assert.equal(complete.completed,5);assert.deepEqual(complete.source,s.source);assert.deepEqual(start.source,s.source);assert.equal(start.compositionSha256,auth.publicCompositionSha256);
assert.equal(manifest.hostRoot,originalHostRoot);assert.deepEqual(manifest.source,{path:'/workspace/zryna',...s.source});assert.deepEqual(manifest.run,{id:String(layout.runId),attempt:String(layout.runAttempt)});assert.equal(manifest.approval.phase,'public');assert.equal(manifest.approval.operatorCommit,layout.operatorCommit);assert.equal(manifest.approval.root,originalHostRoot+'/public-composition');
assert.equal(manifest.files.runtime.sha256,auth.coordinatorProgram.sha256);assert.equal(manifest.files.runtime.bytes,get(auth.coordinatorProgram.inventoryPath).length);assert.equal(runtime.argv[0],manifest.files.node.path);assert.equal(runtime.argv[1],manifest.files.runtime.path);
assert(Number.isSafeInteger(credentials.pid)&&credentials.pid>0);assert.equal(runtime.pid,credentials.pid);assert.equal(drop.pid,credentials.pid);assert.equal(drop.fromUid,0);assert.equal(drop.toUid,1000);assert.equal(drop.toGid,1000);assert.equal(drop.noNewPrivs,'1');assert.deepEqual(drop.source,s.source);
assert.deepEqual([credentials.uid,credentials.euid,credentials.gid,credentials.egid],[1000,1000,1000,1000]);assert.deepEqual(credentials.supplementaryGroups,[]);assert.equal(credentials.beforeFirstLauncher,true);for(const k of ['Uid','Gid'])assert.deepEqual(credentials.status[k].split(/\s+/),['1000','1000','1000','1000']);assert.equal(credentials.status.Groups.trim(),'');assert.equal(credentials.status.NoNewPrivs,'1');for(const k of ['CapInh','CapPrm','CapEff','CapAmb'])assert.equal(BigInt('0x'+credentials.status[k]),0n);
assert.equal(runtime.returncode,0);assert.equal(runtime.reaped,true);assert.equal(runtime.timedOut,false);assert(!runtime.reapError&&!runtime.error);assert.equal(outer.returncode,0);assert(!outer.failure&&!outer.captureFailure);
assert.equal(host.status,'owned-host-phases-completed-no-acceptance-verdict');assert.equal(host.originalCgroupMountUnchanged,true);assert(!host.failure);assert.deepEqual(host.sourceSelectedByOperator,manifest.source);for(const k of ['dockerd','containerd'])assert.equal(host.stops[k].reaped,true);
assert.equal(host.observer.status,'public-phases-and-inert-material-retention-exited-zero');assert.deepEqual(host.observer.phaseResults.runtime,runtime);
const outcomes={parity:'actual-nineteen-cli-http-browser-comparison-matched',ui:'actual-initial-abort-corpus-ax-ui-pass',boundaries:'actual-http-boundary-cohort-pass',isolation:'actual-source-session-and-contained-browser-isolation-pass',documentation:'actual-published-guide-source-reject-restore-and-browser42-pass'};
assert.deepEqual(Object.keys(auth.cohortCompletions).sort(),Object.keys(outcomes).sort());assert.deepEqual(review.cohortCompletionSha256ByName,Object.fromEntries(Object.entries(auth.cohortCompletions).map(([k,v])=>[k,v.sha256])));
const cohortResults={};
for(const [name,status]of Object.entries(outcomes)){
 const p=auth.cohortCompletions[name],row=inventory.files.find(f=>f.path===p.inventoryPath);assert(row);assert.equal(row.sourcePath,journalRoot+'/COHORT_'+name+'_COMPLETE.json');const b=get(p.inventoryPath);assert.equal(sha256(b),p.sha256);const done=JSON.parse(b);assert.equal(done.name,name);assert.equal(done.status,status);
 const originalResult=originalHostRoot+'/public-observations/M6_410_ACTUAL_PUBLISHED_'+captureNames[name]+'_'+C+'_RUN1/RESULT.json';assert.equal(done.result.path,originalResult);const resultRow=bySource.get(finalRoot+'/public-observations/M6_410_ACTUAL_PUBLISHED_'+captureNames[name]+'_'+C+'_RUN1/RESULT.json');assert(resultRow);assert.equal(resultRow.bytes,done.result.bytes);assert.equal(resultRow.sha256,done.result.sha256);const result=JSON.parse(get(resultRow.path));assert.equal(result.status,status);assert(!result.failure&&!result.cleanupFailure&&(!result.cleanupFailures||result.cleanupFailures.length===0));cohortResults[name]=result;
}
assert.equal(cohortResults.parity.launcherStopped,true);assert.equal(cohortResults.parity.stages.length,19);assert(cohortResults.parity.stages.every(x=>x.finishAcknowledged));assert.deepEqual(cohortResults.parity.integration,s.source);
const uiRow=bySource.get(finalRoot+'/public-observations/M6_410_ACTUAL_PUBLISHED_UI_'+C+'_RUN1/OBSERVATION.json');assert(uiRow);const ui=JSON.parse(get(uiRow.path));assert.equal(ui.containerCleanupConfirmed,true);assert.equal(ui.compilerEvidence.cleanupAcknowledged,true);for(const k of ['removed','dockerRemoved','kernelReapProven'])assert.equal(ui.owner[k],true);assert.equal(ui.owner.failure,null);assert.equal(ui.owner.cleanupFailure,null);assert.equal(ui.owner.ownershipUnconfirmed,false);
assert(cohortResults.boundaries.rows.some(x=>x.id==='actual-chrome-recovery'&&x.value===42&&x.finishAcknowledged===true));assert.equal(cohortResults.isolation.allLaunchersStopped,true);assert.deepEqual(cohortResults.isolation.actualChromeValues,[42,7]);assert.equal(cohortResults.documentation.normalNativeCleanupConfirmed,true);assert.equal(cohortResults.documentation.restoredValue,42);
// Root phase reaping above is process ownership evidence only. It never substitutes for
// the original per-operation native cleanup, complete raw cohort proofs or59 reviewed facts.
assert(hash(auth.docsManifestSha256));assert.equal(review.docsManifestSha256,auth.docsManifestSha256);
const deployed=JSON.parse(get(auth.deploymentProof.inventoryPath));assert.equal(deployed.status,'actual-new-source-production-124-route-content-and-header-check-passed');assert.equal(deployed.compilerSourceCommit,C);assert.equal(deployed.manifestSha256,auth.docsManifestSha256);
assert(typeof auth.publishedCompilerRef==='string'&&/^refs\/tags\/v0\.1\.0-playground-compiler\.[1-9][0-9]*$/.test(auth.publishedCompilerRef));assert.equal(review.publishedCompilerRef,auth.publishedCompilerRef);
assert.equal(auth.publicComposition.sha256,auth.publicCompositionSha256);const receipt=JSON.parse(get(auth.publishedReceipt.inventoryPath)),verification=JSON.parse(get(auth.signatureVerification.inventoryPath));
assert.equal(receipt.type,'zryna.playground-compiler-publication.v1');assert.equal(receipt.status,'authenticated');assert.equal(receipt.source.commit,C);assert.equal(receipt.source.tree,T);assert.equal(receipt.archive.sha256,auth.publishedCompilerArchiveSha256);assert.equal(receipt.compiler.bytes,auth.compiler.bytes);assert.equal(receipt.compiler.sha256,auth.compiler.sha256);
assert.equal(receipt.source.ref,auth.publishedCompilerRef);assert.equal(receipt.verification.sourceCommit,C);assert.equal(receipt.verification.ref,auth.publishedCompilerRef);assert.equal(receipt.verification.event,'push');assert.equal(receipt.verification.offline,true);assert.equal(receipt.verification.transparencyAndSctChecksRetained,true);
assert.equal(verification.result.status,0);assert.equal(verification.result.signal,null);assert.equal(verification.result.errorCode,null);assert.deepEqual(receipt.verification.result,verification.result);assert.equal(receipt.verification.commandSha256,sha256(bytes(verification.command)));
for(const stream of ['stdout','stderr']){const original=inventory.files.find(f=>f.sourcePath===publicRoot+'/actual-verification.'+stream);assert(original);const data=get(original.path);assert.equal(data.length,verification.result[stream+'Bytes']);assert.equal(sha256(data),verification.result[stream+'Sha256']);}
assert.deepEqual(review.compiler,auth.compiler);assert.deepEqual(review.qualificationMaterials,auth.qualificationMaterials);assert.equal(review.publicCompositionSha256,auth.publicCompositionSha256);assert.equal(review.publishedCompilerArchiveSha256,auth.publishedCompilerArchiveSha256);
assert(Number.isSafeInteger(auth.compiler.bytes)&&auth.compiler.bytes>0&&auth.compiler.bytes<=128*1024*1024&&hash(auth.compiler.sha256));
const qs=auth.qualificationSelection;assert(qs&&Number.isSafeInteger(qs.ciRun)&&qs.ciRun>0&&Number.isSafeInteger(qs.ciAttempt)&&qs.ciAttempt>0&&Number.isSafeInteger(qs.qualificationAsset)&&qs.qualificationAsset>0&&hash(qs.qualificationSha256)&&hash(qs.reviewSha256));
const qualified=await openQualification(get(auth.qualificationPacket.inventoryPath),{source:{repository:'https://github.com/zryna/zryna',...s.source},compiler:auth.compiler,selection:auth.qualificationSelection});assert.equal(qualified.record.obligations.length,68);assert.deepEqual(qualified.record.materials,auth.qualificationMaterials);
assert.equal(sha256(get(auth.qualificationPacket.inventoryPath)),auth.qualificationSelection.qualificationSha256);
const facts=review.facts;assert(facts&&typeof facts==='object'&&!Array.isArray(facts)&&Object.keys(facts).length>0&&Object.keys(facts).length<=256);const used=new Set();
function verifyFact(id){
 assert(Object.hasOwn(facts,id));const f=facts[id];assert(typeof f.path==='string');const data=get(f.path);
 if(f.kind==='file-sha256'){assert.equal(sha256(data),f.expected);}
 else if(f.kind==='json-equals'){
  assert(typeof f.pointer==='string'&&f.pointer.startsWith('/')&&f.pointer.length<=2048);let v=JSON.parse(data);
  const keys=f.pointer.slice(1).split('/');assert(keys.length<=32);for(const raw of keys){const key=raw.replace(/~1/g,'/').replace(/~0/g,'~');assert(v!==null&&typeof v==='object'&&Object.hasOwn(v,key));v=v[key];}
  assert(bytes(f.expected).length<=16384);assert.deepEqual(v,f.expected);
 }else if(f.kind==='text-line-sha256'){
  assert(Number.isSafeInteger(f.line)&&f.line>0);const lines=new TextDecoder('utf8',{fatal:true}).decode(data).split(/\r?\n/);assert(f.line<=lines.length);assert.equal(sha256(Buffer.from(lines[f.line-1])),f.expected);
 }else throw Error('Closed actual observation fact kind');used.add(id);
}
const expected=new Map(sourceRegistry.gates.filter(g=>FAMILIES.includes(g.id)).map(g=>[g.id+'-linux',g]));assert.equal([...expected.values()].reduce((n,g)=>n+g.cases.length,0),59);assert.deepEqual(Object.keys(review.gates).sort(),[...expected.keys()].sort());
const gates={};let caseCount=0;
for(const [gid,rows]of Object.entries(review.gates)){
 assert(Array.isArray(rows));assert.deepEqual(rows.map(r=>r.id).sort(),[...expected.get(gid).cases].sort());gates[gid]=[];
 for(const row of rows){assert.equal(row.reviewedStatus,'independently-reviewed-actual-positive');assert(typeof row.rationale==='string'&&row.rationale.trim().length>0&&row.rationale.length<=4096);assert(Array.isArray(row.facts)&&row.facts.length>0&&row.facts.length<=16&&new Set(row.facts).size===row.facts.length);for(const id of row.facts)verifyFact(id);gates[gid].push({id:row.id,passed:row.facts.length,failed:0,skipped:0,factIds:row.facts});caseCount++;}
}
assert.equal(caseCount,59);assert.deepEqual([...used].sort(),Object.keys(facts).sort(),'No unused declared proof facts');
// Recheck complete original capture bytes after predicates; never reinterpret them as own streams.
for(const row of inventory.files)pin({path:row.sourcePath,bytes:row.bytes,sha256:row.sha256},32*1024*1024);
const result={format:'private.m6-actual-public-readonly-proof-reader.v1',status:'read-only-public-family-observations-verified',source:s.source,environment:{platform:'linux',osVersion:release(),architecture:'x86_64',runtime:process.version},startedAt,finishedAt:new Date().toISOString(),corpusSha256:s.caseReview.sha256,selectionSha256:expectedSelectionSha,inventorySha256:s.inventory.sha256,authenticationSha256:s.authenticationState.sha256,readerSha256:s.reader.sha256,verifiedFiles:files.size,verifiedBytes:total,verifiedFactDefinitions:used.size,caseCount,gates,scope:'Actual owned read-only observer command of independently reviewed existing observations. Counts are supporting verified observations, may overlap across cases, and are not unique product test reruns or new guest executions. Original complete public/private/signature/deployment bytes remain whole material archive data; no running coordinator stream/exit is claimed.'};
const raw=Buffer.from(JSON.stringify(result)+'\n');assert(raw.length<=65536);writeFileSync(output,raw,{flag:'wx',mode:0o400});process.stdout.write(raw);
