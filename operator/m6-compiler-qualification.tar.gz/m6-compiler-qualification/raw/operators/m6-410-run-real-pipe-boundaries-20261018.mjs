// Real original pipeline under fixed trusted operator faults; unchanged5s/2s guest budgets.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {readFileSync,writeFileSync,mkdirSync,openSync,closeSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {createSourceLauncher} from '/workspace/zryna/examples/playground/restricted/daemon/launcher.mjs';
import {decodeCompilation} from '/workspace/zryna/examples/playground/restricted/protocol.mjs';
const root='/workspace/scratch/M6_410_ACTUAL_PIPE_BOUNDARIES_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1';mkdirSync(root,{mode:0o700});
const fd=openSync(root+'/RESULT.json','wx',0o400),sha=b=>createHash('sha256').update(b).digest('hex');let result={status:'failed',rows:[]};
const save=(name,v)=>writeFileSync(root+'/'+name,JSON.stringify(v,null,2)+'\n',{flag:'wx',mode:0o400});
const reviewed=JSON.parse(readFileSync('/workspace/scratch/M6_410_LAUNCHER_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/reviewed-launcher.candidate.json'));
const helper='/workspace/scratch/M6_410_RUNTIME_COHORT_OPERATORS_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/m6-410-observe-real-pipe-boundary-20261018.py';
save('INTENT.json',{source:{commit:reviewed.source.commit,tree:reviewed.source.tree},compilerSha256:reviewed.compiler.sha256,
 scriptSha256:sha(readFileSync(import.meta.filename)),helperSha256:sha(readFileSync(helper)),
 scope:'Fixed trusted operator stops the audited original compiler at its actual execution and writes exactly the stdout1277956 or stderr4096 limit through that original process pipe. The first extra byte must cause original unchanged supervisor refusal and native ownedcleanup. No invalid injected bytes are treated as a real compilation result; fresh actualChrome42 must recover.'});
try{
 for(const mode of ['stdout','stderr']){
  let launcher,child;let primary;
  try{
   launcher=await createSourceLauncher(reviewed);await launcher.launch();const url=new URL(launcher.takeLaunchUrl()),capability=url.hash.slice(1);
   const headers={authorization:'Bearer '+capability,origin:url.origin,'sec-fetch-site':'same-origin','content-type':'application/json'};
   async function request(path,body){const response=await fetch(url.origin+path,{method:'POST',headers,body:JSON.stringify(body),redirect:'error',signal:AbortSignal.timeout(12500)});let total=0;const chunks=[];for await(const b of response.body){total+=b.length;assert(total<=1277956);chunks.push(b)}return {status:response.status,data:Buffer.concat(chunks),response};}
   async function compile(revision){const source='export function value(): i32 { return 42; }\n';const r=await request('/compile',{version:1,revision,source});assert.equal(r.status,200);const token=r.response.headers.get('x-zryna-job');assert.equal((await request('/finish',{token,cancelled:false})).status,200);const d=await decodeCompilation(new Uint8Array(r.data),{revision,source,witSha256:reviewed.witSha256});assert.equal(d.metadata.status,'compiled');return {revision,sourceSha256:d.metadata.sourceSha256,componentSha256:d.metadata.identity.componentSha256,logical:'value',args:[]};}
   const events=[];let pending='',wake;
   const stderr=openSync(root+'/'+mode+'-observer.stderr','wx',0o400);
   child=spawn('python3',[helper,'--parent',String(process.pid),'--mode',mode,'--output',root+'/'+mode],{cwd:'/workspace/zryna',stdio:['pipe','pipe',stderr],shell:false});closeSync(stderr);
   const ended=new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));
   child.stdout.on('data',b=>{pending+=b.toString();assert(pending.length<4096);let n;while((n=pending.indexOf('\n'))>=0){events.push(JSON.parse(pending.slice(0,n)));pending=pending.slice(n+1);wake?.();}});
   async function awaitEvent(event){const end=performance.now()+14000;while(!events.some(e=>e.event===event)){assert(performance.now()<end,'Fixed observer handshake');const changed=new Promise(resolve=>{wake=resolve});const value=await Promise.race([changed,ended.then(v=>({ended:v})),new Promise(resolve=>setTimeout(()=>resolve({tick:true}),100))]);if(value?.ended)throw Error('Observer ended before '+event+': '+JSON.stringify(value.ended));}}
   await awaitEvent('ready');const started=performance.now();const evaluation=request('/compile',{version:1,revision:701,source:'export function value(): i32 { return 42; }\n'});
   await awaitEvent('boundary');let cancellation;
   if(mode==='cancel'){cancellation=await request('/cancel',{cancelled:true});assert.equal(cancellation.status,200);assert.deepEqual(JSON.parse(cancellation.data),{finished:true});}
   const reply=await evaluation,elapsedMs=performance.now()-started;assert.equal(reply.status,400);
   const failure=JSON.parse(reply.data);assert(/^PLAYGROUND-[A-Z0-9-]+$/.test(failure.policyError));assert.equal(failure.policyError,'PLAYGROUND-HOST-CHILD');
   if(mode==='timeout'){assert.equal(failure.policyError,'PLAYGROUND-HOST-TIMEOUT');assert(elapsedMs>=9500&&elapsedMs<=13000);}
   if(mode==='cancel')assert.equal(failure.policyError,'PLAYGROUND-CANCELLED');
   child.stdin.end('verify\n');const end=await ended;assert.deepEqual(end,{code:0,signal:null});assert.equal(launcher.recovery().host,null);
   const observation=JSON.parse(readFileSync(root+'/'+mode+'/OBSERVATION.json'));assert.equal(observation.status,'actual-original-compiler-pipe-boundary-and-reap-observed');
   const recovered=await compile(702),replyRecovered=await request('/evaluate',recovered);assert.equal(replyRecovered.status,200);const observed=JSON.parse(replyRecovered.data);assert.equal(observed.observation.value,42);assert.equal((await request('/finish',{token:observed.token,cancelled:false})).status,200);
   await launcher.stop();launcher=null;
   const row={mode,status:'pass',elapsedMs,policyError:failure.policyError,lateSuccessSuppressed:true,originalOwnedReapConfirmed:true,actualChromeRecoveryValue:42,observerSha256:sha(readFileSync(root+'/'+mode+'/OBSERVATION.json'))};result.rows.push(row);save(mode+'-RESULT.json',row);
  }catch(error){primary=error;throw error;}
  finally{
   if(child&&!child.stdin.destroyed)child.stdin.end();
   if(launcher){try{await launcher.stop()}catch(error){save(mode+'-CLEANUP_FAILURE.json',{message:String(error.message),recovery:launcher.recovery()});if(!primary)throw error;}}
  }
 }
 result.status='actual-compiler-stdout-stderr-first-extra-boundaries-pass';result.fullQualification=false;console.log(JSON.stringify({status:result.status,cohorts:result.rows.length}));
}catch(error){result.failure=String(error.message).slice(0,1500);throw error;}
finally{writeFileSync(fd,JSON.stringify(result,null,2)+'\n');closeSync(fd);}
