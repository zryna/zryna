"""Fixed trusted kernel probes. Separate from actual compiler/browser acceptance."""
import hashlib, importlib.util, json, os, pathlib, re, subprocess, sys, time
import argparse
sys.path.insert(0,'/workspace/scratch/M6_410_PUBLICATION_FIX_RUNTIME_PREPARATION_20261018_RUN1')
from binding import select,ordinary,sha
parser=argparse.ArgumentParser();parser.add_argument('--candidate-review',required=True);args=parser.parse_args()
selection=select('/workspace/zryna','/workspace/scratch/M6_410_PUBLICATION_FIX_MERGE_AND_FREEZE_20261018_RUN1/FROZEN_MAIN.json',args.candidate_review)
assert selection['source']['commit']=='dcef77a79782e91016b9e3e8d528cf21850b9d41' and selection['source']['tree']=='1fa77b9e77185f5fb9d401f1cfb70ee6cc76f963'
composition=pathlib.Path(selection['directories']['composition'])
prepared=json.loads(ordinary(pathlib.Path(selection['directories']['prepared'])/'RESULT.json'))
review=json.loads(ordinary(pathlib.Path(selection['directories']['review'])/'REVIEW.json'))
assert prepared['status']=='prepared-unapproved' and prepared['selection']==selection
assert review['status']=='fresh-runtime-input-review-observations-not-approved' and review['selection']==selection
approval_raw=ordinary(composition/'approval.json');assert approval_raw==ordinary(composition/'approval.candidate.json')
approval=json.loads(approval_raw);descriptor=json.loads(ordinary(composition/'reviewed-launcher.candidate.json'))
assert descriptor['approval']['sha256']==sha(approval_raw) and descriptor['approval']['bytes']==len(approval_raw)
assert descriptor['compiler']['sha256']==selection['compiler']['sha256'] and approval['compiler_executable_sha256']==selection['compiler']['sha256']
assert descriptor['source']['commit']==selection['source']['commit'] and descriptor['source']['tree']==selection['source']['tree']
repo=pathlib.Path('/workspace/zryna')
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/preparation'))
from engine import Engine
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/cli-parity'))
import cli_cgroup
from cli_kernel_read import read as kernel_read, numbers as kernel_numbers
spec=importlib.util.spec_from_file_location('fixed_policy','/workspace/scratch/M6_410_KERNEL_POLICY_OPERATORS_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/compose-daemon-policy.py')
policy=importlib.util.module_from_spec(spec);spec.loader.exec_module(policy)
root=pathlib.Path('/workspace/scratch/M6_410_KERNEL_POLICY_ACTUAL_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN2');root.mkdir(mode=0o700)
def save(name,value):
    with (root/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
probe_preparation=pathlib.Path('/workspace/scratch/M6_410_RESOURCE_PROBE_PREPARATION_20261018_RUN1')
probe_state=json.loads(ordinary(probe_preparation/'IMAGE.json'))[0];image=probe_state['Id']
assert image=='sha256:2d52b61393de48e65215286ee502e87164748dd7fe3974696552db9bb4748d0e'
assert ordinary(probe_preparation/'probe.c')==ordinary(pathlib.Path(__file__).with_name('probe.c'))
assert policy.digest(approval)==approval['policy_sha256']
check_engine=Engine(65534,seconds=10)
fresh_probe=check_engine.json('GET','/images/'+image+'/json')
# Image content identity remains exact; API1.49 includes deprecated inert defaults
# omitted by API1.51/CLI inspect. Validate the complete closed representation.
for key in ['Id','Os','Architecture','RootFS']:assert fresh_probe[key]==probe_state[key],key
config_blob_path=pathlib.Path('/workspace/scratch/M6_410_KERNEL_PRECREATION_CONFIG_DIAGNOSIS_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/EXACT_IMAGE_CONFIG_BLOB.json')
config_blob=ordinary(config_blob_path);assert sha(config_blob)==image.removeprefix('sha256:')
blob=json.loads(config_blob)
assert blob['os']==fresh_probe['Os'] and blob['architecture']==fresh_probe['Architecture']
assert blob['rootfs']=={'type':'layers','diff_ids':fresh_probe['RootFS']['Layers']}
expected_blob_config={'User':'65534:65534','Env':['PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'],'Entrypoint':['/probe'],'WorkingDir':'/'}
assert blob['config']==expected_blob_config
canonical_config={**expected_blob_config,'Cmd':None,'Labels':None,'OnBuild':None,'Volumes':None}
assert probe_state['Config']==canonical_config
api149_defaults={'AttachStderr':False,'AttachStdin':False,'AttachStdout':False,'Domainname':'','Hostname':'','Image':'','OpenStdin':False,'StdinOnce':False,'Tty':False}
expected_full_config={**canonical_config,**api149_defaults}
assert set(fresh_probe['Config'])==set(expected_full_config),'Closed complete API1.49 probe config required'
for key,value in expected_full_config.items():
    actual=fresh_probe['Config'][key]
    assert type(actual) is type(value) and actual==value,('Config',key)
save('CONFIG_COMPATIBILITY.json',{'status':'exact-content-addressed-probe-config-with-explicit-api149-defaults','image':image,
    'configBlob':{'path':str(config_blob_path),'bytes':len(config_blob),'sha256':sha(config_blob)},
    'canonicalConfig':canonical_config,'strictApi149AdditionalDefaults':api149_defaults,
    'scope':'Closed API representation equivalence only; no image/policy/guest authority changes or runtime success claimed.'})
save('TRUSTED_PROBE_IMAGE_FRESH.json',fresh_probe)
from install import validate_runtime_image
production_images={}
for role in ['compiler','evaluator']:
    selected_image=prepared['images'][role];assert selected_image['failure'] is None
    image_id='sha256:'+approval[role+'_image_sha256'];assert image_id==selected_image['image']
    state=check_engine.json('GET','/images/'+image_id+'/json');validate_runtime_image(state,image_id)
    assert state['RootFS']=={'Type':'layers','Layers':['sha256:'+selected_image['emission']['archiveSha256']]}
    production_images[role]=state
save('PRODUCTION_IMAGES_FRESH_METADATA_ONLY.json',production_images)
save('BINDING.json',{'selection':selection,'approval':{'path':str(composition/'approval.json'),'bytes':len(approval_raw),'sha256':sha(approval_raw)},'probeImage':image,'productionImageScope':'Fresh metadata/config/layer checks only; executable below is the distinct immutable trusted /probe image, not the candidate image.','sourceScope':'Actual current new-source role policy; fresh candidate and runtime approval are preconditions, not a claim of candidate execution.'})
source={rel:hashlib.sha256((repo/rel).read_bytes()).hexdigest() for rel in [
    'crates/zryna-driver/src/restricted_browser/daemon/config.rs',
    'crates/zryna-driver/src/restricted_browser/daemon/policy.rs',
    'examples/playground/restricted/daemon/policies/compiler-amd64.json',
    'examples/playground/restricted/daemon/policies/evaluator-amd64.json']}
for rel in source:
    assert (repo/rel).read_bytes()==subprocess.check_output(['git','show','dcef77a79782e91016b9e3e8d528cf21850b9d41:'+rel],cwd=repo)
env=os.environ.copy()
for key in ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(key,None)
docker=['docker','--host=unix:///var/run/docker.sock']
record=approval
for role in ['compiler','evaluator']:
    assert record[role+'_seccomp_json']==(repo/('examples/playground/restricted/daemon/policies/'+role+'-amd64.json')).read_text().strip()
save('INTENT.json',{'sourceCommit':'dcef77a79782e91016b9e3e8d528cf21850b9d41','sourcePins':source,'image':image,
    'scope':'Actual fixed trusted resource probes with production role kernel controls. Different image/entrypoint and fresh empty read-only materials; no claim of compiler/browser corpus acceptance.',
    'activeSeconds':10,'cleanupSeconds':2,'cases':['policy'],'selection':selection,'productionImageScope':'Metadata checks only; policy executable is separate trusted /probe image'})
rows=[]
for role in ['compiler','evaluator']:
 for case in ['policy']:
    name=role+'-'+case;nonce=os.urandom(16).hex();engine=Engine(65534,seconds=10);cid=None;volumes=[];child=None
    result={'role':role,'case':case,'image':image,'nonce':nonce,'failure':None,'cleanupConfirmed':False}
    started=time.monotonic();observations=[];mapping=None
    try:
        for suffix in ['input','output','materials']:
            volume='zryna410-policy-probe-'+nonce+'-'+suffix
            config={'Name':volume,'Driver':'local','Labels':{'zryna410.policy-probe':nonce}}
            if suffix!='materials':config['DriverOpts']=policy.policy(record)['volumes'][suffix=='output']
            value=engine.json('POST','/volumes/create',config);assert value['Name']==volume;volumes.append(volume)
        selected={**record,'compiler_materials':{'name':volumes[2]},'evaluator_materials':{'name':volumes[2]}}
        config=policy.container(selected,role=='compiler',False)
        config.update({'Image':image,'Entrypoint':['/probe'],'Cmd':[role,case],'Labels':{'zryna410.policy-probe':nonce}})
        for i in [0,1]:config['HostConfig']['Mounts'][i]['Source']=volumes[i]
        save(name+'.CONFIG.json',config)
        value=engine.json('POST','/containers/create',config);cid=value['Id'];result['containerId']=cid
        state=engine.json('GET','/containers/'+cid+'/json');assert state['Image']==image and state['State']['Status']=='created'
        save(name+'.BEFORE.json',state)
        with (root/(name+'.stdout')).open('xb') as out,(root/(name+'.stderr')).open('xb') as err:
            child=subprocess.Popen(docker+['start','--attach',cid],stdout=out,stderr=err,env=env)
            while child.poll() is None:
                assert time.monotonic()-started<10,'Original10second active bound'
                state=engine.json('GET','/containers/'+cid+'/json');pid=state['State']['Pid']
                if pid:
                    try:
                        membership=pathlib.Path('/proc/'+str(pid)+'/cgroup').read_text()
                        if mapping is None:
                            mapping=cli_cgroup.mapping(kernel_read,kernel_numbers,membership,cid,engine.deadline)
                            save(name+'.CGROUP_MAPPING.json',mapping)
                        assert membership in ['0::/../docker/'+cid+'\n','0::/docker/'+cid+'\n'], 'Original admitted cgroup membership changed'
                        cg=pathlib.Path(mapping['path'])
                        values={}
                        for field in ['memory.max','memory.swap.max','memory.current','memory.events','pids.max','pids.current','cpu.max','cpu.stat','cpuset.cpus.effective']:
                            raw=(cg/field).read_bytes();assert len(raw)<=8192;values[field]=raw.decode()
                        observations.append({'elapsedMs':round((time.monotonic()-started)*1000),'pid':pid,'cgroup':membership,'values':values})
                    except FileNotFoundError:pass
                assert len(observations)<=120
                time.sleep(0.05)
            result['ownerExit']=child.wait(timeout=max(.01,10-(time.monotonic()-started)))
        state=engine.json('GET','/containers/'+cid+'/json');save(name+'.AFTER.json',state)
        result.update({'exitCode':state['State']['ExitCode'],'oomKilled':state['State']['OOMKilled'],'elapsedMs':round((time.monotonic()-started)*1000),'kernelSamples':len(observations)})
        stdout=(root/(name+'.stdout')).read_text();assert len(stdout.encode())<=262144
        assert state['State']['Pid']==0 and state['State']['Running'] is False
        assert result['ownerExit']==0 and state['State']['ExitCode']==0 and state['State']['OOMKilled'] is False
        if case=='policy':
            assert re.search(r'^NoNewPrivs:\s+1$',stdout,re.M) and re.search(r'^Seccomp:\s+2$',stdout,re.M)
            for field in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']:assert re.search(r'^'+field+r':\s+0+$',stdout,re.M)
            assert 'PROBE uid=65534 gid=65534 ptrace=-1 errno=1 bpf=-1 errno=1 root=-1 errno=30' in stdout
            result['actualDenials']={'ptrace':'EPERM','bpf':'EPERM','rootCreate':'EROFS'}
            result['namespaceInitUidGid65534']=True
        for o in observations:
            v=o['values'];assert v['memory.max'].strip()==str(536870912 if role=='compiler' else 1073741824)
            assert v['memory.swap.max'].strip()=='0' and v['pids.max'].strip()==str(32 if role=='compiler' else 256)
            assert v['cpu.max'].strip()=='200000 100000' and v['cpuset.cpus.effective'].strip()=='0-1'
    except BaseException as error:
        result['failure']=__import__('traceback').format_exc()[-3000:]
    finally:
        cleanup=Engine(65534,seconds=2)
        try:
            if cid:
                cleanup.request('DELETE','/containers/'+cid+'?force=1&v=0',statuses=(204,))
                cleanup.request('GET','/containers/'+cid+'/json',statuses=(404,))
            if child and child.poll() is None:child.wait(timeout=max(.01,cleanup.deadline-time.monotonic()))
            for volume in volumes:
                cleanup.request('DELETE','/volumes/'+volume,statuses=(204,))
                cleanup.request('GET','/volumes/'+volume,statuses=(404,))
            result['cleanupConfirmed']=True
        except BaseException as error:result['cleanupFailure']=type(error).__name__+': '+str(error)[:1024]
        save(name+'.KERNEL.json',observations);save(name+'.RESULT.json',result);rows.append(result)
    assert result['failure'] is None and result['cleanupConfirmed'],result
save('RESULT.json',{'status':'two-owned-new-source-role-policy-probes-pass','rows':rows,'fullQualification':False,'selection':selection,'scope':'Fresh actual role-policy probes in distinct trusted fixed image; candidate-image resource/storage evidence requires separately selected successful actual new-source owned cohorts.'})
print(json.dumps({'root':str(root),'probes':len(rows),'status':'two-owned-new-source-role-policy-probes-pass'}))
