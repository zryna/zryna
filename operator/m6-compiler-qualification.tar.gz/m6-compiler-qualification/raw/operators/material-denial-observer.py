"""Read-only observer for explicitly invalid private material approvals. Never mutates Engine."""
import argparse,json,os,pathlib,re,select,sys,time
REPO=pathlib.Path('/workspace/zryna')
sys.path.insert(0,str(REPO/'examples/playground/restricted/daemon/preparation'))
from engine import Engine,decode
sys.path.insert(0,str(REPO/'examples/playground/restricted/daemon/cli-parity'))
from cli_kernel_read import read,numbers,ticks
import cli_cgroup
parser=argparse.ArgumentParser();parser.add_argument('--role',choices=['compiler','evaluator'],required=True)
parser.add_argument('--expect-audit',choices=['yes','no'],required=True);parser.add_argument('--output',required=True)
args=parser.parse_args();root=pathlib.Path(args.output)
assert root.parent.name=='M6_410_ACTUAL_MATERIAL_DENIAL_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1';root.mkdir(mode=0o700)
fd=os.open(root/'OBSERVATION.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o400)
deadline=time.monotonic()+15;engine=Engine(65534,seconds=15)
approval=json.loads(pathlib.Path('/workspace/scratch/M6_410_LAUNCHER_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/approval.json').read_bytes())
image='sha256:'+approval[args.role+'_image_sha256'];record={'status':'failed','role':args.role,'engineMethods':['GET'],'auditObserved':False,'inputRequest404DuringAudit':False,'containers':{}}
def emit(event):print(json.dumps({'event':event}),flush=True)
def owned():return [v for v in engine.json('GET','/containers/json?all=1') if 'zryna410.owner' in v.get('Labels',{})]
def private_volumes():return [v['Name'] for v in engine.json('GET','/volumes').get('Volumes',[]) if re.fullmatch(r'zryna410-[a-f0-9]{32}-(input|output)',v['Name'])]
def material_states():return {role:engine.json('GET','/volumes/'+approval[role+'_materials']['name']) for role in ['compiler','evaluator']}
try:
    assert os.getuid()==1000
    assert not owned() and not private_volumes(),'No concurrent or prior owned runtime may be adopted'
    record['materialsBefore']=material_states();emit('ready');completed=False
    while time.monotonic()<deadline:
        ready,_,_=select.select([sys.stdin],[],[],0)
        if ready:
            line=sys.stdin.readline(32);assert line=='verify\n';completed=True;break
        for summary in owned():
            cid=summary['Id'];assert re.fullmatch('[a-f0-9]{64}',cid)
            # A container may be removed between the list and inspect. This is observation only.
            raw,_=engine.request('GET','/containers/'+cid+'/json',statuses=(200,404));state=decode(raw)
            if 'Id' not in state:continue
            assert state['Image']==image and state['Config']['User']=='65534:65534'
            nonce=state['Config']['Labels']['zryna410.owner'];assert re.fullmatch('[a-f0-9]{32}',nonce)
            entry=record['containers'].get(cid)
            if entry is None:
                entry={'ownerNonce':nonce,'inspect':state,'pid':None,'epoch':None,'cgroup':None,'auditExecs':[]};record['containers'][cid]=entry
            pid=state['State']['Pid']
            if pid and entry['pid'] is None:
                try:
                    epoch=ticks(pid,deadline);membership=read('/proc/'+str(pid)+'/cgroup',deadline)
                    mapping=cli_cgroup.mapping(read,numbers,membership,cid,deadline)
                    entry.update({'pid':pid,'epoch':epoch,'cgroup':mapping['path'],'mapping':mapping})
                except FileNotFoundError:pass
            for eid in state.get('ExecIDs') or []:
                raw,_=engine.request('GET','/exec/'+eid+'/json',statuses=(200,404));value=decode(raw)
                if value.get('ProcessConfig',{}).get('entrypoint')!='/supervisor' or value['ProcessConfig'].get('arguments')!=['audit']:continue
                if value.get('Running') is True:
                    record['auditObserved']=True
                    if not any(item['ID']==eid for item in entry['auditExecs']):entry['auditExecs'].append(value)
                    # The sole source carrier does not exist while the real complete auditor runs.
                    engine.request('GET','/containers/'+cid+'/archive?path=/input/request',statuses=(404,),maximum_response=4096)
                    record['inputRequest404DuringAudit']=True
        time.sleep(.005)
    assert completed,'Parent never supplied the completed native denial'
    assert not owned() and not private_volumes(),'Native denial left runtime resources'
    for cid,entry in record['containers'].items():
        engine.request('GET','/containers/'+cid+'/json',statuses=(404,))
        if entry['pid'] is not None:
            try:assert ticks(entry['pid'],deadline)!=entry['epoch'],'Original owned init still exists'
            except FileNotFoundError:pass
            group=pathlib.Path(entry['cgroup'])
            if group.exists():assert 'populated 0' in read(str(group/'cgroup.events'),deadline)
        for mount in entry['inspect']['Mounts']:
            if mount['Destination'] in ['/input','/output']:engine.request('GET','/volumes/'+mount['Name'],statuses=(404,))
    if args.expect_audit=='yes':assert record['auditObserved'] and record['inputRequest404DuringAudit'] and record['containers'],'Actual pre-source auditor was not captured'
    else:assert not record['containers'],'Expected provenance denial before creation'
    record['materialsAfter']=material_states();assert record['materialsAfter']==record['materialsBefore']
    record.update({'status':'actual-material-denial-and-cleanup-observed','ownedResourcesGone':True,'sealedVolumeIdentityUnchanged':True});emit('closed')
finally:
    with os.fdopen(fd,'w') as stream:json.dump(record,stream,indent=2);stream.write('\n')
