"""Fixed trusted operator fault injection into one creation-owned evaluation container.
The public API and guest permissions are unchanged. No capability or browser log is read.
"""
import argparse, hashlib, json, os, pathlib, re, select, struct, sys, time
repo=pathlib.Path('/workspace/zryna')
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/preparation'))
from engine import Engine,decode
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/cli-parity'))
from cli_kernel_read import read,numbers,ticks,fields
import cli_cgroup
parser=argparse.ArgumentParser();parser.add_argument('--parent',type=int,required=True);parser.add_argument('--mode',choices=['host-death'],required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
root=pathlib.Path(args.output);assert root.parent.name=='M6_410_ACTUAL_HOST_DEATH_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1';root.mkdir(mode=0o700)
observation_fd=os.open(root/'OBSERVATION.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o400)
deadline=time.monotonic()+18;engine=Engine(65534,seconds=18)
approval=json.loads(pathlib.Path('/workspace/scratch/M6_410_LAUNCHER_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/approval.json').read_bytes())
image='sha256:'+approval['compiler_image_sha256'];record={'status':'failed','mode':args.mode,'faultApplied':False,'samples':[],'nativeCleanupAcknowledged':False};cid=None;host_pid=None;host_epoch=None;host_stopped=False;host_killed=False;operator_recovered=False
def save(name,value):
    with (root/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
def event(name):print(json.dumps({'event':name}),flush=True)
def candidates():return [c for c in engine.json('GET','/containers/json?all=1') if c.get('ImageID')==image and 'zryna410.owner' in c.get('Labels',{})]
def stats(group):
    return {name:read(group+'/'+name,deadline) for name in ['memory.max','memory.swap.max','memory.current','memory.events','pids.max','pids.current','pids.events','cpu.max','cpu.stat','cpuset.cpus.effective']}
def gone(pid,epoch):
    try:return ticks(pid,deadline)!=epoch
    except FileNotFoundError:return True
def exec_request(code,ns_pid,detach):
    request={'AttachStdin':False,'AttachStdout':not detach,'AttachStderr':not detach,'Tty':False,'Privileged':False,
        'User':'65534:65534','WorkingDir':'/tmp','Env':['PATH=/materials/runtime/node/bin','LC_ALL=C.UTF-8','LANG=C.UTF-8','TMPDIR=/tmp','HOME=/nonexistent','TZ=UTC','SOURCE_DATE_EPOCH=0'],
        'Cmd':['/materials/runtime/node/bin/node','--input-type=module','-e',code,str(ns_pid)]}
    created=engine.json('POST','/containers/'+cid+'/exec',request);eid=created['Id'];assert re.fullmatch('[a-f0-9]{64}',eid)
    raw,_=engine.request('POST','/exec/'+eid+'/start',value={'Detach':detach,'Tty':False},maximum_response=4096)
    if detach:assert raw==b''
    else:
        assert len(raw)>=8 and raw[0]==1 and raw[1:4]==b'\0\0\0' and struct.unpack('>I',raw[4:8])[0]==len(raw)-8
        value=json.loads(raw[8:]);assert value=={'signal':'SIGSTOP','pid':ns_pid}
        state=engine.json('GET','/exec/'+eid+'/json');assert state['Running'] is False and state['ExitCode']==0
    return {'execId':eid,'codeSha256':hashlib.sha256(code.encode()).hexdigest(),'namespacePid':ns_pid,'detached':detach}
try:
    assert os.getuid()==1000 and args.parent>1
    assert not candidates(),'A preexisting evaluator cannot be adopted by this probe'
    parent_epoch=ticks(args.parent,deadline);event('ready')
    while time.monotonic()<deadline:
        values=candidates();assert len(values)<=1
        if values and values[0]['State']=='running':
            cid=values[0]['Id'];state=engine.json('GET','/containers/'+cid+'/json');pid=state['State']['Pid']
            assert state['Image']==image and state['Config']['User']=='65534:65534' and state['State']['Paused'] is False
            nonce=state['Config']['Labels']['zryna410.owner'];assert re.fullmatch('[a-f0-9]{32}',nonce)
            membership=read('/proc/'+str(pid)+'/cgroup',deadline);mapping=cli_cgroup.mapping(read,numbers,membership,cid,deadline);group=mapping['path']
            init_epoch=ticks(pid,deadline);init_status=fields(read('/proc/'+str(pid)+'/status',deadline));init_ns=init_status['NSpid'].split();assert len(init_ns)>=2 and init_ns[-1]=='1'
            for selected in numbers(read(group+'/cgroup.procs',deadline)):
                try:
                    command=pathlib.Path('/proc/'+str(selected)+'/cmdline').read_bytes();argv=command.split(b'\0')
                    if not argv or argv[0]!=b'/app/compiler' or b'--audit-materials' not in argv:continue
                    status=fields(read('/proc/'+str(selected)+'/status',deadline));ns=status['NSpid'].split();assert len(ns)>=2
                    assert len(ns)==len(init_ns) and ns[0]==str(selected) and all(x.isdigit() and int(x)>0 for x in ns)
                    chrome_epoch=ticks(selected,deadline);ns_pid=int(ns[-1]);assert ns_pid>1
                    assert ticks(args.parent,deadline)==parent_epoch and ticks(pid,deadline)==init_epoch
                    save('PRODUCER_BEFORE.json',state);save('CGROUP_MAPPING.json',mapping)
                    record.update({'containerId':cid,'ownerNonce':nonce,'initPid':pid,'initEpoch':init_epoch,'auditorPid':selected,'auditorEpoch':chrome_epoch,'namespacePid':ns_pid,'baseline':stats(group)})
                    code="import{readFileSync}from'node:fs';const pid=Number(process.argv[1]);if(!Number.isInteger(pid)||pid<=1)throw Error('PID');const epoch=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\\s+/)[19];if(epoch!=="+json.dumps(chrome_epoch)+")throw Error('EPOCH');const argv=readFileSync('/proc/'+pid+'/cmdline','utf8').split('\\0');if(argv[0]!=='/app/compiler'||!argv.includes('--audit-materials'))throw Error('COMMAND');process.kill(pid,'SIGSTOP');console.log(JSON.stringify({signal:'SIGSTOP',pid}));"
                    record['stop']=exec_request(code,ns_pid,False)
                    assert ticks(selected,deadline)==chrome_epoch
                    assert fields(read('/proc/'+str(selected)+'/status',deadline))['State'].split()[0] in ['T','t']
                    record['faultApplied']=True;event('stopped')
                    break
                except FileNotFoundError:continue
            if record['faultApplied']:break
        time.sleep(.01)
    assert record['faultApplied'],'Owned actual compiler audit was not observed before the fixed deadline'
    # The owned auditor is stopped in the original synchronous pre-source audit call.
    # Source ordering permits no later create until this exec completes.
    expected=['--daemon-approval','/workspace/scratch/M6_410_LAUNCHER_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/approval.json',
        '--approval-sha256',hashlib.sha256(pathlib.Path('/workspace/scratch/M6_410_LAUNCHER_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/approval.json').read_bytes()).hexdigest(),'--operation','compile']
    descriptor=json.loads(pathlib.Path('/workspace/scratch/M6_410_LAUNCHER_PREPARATION_dcef77a79782e91016b9e3e8d528cf21850b9d41_RUN1/reviewed-launcher.candidate.json').read_bytes())['compiler'];target=pathlib.Path(descriptor['path']);target_stat=target.stat();assert target_stat.st_size==descriptor['bytes'] and descriptor['sha256']==approval['compiler_executable_sha256']
    found=[]
    entries=list(pathlib.Path('/proc').iterdir());assert len(entries)<=8192
    for entry in entries:
        if not entry.name.isdigit():continue
        try:
            ps=fields(read(str(entry/'status'),deadline))
            if ps['PPid']!=str(args.parent) or ps['Uid'].split()!=['1000']*4:continue
            argv=(entry/'cmdline').read_bytes().rstrip(b'\0').decode('ascii').split('\0')
            if argv[1:]!=expected:continue
            binary=(entry/'exe').stat();assert (binary.st_dev,binary.st_ino,binary.st_size)==(target_stat.st_dev,target_stat.st_ino,target_stat.st_size)
            assert hashlib.sha256((entry/'exe').read_bytes()).hexdigest()==approval['compiler_executable_sha256']
            found.append((int(entry.name),ticks(int(entry.name),deadline),argv))
        except FileNotFoundError:continue
    assert len(found)==1
    host_pid,host_epoch,host_argv=found[0]
    audits=[]
    for eid in engine.json('GET','/containers/'+cid+'/json')['ExecIDs'] or []:
        x=engine.json('GET','/exec/'+eid+'/json');pc=x['ProcessConfig']
        if x['Running'] and pc['entrypoint']=='/supervisor' and pc['arguments']==['audit']:
            assert x['ContainerID']==cid and pc['user']=='65534:65534' and not pc['privileged'];audits.append(x)
    assert len(audits)==1
    owned=[c for c in engine.json('GET','/containers/json?all=1') if c.get('Labels',{}).get('zryna410.owner')==nonce]
    assert len(owned)==1 and owned[0]['Id']==cid
    expected_volumes=[]
    for dest,suffix in [('/input','input'),('/output','output')]:
        mount=next(m for m in state['Mounts'] if m['Destination']==dest);name=mount['Name'];assert name=='zryna410-'+nonce+'-'+suffix
        value=engine.json('GET','/volumes/'+name);assert value['Labels']=={'zryna410.owner':nonce} and value['Driver']=='local'
        expected_volumes.append(value)
    save('AUDIT_BEFORE_HOST_STOP.json',audits[0]);save('VOLUMES_BEFORE_HOST_STOP.json',expected_volumes)
    assert ticks(host_pid,deadline)==host_epoch
    os.kill(host_pid,19);host_stopped=True
    for _ in range(100):
        tasks=list(pathlib.Path('/proc/'+str(host_pid)+'/task').iterdir());assert 1<=len(tasks)<=8
        if all(fields(read(str(t/'status'),deadline))['State'].split()[0] in ['T','t'] for t in tasks):break
        time.sleep(.001)
    else:raise AssertionError('Every native-host thread must be stopped')
    assert ticks(host_pid,deadline)==host_epoch and ticks(pid,deadline)==init_epoch
    assert engine.json('GET','/exec/'+audits[0]['ID']+'/json')['Running'] is True
    assert fields(read('/proc/'+str(selected)+'/status',deadline))['State'].split()[0] in ['T','t']
    record.update({'hostPid':host_pid,'hostEpoch':host_epoch,'hostExecutableSha256':approval['compiler_executable_sha256'],
        'hostThreadsStopped':len(tasks),'originalAuditExecId':audits[0]['ID'],'noLaterCreationBeforeStoppedAudit':True})
    os.kill(host_pid,9);host_killed=True;event('hostKilled')
    ready,_,_=select.select([sys.stdin],[],[],5);assert ready and sys.stdin.readline(128)=='verify\n'
    assert gone(host_pid,host_epoch)
    # The parent observed an unknown-cleanup failure and refused a second admission.
    # An exact operator recovery below is separate from a native acknowledgement.
    current=engine.json('GET','/containers/'+cid+'/json')
    assert current['Id']==cid and current['Image']==image and current['Config']['Labels']=={'zryna410.owner':nonce}
    same=[c for c in engine.json('GET','/containers/json?all=1') if c.get('Labels',{}).get('zryna410.owner')==nonce]
    assert len(same)==1 and same[0]['Id']==cid
    record['unknownCleanupOwnedResourcesStillPresent']=True
    if current['State']['Running']:
        engine.request('POST','/containers/'+cid+'/kill?signal=KILL',statuses=(204,))
    waited=engine.json('POST','/containers/'+cid+'/wait?condition=not-running');assert waited['StatusCode']==137 and waited.get('Error') is None
    after=engine.json('GET','/containers/'+cid+'/json');assert after['State']['Running'] is False and after['State']['Pid']==0
    engine.request('DELETE','/containers/'+cid+'?force=0&v=0',statuses=(204,));engine.request('GET','/containers/'+cid+'/json',statuses=(404,))
    assert gone(pid,init_epoch) and gone(selected,chrome_epoch)
    cg=pathlib.Path(group)
    if cg.exists():assert 'populated 0' in read(group+'/cgroup.events',deadline)
    for value in expected_volumes:
        name=value['Name'];assert engine.json('GET','/volumes/'+name)==value
        engine.request('DELETE','/volumes/'+name,statuses=(204,));engine.request('GET','/volumes/'+name,statuses=(404,))
    operator_recovered=True
    record.update({'status':'actual-host-death-unknown-cleanup-and-separate-owned-operator-recovery-observed',
        'hostGone':True,'originalInitGone':True,'originalAuditorGone':True,'ownedGroupEmptyOrRemoved':True,
        'container404':True,'ownedVolumes404':True,'operatorRecovery':True,'nativeCleanupAcknowledged':False})
    event('closed')
finally:
    if host_stopped and not host_killed:
        try:
            if ticks(host_pid,deadline)==host_epoch:os.kill(host_pid,18)
        except FileNotFoundError:pass
    record['operatorRecovered']=operator_recovered
    with os.fdopen(observation_fd,'w') as output:
        json.dump(record,output,indent=2);output.write('\n')
