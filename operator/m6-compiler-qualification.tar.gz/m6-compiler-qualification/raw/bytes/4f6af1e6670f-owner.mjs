// One bounded trusted host UI owner. No secrets or arbitrary guest commands are inputs.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {launchOwned} from '/workspace/scratch/M6_410_RUNTIME_COVERAGE_INDEPENDENT_REVIEW_20261018_RUN1/trusted-ui-owner-client.mjs';
assert.equal(process.argv.length,3);assert.equal(process.version,'v22.22.1');
const contextPath=process.argv[2],context=JSON.parse(readFileSync(contextPath));
const {root,source}=context;assert(root==='/workspace/scratch/M6_410_PLAIN_KEYBOARD_'+source.commit+'_RUN6');
mkdirSync(root,{mode:0o700});
const worker='/workspace/scratch/M6_410_KEYBOARD_PROTOCOL_VALUE_COMPARISON_PREPARATION_b3be654c452ea51f2c136a75d2eb89995eb4bd66_RUN1/worker.mjs';
const save=(name,v)=>writeFileSync(root+'/'+name,JSON.stringify(v,null,2)+'\n',{flag:'wx',mode:0o400});
save('INTENT.json',{source,workerSha256:createHash('sha256').update(readFileSync(worker)).digest('hex'),
 scope:'One actual ordinary Chrome keyboard/contrast/compile/evaluate exercise; original guest budgets remain unchanged; trusted host browser is not the guest containment claim.'});
const owner=await launchOwned(process.execPath,[worker,contextPath],{cwd:'/workspace/zryna',stage:root,output:root,name:'plain-keyboard',deadline:performance.now()+60000,env:process.env});
const actual=await owner.finish();assert.deepEqual(actual.ended,{status:0,signal:null});
const receipt=JSON.parse(readFileSync(root+'/plain-keyboard.json'));
assert(receipt.complete.cleanupConfirmed&&receipt.complete.status===0&&receipt.complete.failures.length===0&&receipt.ownerExit.status===0);
const result=JSON.parse(readFileSync(root+'/WORKER_RESULT.json'));
assert.equal(result.status,'actual-ordinary-chrome-keyboard-and-contrast-pass');
save('RESULT.json',{...result,trustedOwnerCleanupConfirmed:true});console.log(JSON.stringify(result));
