// Fixed trusted operator fault. Never invoked by guest source or any public selector.
import {readdirSync,readFileSync,statSync,openSync,writeSync,closeSync} from 'node:fs';
import assert from 'node:assert/strict';
const stream=Number(process.argv[1]),limit=Number(process.argv[2]);
assert(stream===1&&limit===1277956||stream===2&&limit===4096);
const deadline=Date.now()+7000,word=new Int32Array(new SharedArrayBuffer(4));
const pause=()=>{assert(Date.now()<deadline);Atomics.wait(word,0,0,1)};
let pid,epoch,argv;
while(!pid){
 for(const entry of readdirSync('/proc')){
  if(!/^[1-9][0-9]*$/.test(entry))continue;
  try{
   argv=readFileSync('/proc/'+entry+'/cmdline','utf8').split('\0');
   if(argv[0]!=='/app/compiler'||!argv.includes('--materials-root'))continue;
   pid=Number(entry);assert(pid>1);
   const before=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\s+/);epoch=before[19];assert(/^[1-9][0-9]*$/.test(epoch));assert(!['Z','X','x'].includes(before[0]));
   process.kill(pid,'SIGSTOP');
   for(;;){
    const fields=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\s+/);assert.equal(fields[19],epoch);assert(!['Z','X','x'].includes(fields[0]));
    const current=readFileSync('/proc/'+pid+'/cmdline','utf8').split('\0');assert.equal(current[0],'/app/compiler');assert(current.includes('--materials-root'));assert.deepEqual(current,argv);
    if(['T','t'].includes(fields[0]))break;
    pause();
   }
   break;
  }catch(error){if(error.code!=='ENOENT'||pid)throw error}
 }
 if(!pid)pause();
}
assert.equal(statSync('/output/stdout').size,0);assert.equal(statSync('/output/stderr').size,0);
const name='/output/'+(stream===1?'stdout':'stderr'),fd=openSync('/proc/'+pid+'/fd/'+stream,'w');
const data=Buffer.alloc(Math.min(limit,65536),65);let sent=0;
while(sent<limit){const n=writeSync(fd,data,0,Math.min(data.length,limit-sent));assert(n>0);sent+=n}
while(statSync(name).size!==limit)pause();
assert.equal(writeSync(fd,Buffer.from([66])),1);closeSync(fd);
for(;;){
 try{const fields=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\s+/);if(fields[19]!==epoch||fields[0]==='Z')break}
 catch(error){if(error.code==='ENOENT')break;throw error}
 pause();
}
console.log(JSON.stringify({status:'original-supervisor-first-extra-refused',stream,limit,sentExact:sent,acceptedFileBytes:statSync(name).size,firstExtraWritten:true,originalCompilerGoneOrReaped:true,elapsedBoundMs:7000}));
