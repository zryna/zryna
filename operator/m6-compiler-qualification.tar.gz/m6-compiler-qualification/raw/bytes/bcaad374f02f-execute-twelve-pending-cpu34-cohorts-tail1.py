"""Execute each original-budget owning cohort ONCE, only after actual independent approval."""
import argparse
import datetime
import hashlib
import json
import pathlib
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--approval-review', required=True)
a = p.parse_args()
scratch = pathlib.Path('/workspace/scratch')
head = 'b3be654c452ea51f2c136a75d2eb89995eb4bd66'
tree = '3fa38d7b62b06a64ac5385d610be164f9b1961b8'
source = {'commit': head, 'tree': tree}
operators = scratch / f'M6_410_RUNTIME_COHORT_OPERATORS_{head}_RUN2_TAIL1'
prep = scratch / f'M6_410_LAUNCHER_CPU34_PREPARATION_{head}_RUN1'
kernel = scratch / f'M6_410_KERNEL_POLICY_OPERATORS_{head}_RUN2'
root = scratch / f'M6_410_ACTUAL_PRIVATE_RUNTIME_EXECUTION_{head}_RUN2_TAIL1'
node = '/workspace/.cloud-setup/node-v22.22.1-linux-x64/bin/node'
candidate_review = scratch / f'M6_410_COMPILER_CANDIDATE_REVIEW_{head}_RUN1/REVIEW.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    path = pathlib.Path(path)
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    st = path.stat()
    raw = path.read_bytes()
    assert st.st_nlink == 1 and len(raw) == st.st_size
    assert not st.st_mode & 0o022
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def save(name, value):
    with (root / name).open('x') as out:
        json.dump(value, out, indent=2)
        out.write('\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

def git_source():
    def git(*args):
        return subprocess.run(['git', *args], cwd='/workspace/zryna', capture_output=True, check=True, timeout=10).stdout
    assert git('rev-parse', 'HEAD').decode().strip() == head
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == tree
    assert not git('status', '--porcelain=v1')
    return source

review_path = pathlib.Path(a.approval_review)
assert review_path.is_absolute()
review = json.loads(review_path.read_bytes())
assert review['status'] == 'independently-reviewed-and-root-approved-exact-runtime-candidates'
assert review['source'] == source
assert pin(review['independentReview']['path']) == review['independentReview']
assert pin(candidate_review) == review['candidateReview']
assert len(review['approvedFiles']) >= 4
for item in review['approvedFiles']:
    assert pin(item['path']) == item
assert {str(prep / name) for name in ['approval.json', 'ui-approval.json', 'reviewed-launcher.candidate.json', 'source-composition.json']}.issubset({x['path'] for x in review['approvedFiles']})
assert (prep / 'approval.json').read_bytes() == (prep / 'approval.candidate.json').read_bytes()
assert (prep / 'ui-approval.json').read_bytes() == (prep / 'ui-approval.candidate.json').read_bytes()
bindings = json.loads((operators / 'BINDINGS.json').read_bytes())
assert bindings['source'] == source and bindings['runtimeBudgetsUnchanged'] is True
selected_operators = [row['prepared'] for row in bindings['operators']]
for item in selected_operators:
    assert pin(item['path']) == item
assert pin(operators / 'PLAIN_KEYBOARD_CONTEXT.json') == bindings['plainKeyboardContext']
assert pin(scratch / 'm6-410-plain-keyboard-worker-20261018.mjs')['sha256'] == 'd34aee127c2af785c96370d5bcb722162461604b70a4aba5b59e7249ae59af8a'
assert pin(kernel / 'run-policy-probes.py')['sha256'] == 'dc4b2b9acbf1efd5cb28615b3952e07e0d74430e362945eff284e3da6f8238f2'

jobs = []
def cohort(name, script, result_root, expected, limit=360):
    jobs.append((name, [node, str(operators / script)], scratch / f'{result_root}_{head}_RUN2/RESULT.json', expected, limit))

cohort('parity', 'm6-410-run-actual-http-parity-20261018.mjs', 'M6_410_ACTUAL_CANDIDATE_HTTP_PARITY', 'actual-nineteen-cli-http-browser-comparison-matched')
jobs.append(('plain-keyboard', [node, str(scratch / f'M6_410_RUNTIME_COHORT_OPERATORS_{head}_RUN2/m6-410-plain-keyboard-owner-run2-20261018.mjs'), str(operators / 'PLAIN_KEYBOARD_CONTEXT.json')], scratch / f'M6_410_PLAIN_KEYBOARD_{head}_RUN2/RESULT.json', 'actual-ordinary-chrome-keyboard-and-contrast-pass', 90))
cohort('original-ui-owner', 'm6-410-run-actual-ui-20261018.mjs', 'M6_410_ACTUAL_CANDIDATE_UI', 'actual-initial-abort-corpus-ax-ui-pass', 360)
cohort('http-boundaries', 'm6-410-run-actual-http-boundaries-20261018.mjs', 'M6_410_ACTUAL_CANDIDATE_HTTP_BOUNDARIES', 'actual-http-boundary-cohort-pass')
cohort('session-isolation', 'm6-410-run-actual-session-isolation-20261018.mjs', 'M6_410_ACTUAL_CANDIDATE_SESSION_ISOLATION', 'actual-source-session-and-contained-browser-isolation-pass')
cohort('browser-faults', 'm6-410-run-real-browser-faults-v2-20261018.mjs', 'M6_410_ACTUAL_BROWSER_FAULTS', 'actual-browser-watchdog-cancellation-resource-faults-pass')
cohort('compiler-owner-faults', 'm6-410-run-real-compiler-owner-faults-20261018.mjs', 'M6_410_ACTUAL_COMPILER_OWNER_FAULTS', 'actual-compiler-whole-operation-timeout-and-cancellation-pass')
cohort('compiler-resources', 'm6-410-run-real-compiler-resource-faults-20261018.mjs', 'M6_410_ACTUAL_COMPILER_RESOURCE_FAULTS', 'actual-current-compiler-resource-faults-pass')
cohort('pipe-boundaries', 'm6-410-run-real-pipe-boundaries-20261018.mjs', 'M6_410_ACTUAL_PIPE_BOUNDARIES', 'actual-compiler-stdout-stderr-first-extra-boundaries-pass')
cohort('storage-boundaries', 'm6-410-run-real-storage-boundaries-20261018.mjs', 'M6_410_ACTUAL_STORAGE_BOUNDARIES', 'actual-original-compiler-evaluator-storage-boundaries-pass')
cohort('material-denials', 'material-denial-operator.mjs', 'M6_410_ACTUAL_MATERIAL_DENIAL', 'actual-material-provenance-and-pre-source-audit-denials-pass')
jobs.append(('role-kernel-policy', ['python3', '-B', str(kernel / 'run-policy-probes.py'), '--candidate-review', str(candidate_review)], scratch / f'M6_410_KERNEL_POLICY_ACTUAL_{head}_RUN2/RESULT.json', 'two-owned-new-source-role-policy-probes-pass', 60))
cohort('host-death-and-owned-recovery', 'm6-410-run-real-host-death-v2-20261018.mjs', 'M6_410_ACTUAL_HOST_DEATH', 'actual-host-death-poison-and-operator-recovery-pass')
assert len(jobs) == 13
retained_pin_path=operators/'RETAINED_ACTUAL_ATTEMPT_PINS.json'
retained_raw=retained_pin_path.read_bytes()
assert sha(retained_raw)=='d59458571844d06c798e1eb984e7d6c54cc0a27f3ccaf9a27295360d55a29838'
retained_pins=json.loads(retained_raw)
for path,expected in retained_pins.items():assert pin(path)==expected
retained_root=scratch/f'M6_410_ACTUAL_PRIVATE_RUNTIME_EXECUTION_{head}_RUN2'
retained_parity_path=jobs[0][2]
assert retained_parity_path==scratch/f'M6_410_ACTUAL_CANDIDATE_HTTP_PARITY_{head}_RUN2/RESULT.json'
retained_parity=json.loads(retained_parity_path.read_bytes())
retained_row=json.loads((retained_root/'01-parity.COMPLETE.json').read_bytes())
preflight=json.loads((retained_root/'02-plain-keyboard.COMPLETE.json').read_bytes())
prior_failure=json.loads((retained_root/'FAILURE.json').read_bytes())
assert retained_parity['status']==jobs[0][3] and retained_parity['integration']==source
assert retained_parity['launcherStopped'] is True and retained_parity['authority']['policySha256']=='93e7a96362c750172c2d7e0b6dd98108e154911216a303c54bf55bb052488ab5'
assert retained_row['name']=='parity' and retained_row['exitCode']==0 and retained_row['actualResult']==pin(retained_parity_path)
assert retained_row['actualResultStatus']==jobs[0][3]
assert preflight['name']=='plain-keyboard' and preflight['exitCode']==1 and 'actualResult' not in preflight
assert prior_failure=={'status':'failed-stop-at-first-cohort-no-retry','reason':"('plain-keyboard', 1)",'rowsCompleted':2}
assert preflight['selectedOperator']==pin(scratch/'m6-410-plain-keyboard-owner-20261018.mjs')
old_plain=(scratch/'m6-410-plain-keyboard-owner-20261018.mjs').read_text()
assert old_plain.index("assert(root==='/workspace/scratch/M6_410_PLAIN_KEYBOARD_'+source.commit+'_RUN1')")<old_plain.index('mkdirSync(root')<old_plain.index('await launchOwned(')
assert b"m6-410-plain-keyboard-owner-20261018.mjs:9:29" in (retained_root/'02-plain-keyboard.stderr').read_bytes()
assert pin(scratch/f'M6_410_RUNTIME_COHORT_OPERATORS_{head}_RUN2/m6-410-plain-keyboard-owner-run2-20261018.mjs')['sha256']=='8699af4448cbd0d8c76d67af88c075a56c6a1b30fd2865fcbc788601ec1ee117'
retained_proof={'parityResult':pin(retained_parity_path),'owningCommand':pin(retained_root/'01-parity.COMPLETE.json'),'preservedPreflightFailure':pin(retained_root/'02-plain-keyboard.COMPLETE.json')}
jobs=jobs[1:]
assert len(jobs)==12 and all(not item[2].parent.exists() for item in jobs)

root.mkdir(mode=0o700)
started = now()
rows = []
try:
    save('INTENT.json', {'source': git_source(), 'approvalReview': pin(review_path), 'candidateReview': pin(candidate_review),
        'script': pin(pathlib.Path(__file__).resolve()), 'startedAt': started,
        'retainedActualParity':retained_proof,'plannedNewOwningCommands':12,
        'scope':'Twelve originally unrun pending owning cohorts only, same original budgets/order. Actual previously completed parity retained, never rerun. Failed preflight journal preserved.'})
    deadline = time.monotonic() + 2400
    for index, (name, command, result_path, expected, limit) in enumerate(jobs, 2):
        assert time.monotonic() < deadline
        row = {'name': name, 'argv': command, 'cwd': '/workspace/zryna', 'startedAt': now(),
            'trustedOuterTimeoutSeconds': limit, 'innerBudgetsUnchanged': True, 'selectedOperator': pin(pathlib.Path(command[1] if command[0] == node else command[2]))}
        save(f'{index:02}-{name}.START.json', row)
        print(json.dumps({'event': 'new-source-owned-cohort-start', 'name': name}), flush=True)
        stdout_path = root / f'{index:02}-{name}.stdout'
        stderr_path = root / f'{index:02}-{name}.stderr'
        timed_out = False
        with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
            child = subprocess.Popen(command, cwd='/workspace/zryna', stdout=out, stderr=err)
            row['directChildPid'] = child.pid
            try:
                exit_code = child.wait(timeout=min(limit, max(1, deadline-time.monotonic())))
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    child.kill()
                except ProcessLookupError:
                    pass
                try:
                    exit_code = child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    exit_code = None
                    row['directChildReapUnknown'] = True
                row.update(timedOut=True, innerCleanupEstablishedByOuterOwner=False,
                    cleanupScope='Direct-child termination does not establish native owner/container/volume cleanup. Independent inner recovery observations remain mandatory.')
        row.update(finishedAt=now(), exitCode=exit_code,
            exitSignal=-exit_code if exit_code is not None and exit_code < 0 else None,
            stdout=pin(stdout_path), stderr=pin(stderr_path))
        if result_path.exists():
            row['actualResult'] = pin(result_path)
            try:
                actual = json.loads(result_path.read_bytes())
                row['actualResultStatus'] = actual.get('status')
            except (json.JSONDecodeError, UnicodeDecodeError, AttributeError) as error:
                row['actualResultParseFailure'] = type(error).__name__
        save(f'{index:02}-{name}.COMPLETE.json', row)
        rows.append(row)
        assert not timed_out, (name, 'trusted outer timeout; cleanup not established by outer owner')
        assert exit_code == 0, (name, exit_code)
        assert row.get('actualResultStatus') == expected, (name, row.get('actualResultStatus'))
        print(json.dumps({'event': 'new-source-owned-cohort-complete', 'name': name, 'status': expected}), flush=True)
    for item in selected_operators:
        assert pin(item['path']) == item
    for item in review['approvedFiles']:
        assert pin(item['path']) == item
    save('SOURCE_AFTER.json', git_source())
    save('RESULT.json', {'status': 'actual-twelve-pending-cpu34-owning-cohorts-completed-with-retained-parity-independent-68-review-pending',
        'source': source, 'startedAt': started, 'finishedAt': now(), 'rows': rows,
        'newOwningCommands':12,'retainedActualParity':retained_proof,'originalPreflightFailurePreserved':True,
        'qualificationClaim': False, 'publicationAction': False,
        'scope': 'Independent semantic case mapping and actual readonly post-cleanup confirmation still required.'})
except BaseException as error:
    save('FAILURE.json', {'status': 'failed-stop-at-first-pending-cohort-no-retry', 'reason': str(error)[:3000], 'rowsCompleted': len(rows)})
    raise
