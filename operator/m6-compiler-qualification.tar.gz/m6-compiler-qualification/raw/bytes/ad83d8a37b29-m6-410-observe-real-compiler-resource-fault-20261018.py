"""Fixed trusted operator fault injection into one creation-owned evaluation container.
The public API and guest permissions are unchanged. No capability or browser log is read.
"""
import argparse, hashlib, json, os, pathlib, re, select, struct, sys, time
repo=pathlib.Path('/workspace/zryna')
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/preparation'))
from engine import Engine,decode
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/cli-parity'))
from cli_kernel_read import read,numbers,ticks,fields
import cli_cgroup
parser=argparse.ArgumentParser();parser.add_argument('--parent',type=int,required=True);parser.add_argument('--mode',choices=['memory','tasks','cpu'],required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
root=pathlib.Path(args.output);assert root.parent.name=='M6_410_ACTUAL_COMPILER_RESOURCE_FAULTS_b3be654c452ea51f2c136a75d2eb89995eb4bd66_RUN2';root.mkdir(mode=0o700)
observation_fd=os.open(root/'OBSERVATION.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o400)
deadline=time.monotonic()+18;engine=Engine(65534,seconds=18)
approval=json.loads(pathlib.Path('/workspace/scratch/M6_410_LAUNCHER_CPU34_PREPARATION_b3be654c452ea51f2c136a75d2eb89995eb4bd66_RUN1/approval.json').read_bytes())
image='sha256:'+approval['compiler_image_sha256'];record={'status':'failed','mode':args.mode,'faultApplied':False,'samples':[]};cid=None
def save(name,value):
    with (root/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
def event(name):print(json.dumps({'event':name}),flush=True)
def candidates():return [c for c in engine.json('GET','/containers/json?all=1') if c.get('ImageID')==image and 'zryna410.owner' in c.get('Labels',{})]
def stats(group):
    return {name:read(group+'/'+name,deadline) for name in ['memory.max','memory.swap.max','memory.current','memory.events','pids.max','pids.current','pids.events','cpu.max','cpu.stat','cpuset.cpus.effective']}
def gone(pid,epoch):
    try:return ticks(pid,deadline)!=epoch
    except FileNotFoundError:return True
def exec_request(code,ns_pid,detach):
    request={'AttachStdin':False,'AttachStdout':not detach,'AttachStderr':not detach,'Tty':False,'Privileged':False,
        'User':'65534:65534','WorkingDir':'/tmp','Env':['PATH=/materials/runtime/node/bin','LC_ALL=C.UTF-8','LANG=C.UTF-8','TMPDIR=/tmp','HOME=/nonexistent','TZ=UTC','SOURCE_DATE_EPOCH=0'],
        'Cmd':['/materials/runtime/node/bin/node','--input-type=module','-e',code,str(ns_pid)]}
    created=engine.json('POST','/containers/'+cid+'/exec',request);eid=created['Id'];assert re.fullmatch('[a-f0-9]{64}',eid)
    raw,_=engine.request('POST','/exec/'+eid+'/start',value={'Detach':detach,'Tty':False},maximum_response=4096)
    if detach:assert raw==b''
    else:
        assert len(raw)>=8 and raw[0]==1 and raw[1:4]==b'\0\0\0' and struct.unpack('>I',raw[4:8])[0]==len(raw)-8
        value=json.loads(raw[8:]);assert value=={'signal':'SIGSTOP','pid':ns_pid}
        state=engine.json('GET','/exec/'+eid+'/json');assert state['Running'] is False and state['ExitCode']==0
    return {'execId':eid,'codeSha256':hashlib.sha256(code.encode()).hexdigest(),'namespacePid':ns_pid,'detached':detach}
try:
    assert os.getuid()==1000 and args.parent>1
    assert not candidates(),'A preexisting evaluator cannot be adopted by this probe'
    parent_epoch=ticks(args.parent,deadline);event('ready')
    while time.monotonic()<deadline:
        values=candidates();assert len(values)<=1
        if values and values[0]['State']=='running':
            cid=values[0]['Id'];state=engine.json('GET','/containers/'+cid+'/json');pid=state['State']['Pid']
            assert state['Image']==image and state['Config']['User']=='65534:65534' and state['State']['Paused'] is False
            nonce=state['Config']['Labels']['zryna410.owner'];assert re.fullmatch('[a-f0-9]{32}',nonce)
            membership=read('/proc/'+str(pid)+'/cgroup',deadline);mapping=cli_cgroup.mapping(read,numbers,membership,cid,deadline);group=mapping['path']
            init_epoch=ticks(pid,deadline);init_status=fields(read('/proc/'+str(pid)+'/status',deadline));init_ns=init_status['NSpid'].split();assert len(init_ns)>=2 and init_ns[-1]=='1'
            for selected in numbers(read(group+'/cgroup.procs',deadline)):
                try:
                    command=pathlib.Path('/proc/'+str(selected)+'/cmdline').read_bytes();argv=command.split(b'\0')
                    if not argv or argv[0]!=b'/app/compiler' or b'--audit-materials' not in argv:continue
                    status=fields(read('/proc/'+str(selected)+'/status',deadline));ns=status['NSpid'].split();assert len(ns)>=2
                    assert len(ns)==len(init_ns) and ns[0]==str(selected) and all(x.isdigit() and int(x)>0 for x in ns)
                    chrome_epoch=ticks(selected,deadline);ns_pid=int(ns[-1]);assert ns_pid>1
                    assert ticks(args.parent,deadline)==parent_epoch and ticks(pid,deadline)==init_epoch
                    save('PRODUCER_BEFORE.json',state);save('CGROUP_MAPPING.json',mapping)
                    record.update({'containerId':cid,'ownerNonce':nonce,'initPid':pid,'initEpoch':init_epoch,'auditorPid':selected,'auditorEpoch':chrome_epoch,'namespacePid':ns_pid,'baseline':stats(group)})
                    code="import{readFileSync}from'node:fs';const pid=Number(process.argv[1]);if(!Number.isInteger(pid)||pid<=1)throw Error('PID');const epoch=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\\s+/)[19];if(epoch!=="+json.dumps(chrome_epoch)+")throw Error('EPOCH');const argv=readFileSync('/proc/'+pid+'/cmdline','utf8').split('\\0');if(argv[0]!=='/app/compiler'||!argv.includes('--audit-materials'))throw Error('COMMAND');process.kill(pid,'SIGSTOP');console.log(JSON.stringify({signal:'SIGSTOP',pid}));"
                    record['stop']=exec_request(code,ns_pid,False)
                    assert ticks(selected,deadline)==chrome_epoch
                    assert fields(read('/proc/'+str(selected)+'/status',deadline))['State'].split()[0] in ['T','t']
                    record['faultApplied']=True;event('stopped')
                    break
                except FileNotFoundError:continue
            if record['faultApplied']:break
        time.sleep(.01)
    assert record['faultApplied'],'Owned actual compiler audit was not observed before the fixed deadline'
    pressure=None
    if args.mode=='memory':pressure="globalThis.keep=[];for(let i=0;i<32;i++)keep.push(Buffer.alloc(64*1024*1024,90));setTimeout(()=>{},8000);"
    elif args.mode=='tasks':pressure="import{spawn}from'node:child_process';globalThis.keep=[];for(let i=0;i<8;i++){const c=spawn(process.execPath,['--v8-pool-size=64','--max-old-space-size=32','-e','setTimeout(()=>{},8000)'],{stdio:'ignore'});c.on('error',()=>{});keep.push(c)}setTimeout(()=>{},8000);"
    elif args.mode=='cpu':pressure="import{Worker}from'node:worker_threads';globalThis.keep=[];for(let i=0;i<4;i++)keep.push(new Worker('const e=Date.now()+8000;while(Date.now()<e){}',{eval:true}));setTimeout(()=>{},8000);"
    if pressure:record['pressure']=exec_request(pressure,ns_pid,True)
    completed=False
    while time.monotonic()<deadline:
        available,_,_=select.select([sys.stdin],[],[],0)
        if available:
            line=sys.stdin.readline(128);assert line=='verify\n';completed=True;break
        try:
            snapshot=stats(group);record['samples'].append(snapshot);assert len(record['samples'])<=600
        except FileNotFoundError:pass
        time.sleep(.025)
    assert completed,'Parent did not supply a completed native result'
    engine.request('GET','/containers/'+cid+'/json',statuses=(404,))
    assert gone(pid,init_epoch) and gone(selected,chrome_epoch)
    cg=pathlib.Path(group)
    if cg.exists():assert 'populated 0' in read(group+'/cgroup.events',deadline)
    for mount in state['Mounts']:
        if mount['Destination'] in ['/input','/output']:engine.request('GET','/volumes/'+mount['Name'],statuses=(404,))
    record['nativeContainer404']=True;record['originalInitGone']=True;record['originalAuditorGone']=True;record['ownedGroupEmptyOrRemoved']=True
    for sample in [record['baseline'],*record['samples']]:
        assert sample['memory.max'].strip()=='536870912' and sample['memory.swap.max'].strip()=='0' and sample['pids.max'].strip()=='32' and sample['cpu.max'].strip()=='200000 100000' and sample['cpuset.cpus.effective'].strip()=='3-4'
    def counter(text,key):return int(next(line.split()[1] for line in text.splitlines() if line.split()[0]==key))
    if args.mode=='memory':assert any(counter(s['memory.events'],'oom_kill')>counter(record['baseline']['memory.events'],'oom_kill') for s in record['samples']),'No actual owned-memory OOM observation'
    if args.mode=='tasks':assert any(counter(s['pids.events'],'max')>counter(record['baseline']['pids.events'],'max') for s in record['samples']),'No actual owned-task ceiling observation'
    if args.mode=='cpu':assert any(counter(s['cpu.stat'],'usage_usec')-counter(record['baseline']['cpu.stat'],'usage_usec')>2000000 for s in record['samples']),'Actual four-worker CPU pressure not observed'
    record['status']='actual-owned-compiler-audit-fault-and-reap-observed';event('closed')
finally:
    with os.fdopen(observation_fd,'w') as output:
        json.dump(record,output,indent=2);output.write('\n')
