"""Fixed trusted operator fault injection into one creation-owned evaluation container.
The public API and guest permissions are unchanged. No capability or browser log is read.
"""
import argparse, hashlib, json, os, pathlib, re, select, struct, sys, time, threading
repo=pathlib.Path('/workspace/zryna')
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/preparation'))
from engine import Engine,decode,Connection
sys.path.insert(0,str(repo/'examples/playground/restricted/daemon/cli-parity'))
from cli_kernel_read import read,numbers,ticks,fields
import cli_cgroup
parser=argparse.ArgumentParser();parser.add_argument('--parent',type=int,required=True);parser.add_argument('--mode',choices=['stdout','stderr'],required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
root=pathlib.Path(args.output);assert root.parent.name=='M6_410_ACTUAL_PIPE_BOUNDARIES_b3be654c452ea51f2c136a75d2eb89995eb4bd66_RUN4';root.mkdir(mode=0o700)
observation_fd=os.open(root/'OBSERVATION.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o400)
deadline=time.monotonic()+18;engine=Engine(65534,seconds=18)
approval=json.loads(pathlib.Path('/workspace/scratch/M6_410_LAUNCHER_CPU34_PREPARATION_b3be654c452ea51f2c136a75d2eb89995eb4bd66_RUN1/approval.json').read_bytes())
image='sha256:'+approval['compiler_image_sha256'];record={'status':'failed','mode':args.mode,'faultApplied':False,'samples':[]};cid=None
def save(name,value):
    with (root/name).open('x') as out:json.dump(value,out,indent=2);out.write('\n')
def event(name):print(json.dumps({'event':name}),flush=True)
def candidates():return [c for c in engine.json('GET','/containers/json?all=1') if c.get('ImageID')==image and 'zryna410.owner' in c.get('Labels',{})]
def stats(group):
    return {name:read(group+'/'+name,deadline) for name in ['memory.max','memory.swap.max','memory.current','memory.events','pids.max','pids.current','pids.events','cpu.max','cpu.stat','cpuset.cpus.effective']}
def gone(pid,epoch):
    try:return ticks(pid,deadline)!=epoch
    except FileNotFoundError:return True
def exec_request(code,ns_pid,detach):
    request={'AttachStdin':False,'AttachStdout':not detach,'AttachStderr':not detach,'Tty':False,'Privileged':False,
        'User':'65534:65534','WorkingDir':'/tmp','Env':['PATH=/materials/runtime/node/bin','LC_ALL=C.UTF-8','LANG=C.UTF-8','TMPDIR=/tmp','HOME=/nonexistent','TZ=UTC','SOURCE_DATE_EPOCH=0'],
        'Cmd':['/materials/runtime/node/bin/node','--input-type=module','-e',code,str(ns_pid)]}
    created=engine.json('POST','/containers/'+cid+'/exec',request);eid=created['Id'];assert re.fullmatch('[a-f0-9]{64}',eid)
    raw,_=engine.request('POST','/exec/'+eid+'/start',value={'Detach':detach,'Tty':False},maximum_response=4096)
    if detach:assert raw==b''
    else:
        assert len(raw)>=8 and raw[0]==1 and raw[1:4]==b'\0\0\0' and struct.unpack('>I',raw[4:8])[0]==len(raw)-8
        value=json.loads(raw[8:]);assert value=={'signal':'SIGSTOP','pid':ns_pid}
        state=engine.json('GET','/exec/'+eid+'/json');assert state['Running'] is False and state['ExitCode']==0
    return {'execId':eid,'codeSha256':hashlib.sha256(code.encode()).hexdigest(),'namespacePid':ns_pid,'detached':detach}
try:
    assert os.getuid()==1000 and args.parent>1
    assert not candidates(),'A preexisting evaluator cannot be adopted by this probe'
    parent_epoch=ticks(args.parent,deadline);event('ready')
    while time.monotonic()<deadline:
        values=candidates();assert len(values)<=1
        if values and values[0]['State']=='running':
            cid=values[0]['Id'];state=engine.json('GET','/containers/'+cid+'/json');pid=state['State']['Pid']
            assert state['Image']==image and state['Config']['User']=='65534:65534' and state['State']['Paused'] is False
            nonce=state['Config']['Labels']['zryna410.owner'];assert re.fullmatch('[a-f0-9]{32}',nonce)
            membership=read('/proc/'+str(pid)+'/cgroup',deadline);mapping=cli_cgroup.mapping(read,numbers,membership,cid,deadline);group=mapping['path']
            init_epoch=ticks(pid,deadline);init_status=fields(read('/proc/'+str(pid)+'/status',deadline));init_ns=init_status['NSpid'].split();assert len(init_ns)>=2 and init_ns[-1]=='1'
            for selected in numbers(read(group+'/cgroup.procs',deadline)):
                try:
                    command=pathlib.Path('/proc/'+str(selected)+'/cmdline').read_bytes();argv=command.split(b'\0')
                    if not argv or argv[0]!=b'/app/compiler' or b'--audit-materials' not in argv:continue
                    status=fields(read('/proc/'+str(selected)+'/status',deadline));ns=status['NSpid'].split();assert len(ns)>=2
                    assert len(ns)==len(init_ns) and ns[0]==str(selected) and all(x.isdigit() and int(x)>0 for x in ns)
                    chrome_epoch=ticks(selected,deadline);ns_pid=int(ns[-1]);assert ns_pid>1
                    assert ticks(args.parent,deadline)==parent_epoch and ticks(pid,deadline)==init_epoch
                    save('PRODUCER_BEFORE.json',state);save('CGROUP_MAPPING.json',mapping)
                    record.update({'containerId':cid,'ownerNonce':nonce,'initPid':pid,'initEpoch':init_epoch,'auditorPid':selected,'auditorEpoch':chrome_epoch,'namespacePid':ns_pid,'baseline':stats(group)})
                    code="import{readFileSync}from'node:fs';const pid=Number(process.argv[1]);if(!Number.isInteger(pid)||pid<=1)throw Error('PID');const epoch=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\\s+/)[19];if(epoch!=="+json.dumps(chrome_epoch)+")throw Error('EPOCH');const argv=readFileSync('/proc/'+pid+'/cmdline','utf8').split('\\0');if(argv[0]!=='/app/compiler'||!argv.includes('--audit-materials'))throw Error('COMMAND');process.kill(pid,'SIGSTOP');console.log(JSON.stringify({signal:'SIGSTOP',pid}));"
                    record['stop']=exec_request(code,ns_pid,False)
                    assert ticks(selected,deadline)==chrome_epoch
                    assert fields(read('/proc/'+str(selected)+'/status',deadline))['State'].split()[0] in ['T','t']
                    record['faultApplied']=True;event('stopped')
                    break
                except FileNotFoundError:continue
            if record['faultApplied']:break
        time.sleep(.01)
    assert record['faultApplied'],'Owned actual compiler audit was not observed before the fixed deadline'
    # Trusted watcher starts before the audit resumes; target is original fixed compiler exec.
    watcher=pathlib.Path('/workspace/scratch/M6_410_PIPE_STOP_ACK_PREPARATION_b3be654c452ea51f2c136a75d2eb89995eb4bd66_RUN1/fixed-pipe-boundary-watcher-stop-ack.mjs').read_text()
    maximum=1277956 if args.mode=='stdout' else 4096;which=1 if args.mode=='stdout' else 2
    request={'AttachStdin':False,'AttachStdout':True,'AttachStderr':True,'Tty':False,'Privileged':False,
        'User':'65534:65534','WorkingDir':'/tmp','Env':['PATH=/materials/runtime/node/bin','LC_ALL=C.UTF-8','LANG=C.UTF-8','TMPDIR=/tmp','HOME=/nonexistent','TZ=UTC','SOURCE_DATE_EPOCH=0'],
        'Cmd':['/materials/runtime/node/bin/node','--input-type=module','-e',watcher,str(which),str(maximum)]}
    eid=engine.json('POST','/containers/'+cid+'/exec',request)['Id'];assert re.fullmatch('[a-f0-9]{64}',eid)
    result={}
    original_getresponse=Connection.getresponse
    def observed_getresponse(connection):
        response=original_getresponse(connection)
        if threading.current_thread() is thread:
            result['responseMetadata']={'status':response.status,'version':response.version,'headers':{k:v for k,v in response.getheaders() if k.lower() in ['content-type','content-length','transfer-encoding','api-version']}}
        elif result.get('captureExecInspect'):
            result['execInspectMetadata']={'status':response.status,'version':response.version,'headers':{k:v for k,v in response.getheaders() if k.lower() in ['content-type','content-length','transfer-encoding','api-version']}}
        return response
    Connection.getresponse=observed_getresponse
    def attached():
        try:result['response']=Engine(65534,seconds=12).request('POST','/exec/'+eid+'/start',value={'Detach':False,'Tty':False},maximum_response=8192)
        except BaseException as e:result['error']=repr(e)
    thread=threading.Thread(target=attached);thread.start()
    for _ in range(100):
        if engine.json('GET','/exec/'+eid+'/json')['Running']:break
        time.sleep(.001)
    else:raise AssertionError('Fixed boundary watcher did not start')
    resume="import{readFileSync}from'node:fs';const pid=Number(process.argv[1]);const epoch=readFileSync('/proc/'+pid+'/stat','utf8').split(')').slice(1).join(')').trim().split(/\\s+/)[19];if(epoch!=="+json.dumps(chrome_epoch)+")throw Error('EPOCH');process.kill(pid,'SIGCONT');"
    r={'AttachStdin':False,'AttachStdout':False,'AttachStderr':False,'Tty':False,'Privileged':False,'User':'65534:65534','WorkingDir':'/tmp','Env':request['Env'],'Cmd':['/materials/runtime/node/bin/node','--input-type=module','-e',resume,str(ns_pid)]}
    rid=engine.json('POST','/containers/'+cid+'/exec',r)['Id'];engine.request('POST','/exec/'+rid+'/start',value={'Detach':True,'Tty':False},maximum_response=4096)
    thread.join(12)
    Connection.getresponse=original_getresponse
    save('ATTACHED_RESPONSE_METADATA.json',{'watcherExecId':eid,'threadAlive':thread.is_alive(),'transportError':result.get('error'),'response':result.get('responseMetadata'),'maximumWholeBytes':8192})
    assert not thread.is_alive() and 'error' not in result,result
    raw,receipt=result['response'];assert len(raw)<=8192
    def save_raw(name,value):
        fd=os.open(root/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o400)
        with os.fdopen(fd,'wb') as out:out.write(value)
    # Preserve complete actual bytes BEFORE parsing, including a malformed mux.
    save_raw('ATTACHED_RESPONSE.raw',raw)
    result['captureExecInspect']=True;Connection.getresponse=observed_getresponse
    try:state_raw,_=engine.request('GET','/exec/'+eid+'/json',statuses=(200,404))
    finally:Connection.getresponse=original_getresponse;result['captureExecInspect']=False
    save_raw('WATCHER_EXEC_INSPECT.raw.json',state_raw);watcher_state=decode(state_raw)
    save('WATCHER_EXEC_INSPECT_METADATA.json',result['execInspectMetadata'])
    output=bytearray();stderr=bytearray();offset=0;frames=[]
    while offset<len(raw):
        start=offset;header=raw[offset:offset+8];assert len(header)==8 and header[0] in [1,2] and header[1:4]==b'\0\0\0'
        length=struct.unpack('>I',header[4:8])[0];offset+=8;assert length<=len(raw)-offset
        payload=raw[offset:offset+length];offset+=length
        (output if header[0]==1 else stderr).extend(payload)
        frames.append({'offset':start,'stream':header[0],'bytes':length,'sha256':hashlib.sha256(payload).hexdigest()})
    assert offset==len(raw)
    save_raw('WATCHER_STDOUT.raw',output);save_raw('WATCHER_STDERR.raw',stderr)
    save('ATTACHED_STREAMS.json',{'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'frames':frames,'stdoutBytes':len(output),'stderrBytes':len(stderr),'watcherRunning':watcher_state.get('Running'),'watcherExitCode':watcher_state.get('ExitCode')})
    assert result['responseMetadata']['status']==200
    inspect_status=result['execInspectMetadata']['status']
    if inspect_status==200:
        assert watcher_state.get('Running') is False and watcher_state.get('ExitCode')==0,'Actual observed watcher must exit0'
        record['watcherExitUnobservedAlreadyRemoved']=False
    else:
        assert inspect_status==404
        record['watcherExitUnobservedAlreadyRemoved']=True
        # No fabricated exit0: require the same complete positive boundaryJSON
        # below and original later ownedcleanup guards before observer success.
    record['watcherStderrReviewRequired']=bool(stderr)
    record['watcherExitCode']=watcher_state.get('ExitCode') if inspect_status==200 else None
    record['watcherStderr']={'bytes':len(stderr),'sha256':hashlib.sha256(stderr).hexdigest(),'scope':'Trusted watcher diagnostics, distinct from tested originalcompiler stream; nonemptybytes require independent semanticreview.'}
    actual=json.loads(output);assert actual['status']=='original-supervisor-first-extra-refused' and actual['limit']==maximum and actual['stream']==which and actual['acceptedFileBytes']==maximum and actual['firstExtraWritten'] is True
    record['actualPipeBoundary']=actual;record['watcherSha256']=hashlib.sha256(watcher.encode()).hexdigest();event('boundary')
    ready,_,_=select.select([sys.stdin],[],[],5);assert ready and sys.stdin.readline(128)=='verify\n'
    engine.request('GET','/containers/'+cid+'/json',statuses=(404,));assert gone(pid,init_epoch)
    if pathlib.Path(group).exists():assert 'populated 0' in read(group+'/cgroup.events',deadline)
    for mount in state['Mounts']:
        if mount['Destination'] in ['/input','/output']:engine.request('GET','/volumes/'+mount['Name'],statuses=(404,))
    record.update({'status':'actual-original-compiler-pipe-boundary-and-reap-observed','nativeContainer404':True,'originalInitGone':True,'ownedGroupEmptyOrRemoved':True});event('closed')
finally:
    if 'original_getresponse' in globals():Connection.getresponse=original_getresponse
    with os.fdopen(observation_fd,'w') as output:
        json.dump(record,output,indent=2);output.write('\n')
