// Trusted host UI exercise over ordinary Chrome HTTP. Guest work remains daemon-contained.
import assert from 'node:assert/strict';
import {Server} from 'node:http';
import {readFileSync,writeFileSync,mkdtempSync,rmSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {chromium} from '/workspace/scratch/M6_410_MATERIAL_COMPOSITION_20261018_RUN1/sources/playwright/index.mjs';
import {createSourceLauncher} from '/workspace/zryna/examples/playground/restricted/daemon/launcher.mjs';
import {decodeCompilation,decodeSourceRequest} from '/workspace/zryna/examples/playground/restricted/protocol.mjs';
import {decodeJson} from '/workspace/zryna/examples/playground/restricted/json.mjs';
import {exact,limits} from '/workspace/zryna/examples/playground/restricted/limits.mjs';
import {verifyReceipt} from '/workspace/zryna/examples/playground/restricted/executable.mjs';
import {validateObservation} from '/workspace/zryna/examples/playground/restricted/evaluation.mjs';
import {routes} from '/workspace/zryna/examples/playground/restricted/daemon/ui-qualification/routes.mjs';

assert.equal(process.argv.length,3);
const selected=JSON.parse(readFileSync(process.argv[2]));
const {root,prep,source}=selected;
assert(root.startsWith('/workspace/scratch/M6_410_')&&prep.startsWith('/workspace/scratch/M6_410_'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const save=(name,value)=>writeFileSync(root+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o400});
const proof=()=>{
 const git=(...args)=>execFileSync('git',args,{cwd:'/workspace/zryna',encoding:'utf8'}).trim();
 assert.equal(git('rev-parse','HEAD'),source.commit);assert.equal(git('rev-parse','HEAD^{tree}'),source.tree);assert.equal(git('status','--porcelain'),'');
 return source;
};
const temp=mkdtempSync('/tmp/z4key-'),network=[],serverEvents=[],eventFailures=[];
const safeMessage=error=>String(error.message??error).replace(/[a-f0-9]{64}/g,'REDACTED').slice(0,1500);
const rememberEventFailure=error=>{if(eventFailures.length<8)eventFailures.push(safeMessage(error))};
let launcher,browser,page,watchedPort,observedBrowserVersion,ordinal=0,result={status:'failed'};
const pendingRequests=new Map(),serverResponses=[],originalEmit=Server.prototype.emit;
let compileTokenSha256,evaluationSelection,compilationRequest,expectedAuthority,expectedWit,expectedTemplateSha;
const capturedCompilationBodies=new Map();
Server.prototype.emit=function(event,...args){
 const address=this.address?.();
 if(address&&typeof address==='object'&&address.port===watchedPort&&event==='request'){
  const [request,response]=args;
  if(request.method===(request.url==='/session'?'GET':'POST')&&['/session','/compile','/evaluate','/finish'].includes(request.url)){
   const observed={path:request.url,ordinal:serverResponses.length+1,endCalls:0,writeCalls:0};serverResponses.push(observed);
   const end=response.end,write=response.write;let emittedBody;
   response.write=function(...values){observed.writeCalls++;return Reflect.apply(write,this,values);};
   response.end=function(...values){
    observed.endCalls++;
    try{const chunk=values[0];const body=typeof chunk==='string'?Buffer.from(chunk,typeof values[1]==='string'?values[1]:undefined):Buffer.from(chunk??[]);
     observed.bodyBytes=body.length;observed.bodySha256=sha(body);if(body.length<=(request.url==='/compile'?limits.frame:request.url==='/session'?limits.header:2048))emittedBody=body;
    }catch(error){observed.observerFailure=safeMessage(error);}
    return Reflect.apply(end,this,values);
   };
   response.once('finish',()=>{try{
    observed.status=response.statusCode;observed.finishEventObserved=true;observed.writableFinished=response.writableFinished;
    assert.equal(observed.status,200);assert.equal(observed.endCalls,1);assert.equal(observed.writeCalls,0);assert(observed.writableFinished&&emittedBody);
    if(observed.path==='/compile'){
     const token=response.getHeader('x-zryna-job');assert(/^[a-f0-9]{64}$/.test(token));observed.tokenSha256=sha(Buffer.from(token));
     const encoded=response.getHeader('x-zryna-receipt');assert.equal(typeof encoded,'string');const receiptBytes=Buffer.from(encoded,'base64');assert(receiptBytes.length<=1024);assert.equal(receiptBytes.toString('base64'),encoded);observed.receipt=decodeJson(new Uint8Array(receiptBytes),1024);
     capturedCompilationBodies.set(observed,emittedBody);observed.awaitingCanonicalFrameValidation=true;return;
    }
    const reply=decodeJson(new Uint8Array(emittedBody),observed.path==='/session'?limits.header:2048);
    if(observed.path==='/session'){
     exact(reply,['version','evaluationMode','authority','witSha256','template']);assert.equal(reply.version,2);assert.equal(reply.evaluationMode,'supervised-host');assert.deepEqual({...reply.authority},expectedAuthority);assert.equal(reply.witSha256,expectedWit);
     assert.equal(typeof reply.template,'string');assert(reply.template.length<=Math.ceil(limits.binding/3)*4);const template=Buffer.from(reply.template,'base64');assert(template.length<=limits.binding);assert.equal(template.toString('base64'),reply.template);assert.equal(sha(template),expectedTemplateSha);
     observed.session={version:reply.version,evaluationMode:reply.evaluationMode,authority:reply.authority,witSha256:reply.witSha256,templateBytes:template.length,templateSha256:sha(template)};
    }else if(observed.path==='/evaluate'){
     assert.deepEqual(Object.keys(reply).sort(),['observation','token']);assert(/^[a-f0-9]{64}$/.test(reply.token));assert(evaluationSelection);
     observed.tokenSha256=sha(Buffer.from(reply.token));observed.observation=validateObservation(reply.observation,evaluationSelection);
     assert.equal(observed.observation.logical,'extra');assert.equal(observed.observation.value,42);assert.deepEqual(evaluationSelection.args,[20,21]);
    }else{assert.equal(observed.bodyBytes,17);assert.equal(emittedBody.toString('utf8'),'\u007b"finished":true\u007d');assert.deepEqual({...reply},{finished:true});observed.acknowledgement=reply;}
    observed.completeEmittedResponseVerified=true;
   }catch(error){observed.observerFailure=safeMessage(error);rememberEventFailure(error);}finally{emittedBody=undefined;}});
  }
 }
 if(address&&typeof address==='object'&&address.port===watchedPort&&['connection','drop'].includes(event)){
  serverEvents.push({event,actualConnections:this._connections,maxConnections:this.maxConnections});
 }
 return Reflect.apply(originalEmit,this,[event,...args]);
};
try{
 assert.equal(process.version,'v22.22.1');assert.equal(process.getuid(),1000);save('SOURCE_BEFORE.json',proof());
 const reviewed=JSON.parse(readFileSync(prep+'/reviewed-launcher.candidate.json'));
 assert.equal(reviewed.source.commit,source.commit);assert.equal(reviewed.source.tree,source.tree);
 const approved=JSON.parse(readFileSync(prep+'/approval.json'));expectedAuthority={compilerSha256:reviewed.compiler.sha256,toolkitSha256:reviewed.compositionSha256,policySha256:approved.policy_sha256,bindingTemplateSha256:reviewed.template.sha256};expectedWit=reviewed.witSha256;expectedTemplateSha=reviewed.template.sha256;
 launcher=await createSourceLauncher(reviewed);assert.equal(launcher.qualificationOnly,true);
 await launcher.launch();const privateUrl=launcher.takeLaunchUrl(),origin=new URL(privateUrl).origin;watchedPort=Number(new URL(origin).port);
 browser=await chromium.launch({
  executablePath:'/workspace/scratch/M6_410_MATERIAL_COMPOSITION_20261018_RUN1/sources/browser/chrome-linux64/chrome',
  headless:true,chromiumSandbox:false,timeout:15000,
  env:{PATH:'/usr/bin:/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',HOME:temp,TMPDIR:temp,TZ:'UTC'}
 });
 observedBrowserVersion=browser.version();assert.equal(observedBrowserVersion,'153.0.8010.12');
 const context=await browser.newContext({serviceWorkers:'block'});
 await context.route('**/*',async route=>{
  try{
   const request=route.request(),url=new URL(request.url());
   const allowed=Object.values(routes).some(r=>r.method===request.method()&&r.path===url.pathname);
   assert(url.origin===origin&&!url.search&&!url.username&&!url.password&&allowed,'Closed same-origin UI routes');
   await route.continue();
  }catch(error){rememberEventFailure(error);try{await route.abort()}catch{}}
 });
 page=await context.newPage();page.setDefaultTimeout(15000);
 page.on('request',request=>{
  try{
   const url=new URL(request.url());assert.equal(url.origin,origin);assert(++ordinal<=64);
   const body=request.postDataBuffer();
   const row={id:ordinal,method:request.method(),path:url.pathname,requestBytes:body?.length??0,
    requestSha256:body?sha(body):null,status:null,failureCode:null};
   if(url.pathname==='/compile')compilationRequest=decodeSourceRequest(new Uint8Array(body));
   if(url.pathname==='/evaluate')evaluationSelection=decodeJson(new Uint8Array(body),8192);
   if(url.pathname==='/finish'){const input=JSON.parse(body.toString('utf8'));assert.deepEqual(Object.keys(input).sort(),['cancelled','token']);assert.equal(input.cancelled,false);assert(/^[a-f0-9]{64}$/.test(input.token));row.finishTokenSha256=sha(Buffer.from(input.token));}
   network.push(row);pendingRequests.set(request,row);
  }catch(error){rememberEventFailure(error)}
 });
 page.on('response',response=>{try{const row=pendingRequests.get(response.request());if(row)row.status=response.status();
  if(row?.path==='/compile'&&row.status===200){const token=response.headers()['x-zryna-job'];assert(/^[a-f0-9]{64}$/.test(token));compileTokenSha256=sha(Buffer.from(token));}
 }catch(error){rememberEventFailure(error)}});
 page.on('requestfailed',request=>{const row=pendingRequests.get(request);if(row)row.failureCode=request.failure()?.errorText.match(/net::[A-Z0-9_]+/)?.[0]??'BROWSER_REQUEST_FAILED'});
 await page.goto(privateUrl,{waitUntil:'load'});await page.waitForFunction(()=>!document.getElementById('preset').disabled);
 assert.deepEqual(eventFailures,[]);
 const keyboard=[],focus=[],active=()=>page.evaluate(()=>document.activeElement?.id??'');
 async function press(key){await page.keyboard.press(key);keyboard.push({key,focusedId:await active()})}
 async function tabTo(id){for(let n=0;n<20;n++){if(await active()===id)return;await press('Tab')}throw Error('Keyboard target unavailable:'+id)}
 async function focusProof(){
  const value=await page.evaluate(()=>{
   const e=document.activeElement,s=getComputedStyle(e);
   const colors=value=>{const m=value.match(/^rgba?\(([^)]+)\)$/);if(!m)throw Error('Computed focus color');const n=m[1].split(',').map(Number);return n.length===3?[...n,1]:n};
   const backdrop=e=>{for(let q=e;q;q=q.parentElement){const c=colors(getComputedStyle(q).backgroundColor);if(c[3]===1)return c}return [255,255,255,1]};
   const linear=x=>(x/=255)<=.04045?x/12.92:((x+.055)/1.055)**2.4;
   const lum=c=>.2126*linear(c[0])+.7152*linear(c[1])+.0722*linear(c[2]);
   const fg=colors(s.outlineColor),bg=backdrop(e.parentElement);if(fg[3]!==1)throw Error('Opaque focus outline required');
   const x=lum(fg),y=lum(bg),contrast=(Math.max(x,y)+.05)/(Math.min(x,y)+.05);
   return {id:e.id,focusVisible:e.matches(':focus-visible'),outlineStyle:s.outlineStyle,outlineWidth:s.outlineWidth,outlineColor:s.outlineColor,outlineOffset:s.outlineOffset,adjacentBackground:bg.slice(0,3),activeOutlineContrast:contrast.toFixed(4)};
  });
  assert(value.focusVisible&&value.outlineStyle==='solid'&&value.outlineWidth==='3px'&&Number(value.activeOutlineContrast)>=3);focus.push(value);
 }
 await tabTo('preset');await focusProof();await press('Home');await press('ArrowDown');
 assert.equal(await page.locator('#preset').inputValue(),'edited-literal');assert.equal(await active(),'source');await focusProof();
 const sourceText='export function add(a: i32, b: i32): i32 { return a + b; }\nexport function extra(a: i32, b: i32): i32 { return a + b + 1; }\n';
 await press('Control+A');await page.keyboard.type(sourceText);
 keyboard.push({action:'type-source',utf8Bytes:Buffer.byteLength(sourceText),sha256:sha(Buffer.from(sourceText)),focusedId:await active()});
 assert.equal(await page.locator('#source').inputValue(),sourceText);
 await press('Control+Enter');await page.waitForFunction(()=>document.getElementById('status').textContent==='Compiled. Choose an export and run it.');
 const compiledAfterFinishStatus=await page.locator('#status').textContent();assert.equal(compiledAfterFinishStatus,'Compiled. Choose an export and run it.');
 await tabTo('compile');await focusProof();await tabTo('export');await focusProof();await press('End');assert.equal(await page.locator('#export').inputValue(),'extra');
 await press('Tab');assert.equal(await active(),'argument-0');await focusProof();await press('Control+A');await page.keyboard.type('20');
 await press('Tab');assert.equal(await active(),'argument-1');await focusProof();await press('Control+A');await page.keyboard.type('21');
 await press('Tab');assert.equal(await active(),'run');await focusProof();await press('Space');
 await page.waitForFunction(()=>document.getElementById('observation').textContent==='extra(20, 21) = 42 (signed i32)');
 // Wait for the UI's actual paired finish response before evaluating cleanup/counts.
 await page.waitForFunction(()=>!document.getElementById('run').disabled);
 const appearance=await page.evaluate(()=>{
  const colors=value=>{const m=value.match(/^rgba?\(([^)]+)\)$/);if(!m)throw Error('Computed color');const n=m[1].split(',').map(Number);return n.length===3?[...n,1]:n};
  const linear=x=>(x/=255)<=.04045?x/12.92:((x+.055)/1.055)**2.4;
  const lum=c=>.2126*linear(c[0])+.7152*linear(c[1])+.0722*linear(c[2]);
  const ratio=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
  const backdrop=e=>{for(let q=e;q;q=q.parentElement){const c=colors(getComputedStyle(q).backgroundColor);if(c[3]===1)return c}return [255,255,255,1]};
  return ['source','preset','compile','export','argument-0','argument-1','run','status','observation','source-error'].map(id=>{
   const e=document.getElementById(id),s=getComputedStyle(e),fg=colors(s.color),bg=backdrop(e),outline=colors(s.outlineColor),around=backdrop(e.parentElement);
   return {id,color:s.color,background:bg.slice(0,3),textContrast:ratio(fg,bg).toFixed(4),outlineContrast:ratio(outline,around).toFixed(4),fontSize:s.fontSize,outlineWidth:s.outlineWidth};
  });
 });
 for(const item of appearance)assert(Number(item.textContrast)>=4.5,'Text contrast:'+item.id);
 assert(Number(appearance.find(x=>x.id==='run').outlineContrast)>=3);
 assert.equal(network.filter(r=>r.path==='/compile'&&r.status===200).length,1);
 assert.equal(network.filter(r=>r.path==='/evaluate'&&r.status===200).length,1);
 assert.equal(network.filter(r=>r.path==='/finish'&&r.status===200).length,2);
 assert.deepEqual(eventFailures,[]);
 assert(network.some(r=>r.path==='/session'&&r.status===200));
 // This is a protocol/business oracle, before interpreting browser diagnostic
 // ERR_ABORTED telemetry. It imposes no extra no-abort transport requirement.
 assert.deepEqual(serverResponses.map(r=>r.path),['/session','/compile','/finish','/evaluate','/finish']);
 const compiledResponse=serverResponses[1],compiledBody=capturedCompilationBodies.get(compiledResponse);assert(compiledBody&&compilationRequest);
 const decoded=await decodeCompilation(new Uint8Array(compiledBody),{revision:compilationRequest.revision,source:compilationRequest.source,witSha256:expectedWit});assert.equal(decoded.metadata.status,'compiled');verifyReceipt(compiledResponse.receipt,decoded.metadata,expectedAuthority);assert.equal(compiledResponse.receipt.frameSha256,sha(compiledBody));assert.equal(compiledResponse.tokenSha256,compileTokenSha256);
 compiledResponse.metadata=decoded.metadata;compiledResponse.completeEmittedResponseVerified=true;delete compiledResponse.awaitingCanonicalFrameValidation;capturedCompilationBodies.clear();
 for(const response of serverResponses){const matching=network.filter(row=>row.path===response.path);if(response.path!=='/finish'){assert.equal(matching.length,1);response.pairedRequestId=matching[0].id;response.pairedRequestSha256=matching[0].requestSha256;}}
 assert(serverResponses.every(r=>r.completeEmittedResponseVerified&&!r.observerFailure));
 const finishes=network.filter(r=>r.path==='/finish');assert.equal(finishes.length,2);
 assert.equal(finishes[0].finishTokenSha256,compileTokenSha256);assert.equal(finishes[1].finishTokenSha256,serverResponses[3].tokenSha256);
 assert.notEqual(compileTokenSha256,serverResponses[3].tokenSha256);
 serverResponses[2].pairedRequestId=finishes[0].id;serverResponses[2].pairedRequestSha256=finishes[0].requestSha256;serverResponses[2].pairedTokenSha256=finishes[0].finishTokenSha256;
 serverResponses[4].pairedRequestId=finishes[1].id;serverResponses[4].pairedRequestSha256=finishes[1].requestSha256;serverResponses[4].pairedTokenSha256=finishes[1].finishTokenSha256;
 const evaluation=network.filter(r=>r.path==='/evaluate');assert.equal(evaluation.length,1);serverResponses[3].pairedRequestId=evaluation[0].id;serverResponses[3].pairedRequestSha256=evaluation[0].requestSha256;
 // Preserve the browser failure code. Only these five complete server responses across four protocol routes,
 // consumed by the original controller's post-finish UI state, can qualify it.
 assert(network.every(row=>row.status===200&&(row.failureCode===null||(
  row.failureCode==='net::ERR_ABORTED'&&['/session','/compile','/finish','/evaluate'].includes(row.path)&&serverResponses.some(r=>r.path===row.path&&r.pairedRequestId===row.id&&r.pairedRequestSha256===row.requestSha256&&r.completeEmittedResponseVerified)))));
 assert.equal(serverEvents.filter(r=>r.event==='drop').length,0);assert(serverEvents.some(r=>r.maxConnections===8));
 const dom=await page.evaluate(()=>({source:document.getElementById('source').value,export:document.getElementById('export').value,args:[...document.querySelectorAll('#arguments input')].map(x=>x.value),observation:document.getElementById('observation').textContent,status:document.getElementById('status').textContent}));
 assert.equal(dom.observation,'extra(20, 21) = 42 (signed i32)');assert.equal(await page.locator('#run').isEnabled(),true);
 assert.equal(launcher.recovery().host,null);await browser.close();browser=null;await launcher.stop();launcher=null;
 save('SOURCE_AFTER.json',proof());
 save('OBSERVATION.json',{status:'actual-ordinary-chrome-keyboard-and-contrast-pass',source,compilerSha256:reviewed.compiler.sha256,
  browserVersion:observedBrowserVersion,keyboard,focus,appearance,dom,network,serverEvents,
  serverResponses,compileTokenSha256,compiledAfterFinishStatus,pairedFinishAcknowledgementsVerified:true,
  transport:'Ordinary Chrome TCP and route.continue guard; no route.fulfill, header injection, NodeHTTP bridge or serialization.',
  scope:'Trusted host UI browser with sandbox disabled. Guest compiler and evaluator remain in the original approved daemon containers and original10s/5s/2s budgets. This does not prove host-browser confinement or audible assistive-technology behavior.'});
 result={status:'actual-ordinary-chrome-keyboard-and-contrast-pass',value:42,compilations:1,evaluations:1,pairedFinishes:2,
  browserClosed:true,launcherStopped:true,qualificationOnly:true};
 console.log(JSON.stringify(result));
}catch(error){
 const safe=safeMessage(error);
 result.status='failed';result.failure=safe;save('FAILURE_DIAGNOSTICS.json',{network,serverEvents,eventFailures,serverResponses});throw Error(safe);
}finally{
 Server.prototype.emit=originalEmit;
 const cleanupFailures=[];
 if(browser){try{await browser.close()}catch(error){cleanupFailures.push({operation:'browser.close',message:safeMessage(error)})}}
 if(launcher){try{await launcher.stop()}catch(error){cleanupFailures.push({operation:'launcher.stop',message:safeMessage(error)})}}
 try{rmSync(temp,{recursive:true,force:true})}catch(error){cleanupFailures.push({operation:'remove-owned-temp',message:safeMessage(error)})}
 if(cleanupFailures.length){result.status='failed';result.cleanupFailures=cleanupFailures}
 save('WORKER_RESULT.json',result);
 if(cleanupFailures.length)throw Error('UI cleanup failed; retained WORKER_RESULT preserves all failures');
}
