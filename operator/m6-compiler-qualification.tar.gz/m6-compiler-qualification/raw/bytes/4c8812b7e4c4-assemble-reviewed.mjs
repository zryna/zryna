// Inert create-only formatter. This file never observes guests or grants publication authority.
// No fixture fallback, registry-to-pass generation, network call or process/container launch.
import assert from 'node:assert/strict';
import { constants, closeSync, fstatSync, lstatSync, mkdirSync, openSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { isAbsolute, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const SOURCE={repository:'https://github.com/zryna/zryna',commit:'b3be654c452ea51f2c136a75d2eb89995eb4bd66',tree:'3fa38d7b62b06a64ac5385d610be164f9b1961b8'};
const OLD='5d79dba18117a7ff41ff08d328aa94838c0fce9c';
const MATERIAL_FIELDS=['compositionSha256','compilerManifestSha256','evaluatorManifestSha256','compilerImageSha256','evaluatorImageSha256','operatorApprovalSha256'];
const HASH=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const sha=data=>createHash('sha256').update(data).digest('hex');
const state=s=>['dev','ino','mode','nlink','size','uid','gid','mtimeNs','ctimeNs'].map(k=>s[k]);
function ordinary(path,maximum){
 assert(isAbsolute(path)&&realpathSync(path)===path,'explicit ordinary path with no symlink ancestors');
 const fd=openSync(path,constants.O_RDONLY|constants.O_NOFOLLOW|constants.O_NONBLOCK);
 try{
  const before=fstatSync(fd,{bigint:true});assert(before.isFile()&&before.nlink===1n&&before.size>0n&&before.size<=BigInt(maximum),'finite stable single-link input');
  const raw=readFileSync(fd);assert.deepEqual(state(fstatSync(fd,{bigint:true})),state(before));assert.deepEqual(state(lstatSync(path,{bigint:true})),state(before));assert.equal(BigInt(raw.length),before.size);return raw;
 }finally{closeSync(fd)}
}
function readPin(pin,maximum){
 assert(pin&&isAbsolute(pin.path)&&Number.isSafeInteger(pin.bytes)&&pin.bytes>0&&pin.bytes<=maximum&&HASH(pin.sha256),'complete actual input file pin');
 const raw=ordinary(pin.path,maximum);assert.equal(raw.length,pin.bytes);assert.equal(sha(raw),pin.sha256);return raw;
}
function noHistorical(path){
 assert(!path.includes(OLD)&&!path.includes('HISTORICAL')&&!path.includes('UNQUALIFIED')&&!path.includes('CANDIDATE_QUALIFICATION_PACKET_20261018_RUN2'),'old historical inputs cannot become actual new-source observations');
}

const [selectionPath,outputPath,...extra]=process.argv.slice(2);
assert(selectionPath&&outputPath&&!extra.length,'usage: assemble-reviewed.mjs <actual canonical selection.json> <new absolute output directory>');
const selectionRaw=ordinary(resolve(selectionPath),2*1024*1024);
const input=JSON.parse(new TextDecoder('utf8',{fatal:true}).decode(selectionRaw));
assert.equal(input.format,'zryna.m6-actual-qualification-packet-inputs.v1');assert.equal(input.version,1);
assert.equal(input.contractRoot,'/workspace/zryna','only the reviewed original repository contract, never a fixture/module substitute');
assert(realpathSync(input.contractRoot)===input.contractRoot);
const contract=await import(pathToFileURL(join(input.contractRoot,'scripts/m6/compiler-release/qualification.mjs')).href);
const canonical=await import(pathToFileURL(join(input.contractRoot,'scripts/distribution/canonical.mjs')).href);
const {bytes,portablePath,orderedPaths}=canonical;
assert(bytes(input).equals(selectionRaw),'selection must be canonical JSON, including no duplicate keys');
assert.deepEqual(input.source,SOURCE);assert(input.compiler&&Number.isSafeInteger(input.compiler.bytes)&&input.compiler.bytes>0&&input.compiler.bytes<=128*1024*1024&&HASH(input.compiler.sha256));
assert.equal(contract.qualificationRegistry.obligations.length,68);
const parsePinned=pin=>{const raw=readPin(pin,2*1024*1024);return JSON.parse(new TextDecoder('utf8',{fatal:true}).decode(raw))};
const frozen=parsePinned(input.frozenMain);assert.equal(frozen.status,'actual-reviewed-publication-fix-merged-and-new-main-frozen');assert.equal(frozen.commit,SOURCE.commit);assert.equal(frozen.tree,SOURCE.tree);
const ci=parsePinned(input.fullCiAdmission);assert.equal(ci.source.commit,SOURCE.commit);assert.equal(ci.source.tree,SOURCE.tree);assert.equal(ci.ci.headSha,SOURCE.commit);assert.equal(ci.ci.headTree,SOURCE.tree);assert.equal(ci.ci.conclusion,'success');
const candidate=parsePinned(input.candidateReview);assert.equal(candidate.status,'official-two-replica-candidate-acquired-and-reassembled');assert.equal(candidate.source.commit,SOURCE.commit);assert.equal(candidate.source.tree,SOURCE.tree);assert.deepEqual(candidate.compiler,input.compiler);
const binary=ordinary(candidate.compilerPath,128*1024*1024);assert.equal(binary.length,input.compiler.bytes);assert.equal(sha(binary),input.compiler.sha256);
assert.deepEqual(Object.keys(input.materials).sort(),[...MATERIAL_FIELDS].sort());assert(Object.values(input.materials).every(HASH));
assert.equal(input.publishedInputs.envelopeSha256,'49cbe33ae33d8c926b2ced151435d5e347e42bbe293eef539643a70fccea3ad6');
assert.equal(input.publishedInputs.archiveSha256,'b258d45e1eb58a701026ced7c74d03dc74c911c90a5ec7da93c656884a97159f');assert(HASH(input.publishedInputs.verificationReceiptSha256));
assert(Array.isArray(input.rawFiles)&&input.rawFiles.length>0&&input.rawFiles.length<=480);
const entries=[],byPath=new Map();let total=0;
const expectedBinding={sourceCommit:SOURCE.commit,sourceTree:SOURCE.tree,compilerSha256:input.compiler.sha256,compositionSha256:input.materials.compositionSha256,operatorApprovalSha256:input.materials.operatorApprovalSha256};
for(const file of input.rawFiles){
 portablePath(file.path);assert(file.path.startsWith('raw/')&&!byPath.has(file.path));
 assert(['actual-new-source-observation','supporting-input','independent-semantic-review','readonly-confirmation'].includes(file.role));
 if(file.role!=='supporting-input')noHistorical(file.sourcePath);
 if(file.role==='actual-new-source-observation')assert.deepEqual(file.binding,expectedBinding,'every owning observation explicitly selects actual new source/binary/runtime');
 const data=readPin({path:file.sourcePath,bytes:file.bytes,sha256:file.sha256},2*1024*1024);total+=data.length;assert(total<=48*1024*1024);
 const entry={path:file.path,mode:0o644,data};entries.push(entry);byPath.set(file.path,{...file,entry});
}
orderedPaths(entries.map(f=>f.path));
assert.deepEqual(input.obligations.map(row=>row.id),contract.qualificationRegistry.obligations,'explicit actual cases must cover the original exact sorted68 IDs');
for(const row of input.obligations){
 assert.equal(row.status,'pass');assert(Array.isArray(row.receipts)&&row.receipts.length>0&&row.receipts.length<=16&&new Set(row.receipts).size===row.receipts.length);
 assert(row.receipts.every(path=>byPath.has(path)));assert(row.receipts.some(path=>byPath.get(path).role==='actual-new-source-observation'),'supporting material/confirmation alone cannot prove a case');
}
const confirmation=byPath.get(input.readonlyConfirmationPath),semanticFile=byPath.get(input.independentSemanticReviewPath);
assert(confirmation?.role==='readonly-confirmation'&&semanticFile?.role==='independent-semantic-review');
const semantic=JSON.parse(new TextDecoder('utf8',{fatal:true}).decode(semanticFile.entry.data));assert(bytes(semantic).equals(semanticFile.entry.data),'independent semantic decision must be canonical');
assert.equal(semantic.format,'zryna.m6-independent-semantic-qualification-review.v1');assert.equal(semantic.version,1);assert.equal(semantic.status,'independently-reviewed-actual-positive');
assert.deepEqual(semantic.source,SOURCE);assert.deepEqual(semantic.compiler,input.compiler);assert.deepEqual(semantic.materials,input.materials);
assert(typeof semantic.reviewer==='string'&&/^[A-Za-z0-9@._/-]{1,128}$/.test(semantic.reviewer)&&!/(?:fixture|synthetic)/i.test(semantic.reviewer));
assert.equal(semantic.readonlyConfirmationNewSource,true);assert.equal(semantic.readonlyConfirmationInputsMatch,true);assert.equal(semantic.readonlyConfirmationRuntimeCleanupConfirmed,true);
const describe=entry=>({path:entry.path,bytes:entry.data.length,sha256:sha(entry.data)});
assert.deepEqual(semantic.confirmation,describe(confirmation.entry));
assert.deepEqual(semantic.obligations.map(row=>row.id),contract.qualificationRegistry.obligations);
for(let i=0;i<input.obligations.length;i++){
 const actual=input.obligations[i],reviewed=semantic.obligations[i];assert.equal(reviewed.status,'reviewed-actual-pass');assert.equal(reviewed.actualNewSource,true);assert.deepEqual(reviewed.receipts,actual.receipts);
 assert(typeof reviewed.rationale==='string'&&reviewed.rationale.trim().length>0&&reviewed.rationale.length<=4096,'separate explicit semantic assessment required per owning case');
}
const publishedReceipt=byPath.get(input.publishedInputReceiptPath);assert(publishedReceipt?.role==='supporting-input');assert.equal(publishedReceipt.sha256,input.publishedInputs.verificationReceiptSha256);
const record={format:'zryna.playground-compiler-candidate.v1',version:1,status:'candidate-qualified-not-published',source:input.source,compiler:input.compiler,registrySha256:contract.qualificationRegistrySha256,obligations:input.obligations,publishedInputs:input.publishedInputs,materials:input.materials,files:entries.map(describe)};
const recordBytes=bytes(record);assert(recordBytes.length<=262144,'original canonical record parser budget');
// The independent input supplies the semantic verdict. These fields only project it
// into the original schema; review.qualificationSha256 is RECORD SHA, not packet SHA.
const review={format:'zryna.playground-compiler-candidate-review.v1',version:1,status:semantic.status,source:input.source,compiler:input.compiler,registrySha256:contract.qualificationRegistrySha256,qualificationSha256:sha(recordBytes),rawInventorySha256:sha(bytes(record.files)),reviewer:semantic.reviewer,confirmation:describe(confirmation.entry)};
const reviewBytes=bytes(review);assert(reviewBytes.length<=262144);
contract.validateQualification(record,review,entries,{source:input.source,compiler:input.compiler,selection:{reviewSha256:sha(reviewBytes)}});
const packet=await contract.createQualificationPacket(record,review,entries);assert(packet.length>0&&packet.length<=64*1024*1024);
const packetSha256=sha(packet),reviewSha256=sha(reviewBytes);
const opened=await contract.openQualification(packet,{source:input.source,compiler:input.compiler,selection:{qualificationSha256:packetSha256,reviewSha256}});
assert(bytes(opened.record).equals(recordBytes)&&bytes(opened.review).equals(reviewBytes));
for(const file of input.rawFiles)assert(readPin({path:file.sourcePath,bytes:file.bytes,sha256:file.sha256},2*1024*1024).equals(byPath.get(file.path).entry.data),'raw input changed around canonical encoding');
assert(ordinary(resolve(selectionPath),2*1024*1024).equals(selectionRaw),'selected manifest changed');
const out=resolve(outputPath);assert(isAbsolute(outputPath)&&out.startsWith('/workspace/scratch/')&&!out.includes(OLD));
mkdirSync(out,{mode:0o700});const put=(name,data)=>writeFileSync(join(out,name),data,{flag:'wx',mode:0o600});
put('qualification.json',recordBytes);put('review.json',reviewBytes);put('m6-compiler-qualification.tar.gz',packet);
const pins={source:input.source,compiler:input.compiler,bytes:packet.length,qualificationSha256:packetSha256,reviewSha256,tag:'m6-qualification-'+SOURCE.commit+'-20261018-1'};
put('qualification-pins.json',bytes(pins));
put('PACKAGING_PROOF.json',bytes({status:'canonical-packet-from-explicit-independent-actual-inputs-not-published',source:input.source,compiler:input.compiler,rawFiles:entries.length,rawBytes:total,packetBytes:packet.length,recordSha256:sha(recordBytes),packetSha256,reviewSha256,selectionSha256:sha(selectionRaw),independentSemanticInput:describe(semanticFile.entry),readonlyConfirmation:describe(confirmation.entry),originalValidatorAndCanonicalRoundtrip:true,networkCalls:0,guestExecutions:0,publicSupportClaim:false}));
console.log(JSON.stringify({status:'canonical-packet-prepared-not-published',output:out,bytes:packet.length,qualificationSha256:packetSha256,reviewSha256}));
